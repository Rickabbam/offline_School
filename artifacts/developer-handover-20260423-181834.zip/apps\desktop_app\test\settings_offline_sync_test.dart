import 'dart:convert';

import 'package:desktop_app/auth/auth_service.dart';
import 'package:desktop_app/database/app_database.dart';
import 'package:desktop_app/ui/settings/settings_service.dart';
import 'package:dio/dio.dart';
import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';

class _OfflineAuthService extends AuthService {
  _OfflineAuthService() : super(backendBaseUrl: 'http://localhost:3000');

  @override
  AuthUser? get currentUser => const AuthUser(
        id: 'user-1',
        email: 'admin@example.com',
        fullName: 'Admin User',
        role: 'admin',
        tenantId: 'tenant-1',
        schoolId: 'school-1',
        campusId: 'campus-1',
      );

  @override
  bool get isOfflineSession => true;

  @override
  Dio createAuthenticatedClient() {
    throw StateError('Offline settings test must not use the network.');
  }
}

void main() {
  late AppDatabase db;
  late SettingsService service;

  setUp(() async {
    db = AppDatabase.forTesting(NativeDatabase.memory());
    await db.runMigrations();
    service = SettingsService(_OfflineAuthService(), db);
  });

  tearDown(() async {
    await db.close();
  });

  test('queues offline academic term creation with tenant-scoped payload',
      () async {
    final now = DateTime.now();
    await db.upsertAcademicYear(
      AcademicYearsCacheCompanion.insert(
        id: 'year-1',
        tenantId: 'tenant-1',
        schoolId: 'school-1',
        label: '2026/2027',
        startDate: '2026-09-01',
        endDate: '2027-07-31',
        createdAt: Value(now),
        updatedAt: Value(now),
      ),
    );

    final created = await service.createTerm(
      academicYearId: 'year-1',
      name: 'Term 1',
      termNumber: 1,
      startDate: '2026-09-01',
      endDate: '2026-12-18',
      isCurrent: true,
    );

    final term = await (db.select(db.termsCache)
          ..where((row) => row.id.equals('${created['id']}')))
        .getSingle();
    final queueItem = await (db.select(db.syncQueue)
          ..where((row) => row.entityId.equals(term.id)))
        .getSingle();
    final payload = jsonDecode(queueItem.payloadJson) as Map<String, dynamic>;

    expect(term.tenantId, 'tenant-1');
    expect(term.schoolId, 'school-1');
    expect(term.academicYearId, 'year-1');
    expect(term.serverRevision, 0);
    expect(queueItem.entityType, 'term');
    expect(queueItem.operation, 'create');
    expect(queueItem.status, 'pending');
    expect(payload['tenantId'], 'tenant-1');
    expect(payload['schoolId'], 'school-1');
    expect(payload['academicYearId'], 'year-1');
  });

  test('rejects offline term creation when parent academic year is out of scope',
      () async {
    await expectLater(
      service.createTerm(
        academicYearId: 'missing-year',
        name: 'Term 1',
        termNumber: 1,
        startDate: '2026-09-01',
        endDate: '2026-12-18',
        isCurrent: true,
      ),
      throwsStateError,
    );

    expect(await db.select(db.termsCache).get(), isEmpty);
    expect(await db.select(db.syncQueue).get(), isEmpty);
  });
}
