import { BadRequestException } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import * as bcrypt from 'bcrypt';
import { DataSource } from 'typeorm';
import { OnboardingService } from './onboarding.service';
import { BootstrapSchoolSetupDto } from './dto/bootstrap-school.dto';
import { User } from '../users/user.entity';
import { Device } from '../devices/device.entity';
import { UserRole } from '../users/user-role.enum';
import { SchoolType } from '../schools/school.entity';

jest.mock('bcrypt', () => ({
  hash: jest.fn(),
}));

describe('OnboardingService', () => {
  let service: OnboardingService;

  const usersRepo = {
    findOne: jest.fn(),
  };

  const dataSource = {
    transaction: jest.fn(),
  };

  const draft: BootstrapSchoolSetupDto = {
    school: {
      name: 'Pilot School',
      shortName: 'PS',
      schoolType: SchoolType.Basic,
      address: 'Main Street',
      region: 'Greater Accra',
      district: 'Accra Metro',
      contactPhone: '0200000000',
      contactEmail: 'pilot@example.com',
    },
    campus: {
      name: 'Main Campus',
      address: 'Main Street',
      contactPhone: '0200000000',
      registrationCode: 'MAIN',
    },
    academicYear: {
      label: '2026/2027',
      startDate: '2026-09-01',
      endDate: '2027-07-31',
      terms: [
        {
          name: 'Term 1',
          termNumber: 1,
          startDate: '2026-09-01',
          endDate: '2026-12-15',
          isCurrent: true,
        },
      ],
    },
    classLevels: [
      {
        name: 'JHS 1',
        sortOrder: 1,
        arms: [{ arm: 'A' }],
      },
    ],
    subjects: [
      {
        name: 'Mathematics',
        code: 'MATH',
      },
    ],
    gradingScheme: {
      name: 'Default',
      bands: [
        {
          grade: 'A',
          min: 80,
          max: 100,
          remark: 'Excellent',
        },
      ],
    },
    onboardingDefaults: {
      staffRoles: [],
      feeCategories: [],
      receiptFormat: {
        receiptPrefix: 'RCP',
        nextReceiptNumber: 1,
      },
      notifications: {
        smsEnabled: false,
        paymentReceiptsEnabled: true,
        feeRemindersEnabled: true,
      },
    },
    deviceRegistration: {
      registerOfflineAccess: true,
      deviceName: 'Admin Office PC',
      deviceFingerprint: 'device-fingerprint',
    },
  };

  const currentUser: User = {
    id: 'user-1',
    email: 'admin@example.com',
    passwordHash: 'hash',
    fullName: 'Admin User',
    role: UserRole.Admin,
    tenantId: null,
    schoolId: null,
    campusId: null,
    isActive: true,
    deleted: false,
    createdAt: new Date('2026-01-01T00:00:00.000Z'),
    updatedAt: new Date('2026-01-01T00:00:00.000Z'),
  };

  beforeEach(async () => {
    jest.resetAllMocks();

    const moduleRef = await Test.createTestingModule({
      providers: [
        OnboardingService,
        { provide: DataSource, useValue: dataSource },
        { provide: getRepositoryToken(User), useValue: usersRepo },
      ],
    }).compile();

    service = moduleRef.get(OnboardingService);
  });

  it('bootstraps the school and provisions the trusted device only after scope exists', async () => {
    usersRepo.findOne.mockResolvedValue(currentUser);
    (bcrypt.hash as jest.Mock).mockResolvedValue('hashed-offline-token');

    const state = {
      user: currentUser,
      device: null as Device | null,
      sequence: 1,
    };

    dataSource.transaction.mockImplementation(async (callback) => {
      const manager = {
        query: jest.fn(async () => [{ revision: state.sequence++ }]),
        create: jest.fn((_entity, value) => ({ ...value })),
        save: jest.fn(async (entity, value) => {
          const now = new Date('2026-04-23T12:00:00.000Z');
          const entityName = entity.name;
          const id =
            value.id ??
            `${entityName.toLowerCase()}-${state.sequence++}`;
          const saved = {
            ...value,
            id,
            createdAt: value.createdAt ?? now,
            updatedAt: now,
          };
          if (entity === Device) {
            state.device = saved as Device;
          }
          return saved;
        }),
        update: jest.fn(async (entity, id, values) => {
          if (entity === User && id === currentUser.id) {
            state.user = {
              ...state.user,
              ...values,
            };
          }
        }),
        findOne: jest.fn(async (entity, options) => {
          if (entity === Device) {
            return state.device;
          }
          if (entity === User && options.where.id === currentUser.id) {
            return state.user;
          }
          return null;
        }),
      };

      return callback(manager);
    });

    const result = await service.bootstrapSchoolSetup(currentUser.id, draft);
    expect(result.user).not.toBeNull();
    const updatedUser = result.user!;

    expect(updatedUser).toEqual(
      expect.objectContaining({
        id: currentUser.id,
        tenantId: expect.any(String),
        schoolId: expect.any(String),
        campusId: expect.any(String),
      }),
    );
    expect(result.deviceRegistration).toEqual(
      expect.objectContaining({
        deviceName: 'Admin Office PC',
        deviceFingerprint: 'device-fingerprint',
        offlineToken: expect.stringContaining('-'),
      }),
    );
    expect(result.bootstrapSnapshot).toEqual(
      expect.objectContaining({
        academicYear: expect.objectContaining({
          serverRevision: expect.any(Number),
        }),
        gradingScheme: expect.objectContaining({
          serverRevision: expect.any(Number),
        }),
      }),
    );
    expect(result.bootstrapSnapshot.terms).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          serverRevision: expect.any(Number),
        }),
      ]),
    );
    expect(result.bootstrapSnapshot.classLevels).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          serverRevision: expect.any(Number),
        }),
      ]),
    );
    expect(result.bootstrapSnapshot.classArms).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          serverRevision: expect.any(Number),
        }),
      ]),
    );
    expect(result.bootstrapSnapshot.subjects).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          serverRevision: expect.any(Number),
        }),
      ]),
    );
    expect(state.device).toEqual(
      expect.objectContaining({
        tenantId: updatedUser.tenantId,
        schoolId: updatedUser.schoolId,
        campusId: updatedUser.campusId,
        registeredByUserId: currentUser.id,
        isActive: true,
      }),
    );
  });

  it('rejects onboarding trusted-device registration when the fingerprint belongs to another user', async () => {
    usersRepo.findOne.mockResolvedValue(currentUser);
    (bcrypt.hash as jest.Mock).mockResolvedValue('hashed-offline-token');

    dataSource.transaction.mockImplementation(async (callback) => {
      const manager = {
        query: jest.fn(async () => [{ revision: 1 }]),
        create: jest.fn((_entity, value) => ({ ...value })),
        save: jest.fn(async (entity, value) => ({
          ...value,
          id: value.id ?? `${entity.name.toLowerCase()}-1`,
          createdAt: new Date('2026-04-23T12:00:00.000Z'),
          updatedAt: new Date('2026-04-23T12:00:00.000Z'),
        })),
        update: jest.fn(),
        findOne: jest.fn(async (entity) => {
          if (entity === Device) {
            return {
              id: 'device-foreign',
              deviceFingerprint: 'device-fingerprint',
              registeredByUserId: 'user-2',
            };
          }
          if (entity === User) {
            return {
              ...currentUser,
              tenantId: 'tenant-1',
              schoolId: 'school-1',
              campusId: 'campus-1',
            };
          }
          return null;
        }),
      };

      return callback(manager);
    });

    await expect(
      service.bootstrapSchoolSetup(currentUser.id, draft),
    ).rejects.toBeInstanceOf(BadRequestException);
  });
});
