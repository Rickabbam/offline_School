import { NotFoundException } from '@nestjs/common';
import { CampusesService } from './campuses.service';

describe('CampusesService', () => {
  const dataSource = {
    query: jest.fn(),
  };
  const repo = {
    find: jest.fn(),
    findOne: jest.fn(),
    create: jest.fn(),
    save: jest.fn(),
    update: jest.fn(),
  };

  let service: CampusesService;

  beforeEach(() => {
    jest.resetAllMocks();
    dataSource.query.mockResolvedValue([{ revision: 1 }]);
    service = new CampusesService(dataSource as never, repo as never);
  });

  it('scopes list queries to both tenant and school', async () => {
    repo.find.mockResolvedValue([]);

    await service.findAll('tenant-1', 'school-1');

    expect(repo.find).toHaveBeenCalledWith({
      where: {
        tenantId: 'tenant-1',
        schoolId: 'school-1',
        deleted: false,
      },
    });
  });

  it('forces tenant and school scope on create', async () => {
    repo.create.mockImplementation((value) => value);
    repo.save.mockImplementation(async (value) => value);

    const result = await service.create('tenant-1', 'school-1', {
      tenantId: 'tenant-x',
      schoolId: 'school-x',
      name: 'Main Campus',
    });

    expect(repo.create).toHaveBeenCalledWith(
      expect.objectContaining({
        tenantId: 'tenant-1',
        schoolId: 'school-1',
        name: 'Main Campus',
        registrationCode: expect.any(String),
      }),
    );
    expect(result).toEqual(
      expect.objectContaining({
        tenantId: 'tenant-1',
        schoolId: 'school-1',
      }),
    );
  });

  it('preserves an explicit campus registration code from the setup flow', async () => {
    repo.create.mockImplementation((value) => value);
    repo.save.mockImplementation(async (value) => value);

    const result = await service.create('tenant-1', 'school-1', {
      name: 'Main Campus',
      registrationCode: 'MAIN',
    });

    expect(repo.create).toHaveBeenCalledWith(
      expect.objectContaining({
        tenantId: 'tenant-1',
        schoolId: 'school-1',
        registrationCode: 'MAIN',
      }),
    );
    expect(result).toEqual(
      expect.objectContaining({
        registrationCode: 'MAIN',
      }),
    );
  });

  it('rejects updates outside the authenticated school scope', async () => {
    repo.findOne.mockResolvedValue(null);

    await expect(
      service.update('tenant-1', 'campus-1', { name: 'Renamed' }, 'school-1'),
    ).rejects.toBeInstanceOf(NotFoundException);
  });
});
