import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository, ILike } from 'typeorm';
import { AcademicYear, ClassArm } from '../academic/academic.entity';
import { Campus } from '../campuses/campus.entity';
import { Student, Guardian, Enrollment } from './student.entity';
import { CreateStudentDto } from './dto/create-student.dto';

@Injectable()
export class StudentsService {
  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(Student) private readonly students: Repository<Student>,
    @InjectRepository(Guardian) private readonly guardians: Repository<Guardian>,
    @InjectRepository(Enrollment) private readonly enrollments: Repository<Enrollment>,
    @InjectRepository(AcademicYear) private readonly academicYears: Repository<AcademicYear>,
    @InjectRepository(ClassArm) private readonly classArms: Repository<ClassArm>,
    @InjectRepository(Campus) private readonly campuses: Repository<Campus>,
  ) {}

  findAll(tenantId: string, schoolId: string, search?: string) {
    if (search) {
      return this.students.find({
        where: [
          { tenantId, schoolId, deleted: false, firstName: ILike(`%${search}%`) },
          { tenantId, schoolId, deleted: false, lastName: ILike(`%${search}%`) },
          { tenantId, schoolId, deleted: false, studentNumber: ILike(`%${search}%`) },
        ],
      });
    }
    return this.students.find({ where: { tenantId, schoolId, deleted: false } });
  }

  findById(tenantId: string, schoolId: string, id: string) {
    return this.students.findOne({ where: { id, tenantId, schoolId, deleted: false } });
  }

  async create(tenantId: string, schoolId: string, dto: CreateStudentDto) {
    await this.assertCampusInScope(tenantId, schoolId, dto.campusId);
    const student = this.students.create({
      ...dto,
      tenantId,
      schoolId,
      serverRevision: await this.nextServerRevision(),
      syncStatus: 'local',
    });
    return this.students.save(student);
  }

  async update(tenantId: string, schoolId: string, id: string, data: Partial<Student>) {
    const student = await this.students.findOne({ where: { id, tenantId, schoolId, deleted: false } });
    if (!student) throw new NotFoundException('Student not found.');
    await this.assertCampusInScope(tenantId, schoolId, data.campusId);
    await this.students.update({ id, tenantId, schoolId }, {
      ...data,
      serverRevision: await this.nextServerRevision(),
      syncStatus: 'local',
    });
    return this.findById(tenantId, schoolId, id);
  }

  async remove(tenantId: string, schoolId: string, id: string) {
    const student = await this.students.findOne({ where: { id, tenantId, schoolId, deleted: false } });
    if (!student) throw new NotFoundException('Student not found.');
    await this.students.update({ id, tenantId, schoolId }, {
      deleted: true,
      serverRevision: await this.nextServerRevision(),
      syncStatus: 'local',
    });
  }

  // ─── Guardians ──────────────────────────────────────────────────────────────
  getGuardians(tenantId: string, schoolId: string, studentId: string) {
    return this.guardians.find({ where: { tenantId, schoolId, studentId, deleted: false } });
  }

  async addGuardian(tenantId: string, schoolId: string, data: Partial<Guardian>) {
    await this.assertStudentInScope(tenantId, schoolId, data.studentId);
    return this.guardians.save(
      this.guardians.create({
        ...data,
        tenantId,
        schoolId,
        serverRevision: await this.nextServerRevision(),
      }),
    );
  }

  // ─── Enrollments ────────────────────────────────────────────────────────────
  getEnrollments(tenantId: string, schoolId: string, studentId: string) {
    return this.enrollments.find({ where: { tenantId, schoolId, studentId, deleted: false } });
  }

  async enroll(tenantId: string, schoolId: string, data: Partial<Enrollment>) {
    await this.assertStudentInScope(tenantId, schoolId, data.studentId);
    await this.assertAcademicYearInScope(tenantId, schoolId, data.academicYearId);
    await this.assertClassArmInScope(tenantId, schoolId, data.classArmId);
    const existing = await this.enrollments.findOne({
      where: {
        tenantId,
        schoolId,
        studentId: data.studentId,
        academicYearId: data.academicYearId,
        deleted: false,
      },
    });

    return this.enrollments.save(
      this.enrollments.create({
        ...data,
        tenantId,
        schoolId,
        id: existing?.id,
        serverRevision: await this.nextServerRevision(),
      }),
    );
  }

  private async assertAcademicYearInScope(
    tenantId: string,
    schoolId: string,
    academicYearId: string | undefined,
  ) {
    if (!academicYearId) {
      throw new NotFoundException('Academic year not found.');
    }

    const academicYear = await this.academicYears.findOne({
      where: { id: academicYearId, tenantId, schoolId, deleted: false },
    });
    if (!academicYear) {
      throw new NotFoundException('Academic year not found.');
    }
  }

  private async assertCampusInScope(
    tenantId: string,
    schoolId: string,
    campusId: string | null | undefined,
  ) {
    if (!campusId) {
      return;
    }

    const campus = await this.campuses.findOne({
      where: { id: campusId, tenantId, schoolId, deleted: false },
    });
    if (!campus) {
      throw new NotFoundException('Campus not found.');
    }
  }

  private async assertClassArmInScope(
    tenantId: string,
    schoolId: string,
    classArmId: string | undefined,
  ) {
    if (!classArmId) {
      throw new NotFoundException('Class arm not found.');
    }

    const classArm = await this.classArms.findOne({
      where: { id: classArmId, tenantId, schoolId, deleted: false },
    });
    if (!classArm) {
      throw new NotFoundException('Class arm not found.');
    }
  }

  private async assertStudentInScope(
    tenantId: string,
    schoolId: string,
    studentId: string | undefined,
  ) {
    if (!studentId) {
      throw new NotFoundException('Student not found.');
    }

    const student = await this.students.findOne({
      where: { id: studentId, tenantId, schoolId, deleted: false },
    });
    if (!student) {
      throw new NotFoundException('Student not found.');
    }
  }

  private async nextServerRevision() {
    const result = (await this.dataSource.query(
      "SELECT nextval('sync_server_revision_seq')::bigint AS revision",
    )) as { revision: string | number }[];
    return Number(result[0].revision);
  }
}
