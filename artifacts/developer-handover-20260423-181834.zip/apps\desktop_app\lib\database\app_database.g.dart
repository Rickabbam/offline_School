// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_database.dart';

// ignore_for_file: type=lint
class $SyncQueueTable extends SyncQueue
    with TableInfo<$SyncQueueTable, SyncQueueData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SyncQueueTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityTypeMeta =
      const VerificationMeta('entityType');
  @override
  late final GeneratedColumn<String> entityType = GeneratedColumn<String>(
      'entity_type', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _entityIdMeta =
      const VerificationMeta('entityId');
  @override
  late final GeneratedColumn<String> entityId = GeneratedColumn<String>(
      'entity_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _operationMeta =
      const VerificationMeta('operation');
  @override
  late final GeneratedColumn<String> operation = GeneratedColumn<String>(
      'operation', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _payloadJsonMeta =
      const VerificationMeta('payloadJson');
  @override
  late final GeneratedColumn<String> payloadJson = GeneratedColumn<String>(
      'payload_json', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _retryCountMeta =
      const VerificationMeta('retryCount');
  @override
  late final GeneratedColumn<int> retryCount = GeneratedColumn<int>(
      'retry_count', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _idempotencyKeyMeta =
      const VerificationMeta('idempotencyKey');
  @override
  late final GeneratedColumn<String> idempotencyKey = GeneratedColumn<String>(
      'idempotency_key', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _lamportClockMeta =
      const VerificationMeta('lamportClock');
  @override
  late final GeneratedColumn<int> lamportClock = GeneratedColumn<int>(
      'lamport_clock', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        entityType,
        entityId,
        operation,
        payloadJson,
        status,
        retryCount,
        idempotencyKey,
        lamportClock,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sync_queue';
  @override
  VerificationContext validateIntegrity(Insertable<SyncQueueData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('entity_type')) {
      context.handle(
          _entityTypeMeta,
          entityType.isAcceptableOrUnknown(
              data['entity_type']!, _entityTypeMeta));
    } else if (isInserting) {
      context.missing(_entityTypeMeta);
    }
    if (data.containsKey('entity_id')) {
      context.handle(_entityIdMeta,
          entityId.isAcceptableOrUnknown(data['entity_id']!, _entityIdMeta));
    } else if (isInserting) {
      context.missing(_entityIdMeta);
    }
    if (data.containsKey('operation')) {
      context.handle(_operationMeta,
          operation.isAcceptableOrUnknown(data['operation']!, _operationMeta));
    } else if (isInserting) {
      context.missing(_operationMeta);
    }
    if (data.containsKey('payload_json')) {
      context.handle(
          _payloadJsonMeta,
          payloadJson.isAcceptableOrUnknown(
              data['payload_json']!, _payloadJsonMeta));
    } else if (isInserting) {
      context.missing(_payloadJsonMeta);
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('retry_count')) {
      context.handle(
          _retryCountMeta,
          retryCount.isAcceptableOrUnknown(
              data['retry_count']!, _retryCountMeta));
    }
    if (data.containsKey('idempotency_key')) {
      context.handle(
          _idempotencyKeyMeta,
          idempotencyKey.isAcceptableOrUnknown(
              data['idempotency_key']!, _idempotencyKeyMeta));
    } else if (isInserting) {
      context.missing(_idempotencyKeyMeta);
    }
    if (data.containsKey('lamport_clock')) {
      context.handle(
          _lamportClockMeta,
          lamportClock.isAcceptableOrUnknown(
              data['lamport_clock']!, _lamportClockMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SyncQueueData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SyncQueueData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      entityType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_type'])!,
      entityId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_id'])!,
      operation: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}operation'])!,
      payloadJson: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payload_json'])!,
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      retryCount: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}retry_count'])!,
      idempotencyKey: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}idempotency_key'])!,
      lamportClock: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}lamport_clock'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $SyncQueueTable createAlias(String alias) {
    return $SyncQueueTable(attachedDatabase, alias);
  }
}

class SyncQueueData extends DataClass implements Insertable<SyncQueueData> {
  /// UUID primary key (generated locally with uuid package).
  final String id;

  /// Entity type name, e.g. 'student', 'attendance_record'.
  final String entityType;

  /// UUID of the affected entity.
  final String entityId;

  /// One of: create, update, delete.
  final String operation;

  /// JSON-encoded payload of the full entity state at write time.
  final String payloadJson;

  /// One of: pending, in_progress, done, failed.
  final String status;

  /// Number of push attempts made so far.
  final int retryCount;

  /// Stable key used on the backend to de-duplicate repeated pushes.
  final String idempotencyKey;

  /// Monotonic local logical clock for causal ordering on this device.
  final int lamportClock;

  /// Local timestamp of when the queue item was created.
  final DateTime createdAt;
  const SyncQueueData(
      {required this.id,
      required this.entityType,
      required this.entityId,
      required this.operation,
      required this.payloadJson,
      required this.status,
      required this.retryCount,
      required this.idempotencyKey,
      required this.lamportClock,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['entity_type'] = Variable<String>(entityType);
    map['entity_id'] = Variable<String>(entityId);
    map['operation'] = Variable<String>(operation);
    map['payload_json'] = Variable<String>(payloadJson);
    map['status'] = Variable<String>(status);
    map['retry_count'] = Variable<int>(retryCount);
    map['idempotency_key'] = Variable<String>(idempotencyKey);
    map['lamport_clock'] = Variable<int>(lamportClock);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  SyncQueueCompanion toCompanion(bool nullToAbsent) {
    return SyncQueueCompanion(
      id: Value(id),
      entityType: Value(entityType),
      entityId: Value(entityId),
      operation: Value(operation),
      payloadJson: Value(payloadJson),
      status: Value(status),
      retryCount: Value(retryCount),
      idempotencyKey: Value(idempotencyKey),
      lamportClock: Value(lamportClock),
      createdAt: Value(createdAt),
    );
  }

  factory SyncQueueData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SyncQueueData(
      id: serializer.fromJson<String>(json['id']),
      entityType: serializer.fromJson<String>(json['entityType']),
      entityId: serializer.fromJson<String>(json['entityId']),
      operation: serializer.fromJson<String>(json['operation']),
      payloadJson: serializer.fromJson<String>(json['payloadJson']),
      status: serializer.fromJson<String>(json['status']),
      retryCount: serializer.fromJson<int>(json['retryCount']),
      idempotencyKey: serializer.fromJson<String>(json['idempotencyKey']),
      lamportClock: serializer.fromJson<int>(json['lamportClock']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'entityType': serializer.toJson<String>(entityType),
      'entityId': serializer.toJson<String>(entityId),
      'operation': serializer.toJson<String>(operation),
      'payloadJson': serializer.toJson<String>(payloadJson),
      'status': serializer.toJson<String>(status),
      'retryCount': serializer.toJson<int>(retryCount),
      'idempotencyKey': serializer.toJson<String>(idempotencyKey),
      'lamportClock': serializer.toJson<int>(lamportClock),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  SyncQueueData copyWith(
          {String? id,
          String? entityType,
          String? entityId,
          String? operation,
          String? payloadJson,
          String? status,
          int? retryCount,
          String? idempotencyKey,
          int? lamportClock,
          DateTime? createdAt}) =>
      SyncQueueData(
        id: id ?? this.id,
        entityType: entityType ?? this.entityType,
        entityId: entityId ?? this.entityId,
        operation: operation ?? this.operation,
        payloadJson: payloadJson ?? this.payloadJson,
        status: status ?? this.status,
        retryCount: retryCount ?? this.retryCount,
        idempotencyKey: idempotencyKey ?? this.idempotencyKey,
        lamportClock: lamportClock ?? this.lamportClock,
        createdAt: createdAt ?? this.createdAt,
      );
  SyncQueueData copyWithCompanion(SyncQueueCompanion data) {
    return SyncQueueData(
      id: data.id.present ? data.id.value : this.id,
      entityType:
          data.entityType.present ? data.entityType.value : this.entityType,
      entityId: data.entityId.present ? data.entityId.value : this.entityId,
      operation: data.operation.present ? data.operation.value : this.operation,
      payloadJson:
          data.payloadJson.present ? data.payloadJson.value : this.payloadJson,
      status: data.status.present ? data.status.value : this.status,
      retryCount:
          data.retryCount.present ? data.retryCount.value : this.retryCount,
      idempotencyKey: data.idempotencyKey.present
          ? data.idempotencyKey.value
          : this.idempotencyKey,
      lamportClock: data.lamportClock.present
          ? data.lamportClock.value
          : this.lamportClock,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SyncQueueData(')
          ..write('id: $id, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('operation: $operation, ')
          ..write('payloadJson: $payloadJson, ')
          ..write('status: $status, ')
          ..write('retryCount: $retryCount, ')
          ..write('idempotencyKey: $idempotencyKey, ')
          ..write('lamportClock: $lamportClock, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, entityType, entityId, operation,
      payloadJson, status, retryCount, idempotencyKey, lamportClock, createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SyncQueueData &&
          other.id == this.id &&
          other.entityType == this.entityType &&
          other.entityId == this.entityId &&
          other.operation == this.operation &&
          other.payloadJson == this.payloadJson &&
          other.status == this.status &&
          other.retryCount == this.retryCount &&
          other.idempotencyKey == this.idempotencyKey &&
          other.lamportClock == this.lamportClock &&
          other.createdAt == this.createdAt);
}

class SyncQueueCompanion extends UpdateCompanion<SyncQueueData> {
  final Value<String> id;
  final Value<String> entityType;
  final Value<String> entityId;
  final Value<String> operation;
  final Value<String> payloadJson;
  final Value<String> status;
  final Value<int> retryCount;
  final Value<String> idempotencyKey;
  final Value<int> lamportClock;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const SyncQueueCompanion({
    this.id = const Value.absent(),
    this.entityType = const Value.absent(),
    this.entityId = const Value.absent(),
    this.operation = const Value.absent(),
    this.payloadJson = const Value.absent(),
    this.status = const Value.absent(),
    this.retryCount = const Value.absent(),
    this.idempotencyKey = const Value.absent(),
    this.lamportClock = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SyncQueueCompanion.insert({
    required String id,
    required String entityType,
    required String entityId,
    required String operation,
    required String payloadJson,
    this.status = const Value.absent(),
    this.retryCount = const Value.absent(),
    required String idempotencyKey,
    this.lamportClock = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        entityType = Value(entityType),
        entityId = Value(entityId),
        operation = Value(operation),
        payloadJson = Value(payloadJson),
        idempotencyKey = Value(idempotencyKey);
  static Insertable<SyncQueueData> custom({
    Expression<String>? id,
    Expression<String>? entityType,
    Expression<String>? entityId,
    Expression<String>? operation,
    Expression<String>? payloadJson,
    Expression<String>? status,
    Expression<int>? retryCount,
    Expression<String>? idempotencyKey,
    Expression<int>? lamportClock,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (entityType != null) 'entity_type': entityType,
      if (entityId != null) 'entity_id': entityId,
      if (operation != null) 'operation': operation,
      if (payloadJson != null) 'payload_json': payloadJson,
      if (status != null) 'status': status,
      if (retryCount != null) 'retry_count': retryCount,
      if (idempotencyKey != null) 'idempotency_key': idempotencyKey,
      if (lamportClock != null) 'lamport_clock': lamportClock,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SyncQueueCompanion copyWith(
      {Value<String>? id,
      Value<String>? entityType,
      Value<String>? entityId,
      Value<String>? operation,
      Value<String>? payloadJson,
      Value<String>? status,
      Value<int>? retryCount,
      Value<String>? idempotencyKey,
      Value<int>? lamportClock,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return SyncQueueCompanion(
      id: id ?? this.id,
      entityType: entityType ?? this.entityType,
      entityId: entityId ?? this.entityId,
      operation: operation ?? this.operation,
      payloadJson: payloadJson ?? this.payloadJson,
      status: status ?? this.status,
      retryCount: retryCount ?? this.retryCount,
      idempotencyKey: idempotencyKey ?? this.idempotencyKey,
      lamportClock: lamportClock ?? this.lamportClock,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (entityType.present) {
      map['entity_type'] = Variable<String>(entityType.value);
    }
    if (entityId.present) {
      map['entity_id'] = Variable<String>(entityId.value);
    }
    if (operation.present) {
      map['operation'] = Variable<String>(operation.value);
    }
    if (payloadJson.present) {
      map['payload_json'] = Variable<String>(payloadJson.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (retryCount.present) {
      map['retry_count'] = Variable<int>(retryCount.value);
    }
    if (idempotencyKey.present) {
      map['idempotency_key'] = Variable<String>(idempotencyKey.value);
    }
    if (lamportClock.present) {
      map['lamport_clock'] = Variable<int>(lamportClock.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SyncQueueCompanion(')
          ..write('id: $id, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('operation: $operation, ')
          ..write('payloadJson: $payloadJson, ')
          ..write('status: $status, ')
          ..write('retryCount: $retryCount, ')
          ..write('idempotencyKey: $idempotencyKey, ')
          ..write('lamportClock: $lamportClock, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SyncStateTable extends SyncState
    with TableInfo<$SyncStateTable, SyncStateData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SyncStateTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _entityTypeMeta =
      const VerificationMeta('entityType');
  @override
  late final GeneratedColumn<String> entityType = GeneratedColumn<String>(
      'entity_type', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _lastServerRevisionMeta =
      const VerificationMeta('lastServerRevision');
  @override
  late final GeneratedColumn<int> lastServerRevision = GeneratedColumn<int>(
      'last_server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _lastPulledAtMeta =
      const VerificationMeta('lastPulledAt');
  @override
  late final GeneratedColumn<DateTime> lastPulledAt = GeneratedColumn<DateTime>(
      'last_pulled_at', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [entityType, lastServerRevision, lastPulledAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sync_state';
  @override
  VerificationContext validateIntegrity(Insertable<SyncStateData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('entity_type')) {
      context.handle(
          _entityTypeMeta,
          entityType.isAcceptableOrUnknown(
              data['entity_type']!, _entityTypeMeta));
    } else if (isInserting) {
      context.missing(_entityTypeMeta);
    }
    if (data.containsKey('last_server_revision')) {
      context.handle(
          _lastServerRevisionMeta,
          lastServerRevision.isAcceptableOrUnknown(
              data['last_server_revision']!, _lastServerRevisionMeta));
    }
    if (data.containsKey('last_pulled_at')) {
      context.handle(
          _lastPulledAtMeta,
          lastPulledAt.isAcceptableOrUnknown(
              data['last_pulled_at']!, _lastPulledAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {entityType};
  @override
  SyncStateData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SyncStateData(
      entityType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_type'])!,
      lastServerRevision: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}last_server_revision'])!,
      lastPulledAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}last_pulled_at']),
    );
  }

  @override
  $SyncStateTable createAlias(String alias) {
    return $SyncStateTable(attachedDatabase, alias);
  }
}

class SyncStateData extends DataClass implements Insertable<SyncStateData> {
  /// Entity type name, e.g. 'student', 'attendance_record'.
  final String entityType;

  /// The last server_revision value received for this entity type.
  /// Start at 0 — meaning "pull everything from the beginning".
  final int lastServerRevision;

  /// Timestamp of the last successful pull for this entity type.
  final DateTime? lastPulledAt;
  const SyncStateData(
      {required this.entityType,
      required this.lastServerRevision,
      this.lastPulledAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['entity_type'] = Variable<String>(entityType);
    map['last_server_revision'] = Variable<int>(lastServerRevision);
    if (!nullToAbsent || lastPulledAt != null) {
      map['last_pulled_at'] = Variable<DateTime>(lastPulledAt);
    }
    return map;
  }

  SyncStateCompanion toCompanion(bool nullToAbsent) {
    return SyncStateCompanion(
      entityType: Value(entityType),
      lastServerRevision: Value(lastServerRevision),
      lastPulledAt: lastPulledAt == null && nullToAbsent
          ? const Value.absent()
          : Value(lastPulledAt),
    );
  }

  factory SyncStateData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SyncStateData(
      entityType: serializer.fromJson<String>(json['entityType']),
      lastServerRevision: serializer.fromJson<int>(json['lastServerRevision']),
      lastPulledAt: serializer.fromJson<DateTime?>(json['lastPulledAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'entityType': serializer.toJson<String>(entityType),
      'lastServerRevision': serializer.toJson<int>(lastServerRevision),
      'lastPulledAt': serializer.toJson<DateTime?>(lastPulledAt),
    };
  }

  SyncStateData copyWith(
          {String? entityType,
          int? lastServerRevision,
          Value<DateTime?> lastPulledAt = const Value.absent()}) =>
      SyncStateData(
        entityType: entityType ?? this.entityType,
        lastServerRevision: lastServerRevision ?? this.lastServerRevision,
        lastPulledAt:
            lastPulledAt.present ? lastPulledAt.value : this.lastPulledAt,
      );
  SyncStateData copyWithCompanion(SyncStateCompanion data) {
    return SyncStateData(
      entityType:
          data.entityType.present ? data.entityType.value : this.entityType,
      lastServerRevision: data.lastServerRevision.present
          ? data.lastServerRevision.value
          : this.lastServerRevision,
      lastPulledAt: data.lastPulledAt.present
          ? data.lastPulledAt.value
          : this.lastPulledAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SyncStateData(')
          ..write('entityType: $entityType, ')
          ..write('lastServerRevision: $lastServerRevision, ')
          ..write('lastPulledAt: $lastPulledAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(entityType, lastServerRevision, lastPulledAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SyncStateData &&
          other.entityType == this.entityType &&
          other.lastServerRevision == this.lastServerRevision &&
          other.lastPulledAt == this.lastPulledAt);
}

class SyncStateCompanion extends UpdateCompanion<SyncStateData> {
  final Value<String> entityType;
  final Value<int> lastServerRevision;
  final Value<DateTime?> lastPulledAt;
  final Value<int> rowid;
  const SyncStateCompanion({
    this.entityType = const Value.absent(),
    this.lastServerRevision = const Value.absent(),
    this.lastPulledAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SyncStateCompanion.insert({
    required String entityType,
    this.lastServerRevision = const Value.absent(),
    this.lastPulledAt = const Value.absent(),
    this.rowid = const Value.absent(),
  }) : entityType = Value(entityType);
  static Insertable<SyncStateData> custom({
    Expression<String>? entityType,
    Expression<int>? lastServerRevision,
    Expression<DateTime>? lastPulledAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (entityType != null) 'entity_type': entityType,
      if (lastServerRevision != null)
        'last_server_revision': lastServerRevision,
      if (lastPulledAt != null) 'last_pulled_at': lastPulledAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SyncStateCompanion copyWith(
      {Value<String>? entityType,
      Value<int>? lastServerRevision,
      Value<DateTime?>? lastPulledAt,
      Value<int>? rowid}) {
    return SyncStateCompanion(
      entityType: entityType ?? this.entityType,
      lastServerRevision: lastServerRevision ?? this.lastServerRevision,
      lastPulledAt: lastPulledAt ?? this.lastPulledAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (entityType.present) {
      map['entity_type'] = Variable<String>(entityType.value);
    }
    if (lastServerRevision.present) {
      map['last_server_revision'] = Variable<int>(lastServerRevision.value);
    }
    if (lastPulledAt.present) {
      map['last_pulled_at'] = Variable<DateTime>(lastPulledAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SyncStateCompanion(')
          ..write('entityType: $entityType, ')
          ..write('lastServerRevision: $lastServerRevision, ')
          ..write('lastPulledAt: $lastPulledAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SyncConflictsTable extends SyncConflicts
    with TableInfo<$SyncConflictsTable, SyncConflict> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SyncConflictsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _queueItemIdMeta =
      const VerificationMeta('queueItemId');
  @override
  late final GeneratedColumn<String> queueItemId = GeneratedColumn<String>(
      'queue_item_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _campusIdMeta =
      const VerificationMeta('campusId');
  @override
  late final GeneratedColumn<String> campusId = GeneratedColumn<String>(
      'campus_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _entityTypeMeta =
      const VerificationMeta('entityType');
  @override
  late final GeneratedColumn<String> entityType = GeneratedColumn<String>(
      'entity_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityIdMeta =
      const VerificationMeta('entityId');
  @override
  late final GeneratedColumn<String> entityId = GeneratedColumn<String>(
      'entity_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _operationMeta =
      const VerificationMeta('operation');
  @override
  late final GeneratedColumn<String> operation = GeneratedColumn<String>(
      'operation', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _conflictTypeMeta =
      const VerificationMeta('conflictType');
  @override
  late final GeneratedColumn<String> conflictType = GeneratedColumn<String>(
      'conflict_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _payloadJsonMeta =
      const VerificationMeta('payloadJson');
  @override
  late final GeneratedColumn<String> payloadJson = GeneratedColumn<String>(
      'payload_json', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _serverMessageMeta =
      const VerificationMeta('serverMessage');
  @override
  late final GeneratedColumn<String> serverMessage = GeneratedColumn<String>(
      'server_message', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _responseJsonMeta =
      const VerificationMeta('responseJson');
  @override
  late final GeneratedColumn<String> responseJson = GeneratedColumn<String>(
      'response_json', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('open'));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        queueItemId,
        tenantId,
        schoolId,
        campusId,
        entityType,
        entityId,
        operation,
        conflictType,
        payloadJson,
        serverMessage,
        responseJson,
        status,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sync_conflicts';
  @override
  VerificationContext validateIntegrity(Insertable<SyncConflict> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('queue_item_id')) {
      context.handle(
          _queueItemIdMeta,
          queueItemId.isAcceptableOrUnknown(
              data['queue_item_id']!, _queueItemIdMeta));
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('campus_id')) {
      context.handle(_campusIdMeta,
          campusId.isAcceptableOrUnknown(data['campus_id']!, _campusIdMeta));
    }
    if (data.containsKey('entity_type')) {
      context.handle(
          _entityTypeMeta,
          entityType.isAcceptableOrUnknown(
              data['entity_type']!, _entityTypeMeta));
    } else if (isInserting) {
      context.missing(_entityTypeMeta);
    }
    if (data.containsKey('entity_id')) {
      context.handle(_entityIdMeta,
          entityId.isAcceptableOrUnknown(data['entity_id']!, _entityIdMeta));
    } else if (isInserting) {
      context.missing(_entityIdMeta);
    }
    if (data.containsKey('operation')) {
      context.handle(_operationMeta,
          operation.isAcceptableOrUnknown(data['operation']!, _operationMeta));
    } else if (isInserting) {
      context.missing(_operationMeta);
    }
    if (data.containsKey('conflict_type')) {
      context.handle(
          _conflictTypeMeta,
          conflictType.isAcceptableOrUnknown(
              data['conflict_type']!, _conflictTypeMeta));
    } else if (isInserting) {
      context.missing(_conflictTypeMeta);
    }
    if (data.containsKey('payload_json')) {
      context.handle(
          _payloadJsonMeta,
          payloadJson.isAcceptableOrUnknown(
              data['payload_json']!, _payloadJsonMeta));
    } else if (isInserting) {
      context.missing(_payloadJsonMeta);
    }
    if (data.containsKey('server_message')) {
      context.handle(
          _serverMessageMeta,
          serverMessage.isAcceptableOrUnknown(
              data['server_message']!, _serverMessageMeta));
    }
    if (data.containsKey('response_json')) {
      context.handle(
          _responseJsonMeta,
          responseJson.isAcceptableOrUnknown(
              data['response_json']!, _responseJsonMeta));
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SyncConflict map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SyncConflict(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      queueItemId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}queue_item_id']),
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      campusId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}campus_id']),
      entityType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_type'])!,
      entityId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_id'])!,
      operation: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}operation'])!,
      conflictType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}conflict_type'])!,
      payloadJson: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payload_json'])!,
      serverMessage: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}server_message']),
      responseJson: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}response_json']),
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $SyncConflictsTable createAlias(String alias) {
    return $SyncConflictsTable(attachedDatabase, alias);
  }
}

class SyncConflict extends DataClass implements Insertable<SyncConflict> {
  final String id;
  final String? queueItemId;
  final String tenantId;
  final String schoolId;
  final String? campusId;
  final String entityType;
  final String entityId;
  final String operation;
  final String conflictType;
  final String payloadJson;
  final String? serverMessage;
  final String? responseJson;
  final String status;
  final DateTime createdAt;
  const SyncConflict(
      {required this.id,
      this.queueItemId,
      required this.tenantId,
      required this.schoolId,
      this.campusId,
      required this.entityType,
      required this.entityId,
      required this.operation,
      required this.conflictType,
      required this.payloadJson,
      this.serverMessage,
      this.responseJson,
      required this.status,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    if (!nullToAbsent || queueItemId != null) {
      map['queue_item_id'] = Variable<String>(queueItemId);
    }
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    if (!nullToAbsent || campusId != null) {
      map['campus_id'] = Variable<String>(campusId);
    }
    map['entity_type'] = Variable<String>(entityType);
    map['entity_id'] = Variable<String>(entityId);
    map['operation'] = Variable<String>(operation);
    map['conflict_type'] = Variable<String>(conflictType);
    map['payload_json'] = Variable<String>(payloadJson);
    if (!nullToAbsent || serverMessage != null) {
      map['server_message'] = Variable<String>(serverMessage);
    }
    if (!nullToAbsent || responseJson != null) {
      map['response_json'] = Variable<String>(responseJson);
    }
    map['status'] = Variable<String>(status);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  SyncConflictsCompanion toCompanion(bool nullToAbsent) {
    return SyncConflictsCompanion(
      id: Value(id),
      queueItemId: queueItemId == null && nullToAbsent
          ? const Value.absent()
          : Value(queueItemId),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      campusId: campusId == null && nullToAbsent
          ? const Value.absent()
          : Value(campusId),
      entityType: Value(entityType),
      entityId: Value(entityId),
      operation: Value(operation),
      conflictType: Value(conflictType),
      payloadJson: Value(payloadJson),
      serverMessage: serverMessage == null && nullToAbsent
          ? const Value.absent()
          : Value(serverMessage),
      responseJson: responseJson == null && nullToAbsent
          ? const Value.absent()
          : Value(responseJson),
      status: Value(status),
      createdAt: Value(createdAt),
    );
  }

  factory SyncConflict.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SyncConflict(
      id: serializer.fromJson<String>(json['id']),
      queueItemId: serializer.fromJson<String?>(json['queueItemId']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      campusId: serializer.fromJson<String?>(json['campusId']),
      entityType: serializer.fromJson<String>(json['entityType']),
      entityId: serializer.fromJson<String>(json['entityId']),
      operation: serializer.fromJson<String>(json['operation']),
      conflictType: serializer.fromJson<String>(json['conflictType']),
      payloadJson: serializer.fromJson<String>(json['payloadJson']),
      serverMessage: serializer.fromJson<String?>(json['serverMessage']),
      responseJson: serializer.fromJson<String?>(json['responseJson']),
      status: serializer.fromJson<String>(json['status']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'queueItemId': serializer.toJson<String?>(queueItemId),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'campusId': serializer.toJson<String?>(campusId),
      'entityType': serializer.toJson<String>(entityType),
      'entityId': serializer.toJson<String>(entityId),
      'operation': serializer.toJson<String>(operation),
      'conflictType': serializer.toJson<String>(conflictType),
      'payloadJson': serializer.toJson<String>(payloadJson),
      'serverMessage': serializer.toJson<String?>(serverMessage),
      'responseJson': serializer.toJson<String?>(responseJson),
      'status': serializer.toJson<String>(status),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  SyncConflict copyWith(
          {String? id,
          Value<String?> queueItemId = const Value.absent(),
          String? tenantId,
          String? schoolId,
          Value<String?> campusId = const Value.absent(),
          String? entityType,
          String? entityId,
          String? operation,
          String? conflictType,
          String? payloadJson,
          Value<String?> serverMessage = const Value.absent(),
          Value<String?> responseJson = const Value.absent(),
          String? status,
          DateTime? createdAt}) =>
      SyncConflict(
        id: id ?? this.id,
        queueItemId: queueItemId.present ? queueItemId.value : this.queueItemId,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        campusId: campusId.present ? campusId.value : this.campusId,
        entityType: entityType ?? this.entityType,
        entityId: entityId ?? this.entityId,
        operation: operation ?? this.operation,
        conflictType: conflictType ?? this.conflictType,
        payloadJson: payloadJson ?? this.payloadJson,
        serverMessage:
            serverMessage.present ? serverMessage.value : this.serverMessage,
        responseJson:
            responseJson.present ? responseJson.value : this.responseJson,
        status: status ?? this.status,
        createdAt: createdAt ?? this.createdAt,
      );
  SyncConflict copyWithCompanion(SyncConflictsCompanion data) {
    return SyncConflict(
      id: data.id.present ? data.id.value : this.id,
      queueItemId:
          data.queueItemId.present ? data.queueItemId.value : this.queueItemId,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      campusId: data.campusId.present ? data.campusId.value : this.campusId,
      entityType:
          data.entityType.present ? data.entityType.value : this.entityType,
      entityId: data.entityId.present ? data.entityId.value : this.entityId,
      operation: data.operation.present ? data.operation.value : this.operation,
      conflictType: data.conflictType.present
          ? data.conflictType.value
          : this.conflictType,
      payloadJson:
          data.payloadJson.present ? data.payloadJson.value : this.payloadJson,
      serverMessage: data.serverMessage.present
          ? data.serverMessage.value
          : this.serverMessage,
      responseJson: data.responseJson.present
          ? data.responseJson.value
          : this.responseJson,
      status: data.status.present ? data.status.value : this.status,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SyncConflict(')
          ..write('id: $id, ')
          ..write('queueItemId: $queueItemId, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('operation: $operation, ')
          ..write('conflictType: $conflictType, ')
          ..write('payloadJson: $payloadJson, ')
          ..write('serverMessage: $serverMessage, ')
          ..write('responseJson: $responseJson, ')
          ..write('status: $status, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      queueItemId,
      tenantId,
      schoolId,
      campusId,
      entityType,
      entityId,
      operation,
      conflictType,
      payloadJson,
      serverMessage,
      responseJson,
      status,
      createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SyncConflict &&
          other.id == this.id &&
          other.queueItemId == this.queueItemId &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.campusId == this.campusId &&
          other.entityType == this.entityType &&
          other.entityId == this.entityId &&
          other.operation == this.operation &&
          other.conflictType == this.conflictType &&
          other.payloadJson == this.payloadJson &&
          other.serverMessage == this.serverMessage &&
          other.responseJson == this.responseJson &&
          other.status == this.status &&
          other.createdAt == this.createdAt);
}

class SyncConflictsCompanion extends UpdateCompanion<SyncConflict> {
  final Value<String> id;
  final Value<String?> queueItemId;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String?> campusId;
  final Value<String> entityType;
  final Value<String> entityId;
  final Value<String> operation;
  final Value<String> conflictType;
  final Value<String> payloadJson;
  final Value<String?> serverMessage;
  final Value<String?> responseJson;
  final Value<String> status;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const SyncConflictsCompanion({
    this.id = const Value.absent(),
    this.queueItemId = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.campusId = const Value.absent(),
    this.entityType = const Value.absent(),
    this.entityId = const Value.absent(),
    this.operation = const Value.absent(),
    this.conflictType = const Value.absent(),
    this.payloadJson = const Value.absent(),
    this.serverMessage = const Value.absent(),
    this.responseJson = const Value.absent(),
    this.status = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SyncConflictsCompanion.insert({
    required String id,
    this.queueItemId = const Value.absent(),
    required String tenantId,
    required String schoolId,
    this.campusId = const Value.absent(),
    required String entityType,
    required String entityId,
    required String operation,
    required String conflictType,
    required String payloadJson,
    this.serverMessage = const Value.absent(),
    this.responseJson = const Value.absent(),
    this.status = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        entityType = Value(entityType),
        entityId = Value(entityId),
        operation = Value(operation),
        conflictType = Value(conflictType),
        payloadJson = Value(payloadJson);
  static Insertable<SyncConflict> custom({
    Expression<String>? id,
    Expression<String>? queueItemId,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? campusId,
    Expression<String>? entityType,
    Expression<String>? entityId,
    Expression<String>? operation,
    Expression<String>? conflictType,
    Expression<String>? payloadJson,
    Expression<String>? serverMessage,
    Expression<String>? responseJson,
    Expression<String>? status,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (queueItemId != null) 'queue_item_id': queueItemId,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (campusId != null) 'campus_id': campusId,
      if (entityType != null) 'entity_type': entityType,
      if (entityId != null) 'entity_id': entityId,
      if (operation != null) 'operation': operation,
      if (conflictType != null) 'conflict_type': conflictType,
      if (payloadJson != null) 'payload_json': payloadJson,
      if (serverMessage != null) 'server_message': serverMessage,
      if (responseJson != null) 'response_json': responseJson,
      if (status != null) 'status': status,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SyncConflictsCompanion copyWith(
      {Value<String>? id,
      Value<String?>? queueItemId,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String?>? campusId,
      Value<String>? entityType,
      Value<String>? entityId,
      Value<String>? operation,
      Value<String>? conflictType,
      Value<String>? payloadJson,
      Value<String?>? serverMessage,
      Value<String?>? responseJson,
      Value<String>? status,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return SyncConflictsCompanion(
      id: id ?? this.id,
      queueItemId: queueItemId ?? this.queueItemId,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      campusId: campusId ?? this.campusId,
      entityType: entityType ?? this.entityType,
      entityId: entityId ?? this.entityId,
      operation: operation ?? this.operation,
      conflictType: conflictType ?? this.conflictType,
      payloadJson: payloadJson ?? this.payloadJson,
      serverMessage: serverMessage ?? this.serverMessage,
      responseJson: responseJson ?? this.responseJson,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (queueItemId.present) {
      map['queue_item_id'] = Variable<String>(queueItemId.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (campusId.present) {
      map['campus_id'] = Variable<String>(campusId.value);
    }
    if (entityType.present) {
      map['entity_type'] = Variable<String>(entityType.value);
    }
    if (entityId.present) {
      map['entity_id'] = Variable<String>(entityId.value);
    }
    if (operation.present) {
      map['operation'] = Variable<String>(operation.value);
    }
    if (conflictType.present) {
      map['conflict_type'] = Variable<String>(conflictType.value);
    }
    if (payloadJson.present) {
      map['payload_json'] = Variable<String>(payloadJson.value);
    }
    if (serverMessage.present) {
      map['server_message'] = Variable<String>(serverMessage.value);
    }
    if (responseJson.present) {
      map['response_json'] = Variable<String>(responseJson.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SyncConflictsCompanion(')
          ..write('id: $id, ')
          ..write('queueItemId: $queueItemId, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('operation: $operation, ')
          ..write('conflictType: $conflictType, ')
          ..write('payloadJson: $payloadJson, ')
          ..write('serverMessage: $serverMessage, ')
          ..write('responseJson: $responseJson, ')
          ..write('status: $status, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SyncReconciliationRequestsCacheTable
    extends SyncReconciliationRequestsCache
    with
        TableInfo<$SyncReconciliationRequestsCacheTable,
            SyncReconciliationRequestsCacheData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SyncReconciliationRequestsCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _campusIdMeta =
      const VerificationMeta('campusId');
  @override
  late final GeneratedColumn<String> campusId = GeneratedColumn<String>(
      'campus_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _targetDeviceIdMeta =
      const VerificationMeta('targetDeviceId');
  @override
  late final GeneratedColumn<String> targetDeviceId = GeneratedColumn<String>(
      'target_device_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _reasonMeta = const VerificationMeta('reason');
  @override
  late final GeneratedColumn<String> reason = GeneratedColumn<String>(
      'reason', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _requestedAtMeta =
      const VerificationMeta('requestedAt');
  @override
  late final GeneratedColumn<DateTime> requestedAt = GeneratedColumn<DateTime>(
      'requested_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _acknowledgedAtMeta =
      const VerificationMeta('acknowledgedAt');
  @override
  late final GeneratedColumn<DateTime> acknowledgedAt =
      GeneratedColumn<DateTime>('acknowledged_at', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        campusId,
        targetDeviceId,
        reason,
        status,
        requestedAt,
        acknowledgedAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sync_reconciliation_requests_cache';
  @override
  VerificationContext validateIntegrity(
      Insertable<SyncReconciliationRequestsCacheData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('campus_id')) {
      context.handle(_campusIdMeta,
          campusId.isAcceptableOrUnknown(data['campus_id']!, _campusIdMeta));
    }
    if (data.containsKey('target_device_id')) {
      context.handle(
          _targetDeviceIdMeta,
          targetDeviceId.isAcceptableOrUnknown(
              data['target_device_id']!, _targetDeviceIdMeta));
    } else if (isInserting) {
      context.missing(_targetDeviceIdMeta);
    }
    if (data.containsKey('reason')) {
      context.handle(_reasonMeta,
          reason.isAcceptableOrUnknown(data['reason']!, _reasonMeta));
    } else if (isInserting) {
      context.missing(_reasonMeta);
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('requested_at')) {
      context.handle(
          _requestedAtMeta,
          requestedAt.isAcceptableOrUnknown(
              data['requested_at']!, _requestedAtMeta));
    } else if (isInserting) {
      context.missing(_requestedAtMeta);
    }
    if (data.containsKey('acknowledged_at')) {
      context.handle(
          _acknowledgedAtMeta,
          acknowledgedAt.isAcceptableOrUnknown(
              data['acknowledged_at']!, _acknowledgedAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SyncReconciliationRequestsCacheData map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SyncReconciliationRequestsCacheData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      campusId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}campus_id']),
      targetDeviceId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}target_device_id'])!,
      reason: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}reason'])!,
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      requestedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}requested_at'])!,
      acknowledgedAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}acknowledged_at']),
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $SyncReconciliationRequestsCacheTable createAlias(String alias) {
    return $SyncReconciliationRequestsCacheTable(attachedDatabase, alias);
  }
}

class SyncReconciliationRequestsCacheData extends DataClass
    implements Insertable<SyncReconciliationRequestsCacheData> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String? campusId;
  final String targetDeviceId;
  final String reason;
  final String status;
  final DateTime requestedAt;
  final DateTime? acknowledgedAt;
  final DateTime updatedAt;
  const SyncReconciliationRequestsCacheData(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      this.campusId,
      required this.targetDeviceId,
      required this.reason,
      required this.status,
      required this.requestedAt,
      this.acknowledgedAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    if (!nullToAbsent || campusId != null) {
      map['campus_id'] = Variable<String>(campusId);
    }
    map['target_device_id'] = Variable<String>(targetDeviceId);
    map['reason'] = Variable<String>(reason);
    map['status'] = Variable<String>(status);
    map['requested_at'] = Variable<DateTime>(requestedAt);
    if (!nullToAbsent || acknowledgedAt != null) {
      map['acknowledged_at'] = Variable<DateTime>(acknowledgedAt);
    }
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  SyncReconciliationRequestsCacheCompanion toCompanion(bool nullToAbsent) {
    return SyncReconciliationRequestsCacheCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      campusId: campusId == null && nullToAbsent
          ? const Value.absent()
          : Value(campusId),
      targetDeviceId: Value(targetDeviceId),
      reason: Value(reason),
      status: Value(status),
      requestedAt: Value(requestedAt),
      acknowledgedAt: acknowledgedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(acknowledgedAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory SyncReconciliationRequestsCacheData.fromJson(
      Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SyncReconciliationRequestsCacheData(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      campusId: serializer.fromJson<String?>(json['campusId']),
      targetDeviceId: serializer.fromJson<String>(json['targetDeviceId']),
      reason: serializer.fromJson<String>(json['reason']),
      status: serializer.fromJson<String>(json['status']),
      requestedAt: serializer.fromJson<DateTime>(json['requestedAt']),
      acknowledgedAt: serializer.fromJson<DateTime?>(json['acknowledgedAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'campusId': serializer.toJson<String?>(campusId),
      'targetDeviceId': serializer.toJson<String>(targetDeviceId),
      'reason': serializer.toJson<String>(reason),
      'status': serializer.toJson<String>(status),
      'requestedAt': serializer.toJson<DateTime>(requestedAt),
      'acknowledgedAt': serializer.toJson<DateTime?>(acknowledgedAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  SyncReconciliationRequestsCacheData copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          Value<String?> campusId = const Value.absent(),
          String? targetDeviceId,
          String? reason,
          String? status,
          DateTime? requestedAt,
          Value<DateTime?> acknowledgedAt = const Value.absent(),
          DateTime? updatedAt}) =>
      SyncReconciliationRequestsCacheData(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        campusId: campusId.present ? campusId.value : this.campusId,
        targetDeviceId: targetDeviceId ?? this.targetDeviceId,
        reason: reason ?? this.reason,
        status: status ?? this.status,
        requestedAt: requestedAt ?? this.requestedAt,
        acknowledgedAt:
            acknowledgedAt.present ? acknowledgedAt.value : this.acknowledgedAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  SyncReconciliationRequestsCacheData copyWithCompanion(
      SyncReconciliationRequestsCacheCompanion data) {
    return SyncReconciliationRequestsCacheData(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      campusId: data.campusId.present ? data.campusId.value : this.campusId,
      targetDeviceId: data.targetDeviceId.present
          ? data.targetDeviceId.value
          : this.targetDeviceId,
      reason: data.reason.present ? data.reason.value : this.reason,
      status: data.status.present ? data.status.value : this.status,
      requestedAt:
          data.requestedAt.present ? data.requestedAt.value : this.requestedAt,
      acknowledgedAt: data.acknowledgedAt.present
          ? data.acknowledgedAt.value
          : this.acknowledgedAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SyncReconciliationRequestsCacheData(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('targetDeviceId: $targetDeviceId, ')
          ..write('reason: $reason, ')
          ..write('status: $status, ')
          ..write('requestedAt: $requestedAt, ')
          ..write('acknowledgedAt: $acknowledgedAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, tenantId, schoolId, campusId,
      targetDeviceId, reason, status, requestedAt, acknowledgedAt, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SyncReconciliationRequestsCacheData &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.campusId == this.campusId &&
          other.targetDeviceId == this.targetDeviceId &&
          other.reason == this.reason &&
          other.status == this.status &&
          other.requestedAt == this.requestedAt &&
          other.acknowledgedAt == this.acknowledgedAt &&
          other.updatedAt == this.updatedAt);
}

class SyncReconciliationRequestsCacheCompanion
    extends UpdateCompanion<SyncReconciliationRequestsCacheData> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String?> campusId;
  final Value<String> targetDeviceId;
  final Value<String> reason;
  final Value<String> status;
  final Value<DateTime> requestedAt;
  final Value<DateTime?> acknowledgedAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const SyncReconciliationRequestsCacheCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.campusId = const Value.absent(),
    this.targetDeviceId = const Value.absent(),
    this.reason = const Value.absent(),
    this.status = const Value.absent(),
    this.requestedAt = const Value.absent(),
    this.acknowledgedAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SyncReconciliationRequestsCacheCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    this.campusId = const Value.absent(),
    required String targetDeviceId,
    required String reason,
    this.status = const Value.absent(),
    required DateTime requestedAt,
    this.acknowledgedAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        targetDeviceId = Value(targetDeviceId),
        reason = Value(reason),
        requestedAt = Value(requestedAt);
  static Insertable<SyncReconciliationRequestsCacheData> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? campusId,
    Expression<String>? targetDeviceId,
    Expression<String>? reason,
    Expression<String>? status,
    Expression<DateTime>? requestedAt,
    Expression<DateTime>? acknowledgedAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (campusId != null) 'campus_id': campusId,
      if (targetDeviceId != null) 'target_device_id': targetDeviceId,
      if (reason != null) 'reason': reason,
      if (status != null) 'status': status,
      if (requestedAt != null) 'requested_at': requestedAt,
      if (acknowledgedAt != null) 'acknowledged_at': acknowledgedAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SyncReconciliationRequestsCacheCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String?>? campusId,
      Value<String>? targetDeviceId,
      Value<String>? reason,
      Value<String>? status,
      Value<DateTime>? requestedAt,
      Value<DateTime?>? acknowledgedAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return SyncReconciliationRequestsCacheCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      campusId: campusId ?? this.campusId,
      targetDeviceId: targetDeviceId ?? this.targetDeviceId,
      reason: reason ?? this.reason,
      status: status ?? this.status,
      requestedAt: requestedAt ?? this.requestedAt,
      acknowledgedAt: acknowledgedAt ?? this.acknowledgedAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (campusId.present) {
      map['campus_id'] = Variable<String>(campusId.value);
    }
    if (targetDeviceId.present) {
      map['target_device_id'] = Variable<String>(targetDeviceId.value);
    }
    if (reason.present) {
      map['reason'] = Variable<String>(reason.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (requestedAt.present) {
      map['requested_at'] = Variable<DateTime>(requestedAt.value);
    }
    if (acknowledgedAt.present) {
      map['acknowledged_at'] = Variable<DateTime>(acknowledgedAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SyncReconciliationRequestsCacheCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('targetDeviceId: $targetDeviceId, ')
          ..write('reason: $reason, ')
          ..write('status: $status, ')
          ..write('requestedAt: $requestedAt, ')
          ..write('acknowledgedAt: $acknowledgedAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $AcademicYearsCacheTable extends AcademicYearsCache
    with TableInfo<$AcademicYearsCacheTable, AcademicYearsCacheData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AcademicYearsCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _labelMeta = const VerificationMeta('label');
  @override
  late final GeneratedColumn<String> label = GeneratedColumn<String>(
      'label', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _startDateMeta =
      const VerificationMeta('startDate');
  @override
  late final GeneratedColumn<String> startDate = GeneratedColumn<String>(
      'start_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _endDateMeta =
      const VerificationMeta('endDate');
  @override
  late final GeneratedColumn<String> endDate = GeneratedColumn<String>(
      'end_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _isCurrentMeta =
      const VerificationMeta('isCurrent');
  @override
  late final GeneratedColumn<bool> isCurrent = GeneratedColumn<bool>(
      'is_current', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_current" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        label,
        startDate,
        endDate,
        isCurrent,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'academic_years_cache';
  @override
  VerificationContext validateIntegrity(
      Insertable<AcademicYearsCacheData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('label')) {
      context.handle(
          _labelMeta, label.isAcceptableOrUnknown(data['label']!, _labelMeta));
    } else if (isInserting) {
      context.missing(_labelMeta);
    }
    if (data.containsKey('start_date')) {
      context.handle(_startDateMeta,
          startDate.isAcceptableOrUnknown(data['start_date']!, _startDateMeta));
    } else if (isInserting) {
      context.missing(_startDateMeta);
    }
    if (data.containsKey('end_date')) {
      context.handle(_endDateMeta,
          endDate.isAcceptableOrUnknown(data['end_date']!, _endDateMeta));
    } else if (isInserting) {
      context.missing(_endDateMeta);
    }
    if (data.containsKey('is_current')) {
      context.handle(_isCurrentMeta,
          isCurrent.isAcceptableOrUnknown(data['is_current']!, _isCurrentMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  AcademicYearsCacheData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AcademicYearsCacheData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      label: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}label'])!,
      startDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}start_date'])!,
      endDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}end_date'])!,
      isCurrent: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_current'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $AcademicYearsCacheTable createAlias(String alias) {
    return $AcademicYearsCacheTable(attachedDatabase, alias);
  }
}

class AcademicYearsCacheData extends DataClass
    implements Insertable<AcademicYearsCacheData> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String label;
  final String startDate;
  final String endDate;
  final bool isCurrent;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const AcademicYearsCacheData(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      required this.label,
      required this.startDate,
      required this.endDate,
      required this.isCurrent,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    map['label'] = Variable<String>(label);
    map['start_date'] = Variable<String>(startDate);
    map['end_date'] = Variable<String>(endDate);
    map['is_current'] = Variable<bool>(isCurrent);
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  AcademicYearsCacheCompanion toCompanion(bool nullToAbsent) {
    return AcademicYearsCacheCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      label: Value(label),
      startDate: Value(startDate),
      endDate: Value(endDate),
      isCurrent: Value(isCurrent),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory AcademicYearsCacheData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AcademicYearsCacheData(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      label: serializer.fromJson<String>(json['label']),
      startDate: serializer.fromJson<String>(json['startDate']),
      endDate: serializer.fromJson<String>(json['endDate']),
      isCurrent: serializer.fromJson<bool>(json['isCurrent']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'label': serializer.toJson<String>(label),
      'startDate': serializer.toJson<String>(startDate),
      'endDate': serializer.toJson<String>(endDate),
      'isCurrent': serializer.toJson<bool>(isCurrent),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  AcademicYearsCacheData copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          String? label,
          String? startDate,
          String? endDate,
          bool? isCurrent,
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      AcademicYearsCacheData(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        label: label ?? this.label,
        startDate: startDate ?? this.startDate,
        endDate: endDate ?? this.endDate,
        isCurrent: isCurrent ?? this.isCurrent,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  AcademicYearsCacheData copyWithCompanion(AcademicYearsCacheCompanion data) {
    return AcademicYearsCacheData(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      label: data.label.present ? data.label.value : this.label,
      startDate: data.startDate.present ? data.startDate.value : this.startDate,
      endDate: data.endDate.present ? data.endDate.value : this.endDate,
      isCurrent: data.isCurrent.present ? data.isCurrent.value : this.isCurrent,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('AcademicYearsCacheData(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('label: $label, ')
          ..write('startDate: $startDate, ')
          ..write('endDate: $endDate, ')
          ..write('isCurrent: $isCurrent, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, tenantId, schoolId, label, startDate,
      endDate, isCurrent, serverRevision, deleted, createdAt, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AcademicYearsCacheData &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.label == this.label &&
          other.startDate == this.startDate &&
          other.endDate == this.endDate &&
          other.isCurrent == this.isCurrent &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class AcademicYearsCacheCompanion
    extends UpdateCompanion<AcademicYearsCacheData> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String> label;
  final Value<String> startDate;
  final Value<String> endDate;
  final Value<bool> isCurrent;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const AcademicYearsCacheCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.label = const Value.absent(),
    this.startDate = const Value.absent(),
    this.endDate = const Value.absent(),
    this.isCurrent = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  AcademicYearsCacheCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    required String label,
    required String startDate,
    required String endDate,
    this.isCurrent = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        label = Value(label),
        startDate = Value(startDate),
        endDate = Value(endDate);
  static Insertable<AcademicYearsCacheData> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? label,
    Expression<String>? startDate,
    Expression<String>? endDate,
    Expression<bool>? isCurrent,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (label != null) 'label': label,
      if (startDate != null) 'start_date': startDate,
      if (endDate != null) 'end_date': endDate,
      if (isCurrent != null) 'is_current': isCurrent,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  AcademicYearsCacheCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String>? label,
      Value<String>? startDate,
      Value<String>? endDate,
      Value<bool>? isCurrent,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return AcademicYearsCacheCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      label: label ?? this.label,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      isCurrent: isCurrent ?? this.isCurrent,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (label.present) {
      map['label'] = Variable<String>(label.value);
    }
    if (startDate.present) {
      map['start_date'] = Variable<String>(startDate.value);
    }
    if (endDate.present) {
      map['end_date'] = Variable<String>(endDate.value);
    }
    if (isCurrent.present) {
      map['is_current'] = Variable<bool>(isCurrent.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AcademicYearsCacheCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('label: $label, ')
          ..write('startDate: $startDate, ')
          ..write('endDate: $endDate, ')
          ..write('isCurrent: $isCurrent, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $TermsCacheTable extends TermsCache
    with TableInfo<$TermsCacheTable, TermsCacheData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TermsCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _academicYearIdMeta =
      const VerificationMeta('academicYearId');
  @override
  late final GeneratedColumn<String> academicYearId = GeneratedColumn<String>(
      'academic_year_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _termNumberMeta =
      const VerificationMeta('termNumber');
  @override
  late final GeneratedColumn<int> termNumber = GeneratedColumn<int>(
      'term_number', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _startDateMeta =
      const VerificationMeta('startDate');
  @override
  late final GeneratedColumn<String> startDate = GeneratedColumn<String>(
      'start_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _endDateMeta =
      const VerificationMeta('endDate');
  @override
  late final GeneratedColumn<String> endDate = GeneratedColumn<String>(
      'end_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _isCurrentMeta =
      const VerificationMeta('isCurrent');
  @override
  late final GeneratedColumn<bool> isCurrent = GeneratedColumn<bool>(
      'is_current', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_current" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        academicYearId,
        name,
        termNumber,
        startDate,
        endDate,
        isCurrent,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'terms_cache';
  @override
  VerificationContext validateIntegrity(Insertable<TermsCacheData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('academic_year_id')) {
      context.handle(
          _academicYearIdMeta,
          academicYearId.isAcceptableOrUnknown(
              data['academic_year_id']!, _academicYearIdMeta));
    } else if (isInserting) {
      context.missing(_academicYearIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('term_number')) {
      context.handle(
          _termNumberMeta,
          termNumber.isAcceptableOrUnknown(
              data['term_number']!, _termNumberMeta));
    } else if (isInserting) {
      context.missing(_termNumberMeta);
    }
    if (data.containsKey('start_date')) {
      context.handle(_startDateMeta,
          startDate.isAcceptableOrUnknown(data['start_date']!, _startDateMeta));
    } else if (isInserting) {
      context.missing(_startDateMeta);
    }
    if (data.containsKey('end_date')) {
      context.handle(_endDateMeta,
          endDate.isAcceptableOrUnknown(data['end_date']!, _endDateMeta));
    } else if (isInserting) {
      context.missing(_endDateMeta);
    }
    if (data.containsKey('is_current')) {
      context.handle(_isCurrentMeta,
          isCurrent.isAcceptableOrUnknown(data['is_current']!, _isCurrentMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TermsCacheData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TermsCacheData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      academicYearId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}academic_year_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      termNumber: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}term_number'])!,
      startDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}start_date'])!,
      endDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}end_date'])!,
      isCurrent: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_current'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $TermsCacheTable createAlias(String alias) {
    return $TermsCacheTable(attachedDatabase, alias);
  }
}

class TermsCacheData extends DataClass implements Insertable<TermsCacheData> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String academicYearId;
  final String name;
  final int termNumber;
  final String startDate;
  final String endDate;
  final bool isCurrent;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const TermsCacheData(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      required this.academicYearId,
      required this.name,
      required this.termNumber,
      required this.startDate,
      required this.endDate,
      required this.isCurrent,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    map['academic_year_id'] = Variable<String>(academicYearId);
    map['name'] = Variable<String>(name);
    map['term_number'] = Variable<int>(termNumber);
    map['start_date'] = Variable<String>(startDate);
    map['end_date'] = Variable<String>(endDate);
    map['is_current'] = Variable<bool>(isCurrent);
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  TermsCacheCompanion toCompanion(bool nullToAbsent) {
    return TermsCacheCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      academicYearId: Value(academicYearId),
      name: Value(name),
      termNumber: Value(termNumber),
      startDate: Value(startDate),
      endDate: Value(endDate),
      isCurrent: Value(isCurrent),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory TermsCacheData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TermsCacheData(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      academicYearId: serializer.fromJson<String>(json['academicYearId']),
      name: serializer.fromJson<String>(json['name']),
      termNumber: serializer.fromJson<int>(json['termNumber']),
      startDate: serializer.fromJson<String>(json['startDate']),
      endDate: serializer.fromJson<String>(json['endDate']),
      isCurrent: serializer.fromJson<bool>(json['isCurrent']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'academicYearId': serializer.toJson<String>(academicYearId),
      'name': serializer.toJson<String>(name),
      'termNumber': serializer.toJson<int>(termNumber),
      'startDate': serializer.toJson<String>(startDate),
      'endDate': serializer.toJson<String>(endDate),
      'isCurrent': serializer.toJson<bool>(isCurrent),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  TermsCacheData copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          String? academicYearId,
          String? name,
          int? termNumber,
          String? startDate,
          String? endDate,
          bool? isCurrent,
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      TermsCacheData(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        academicYearId: academicYearId ?? this.academicYearId,
        name: name ?? this.name,
        termNumber: termNumber ?? this.termNumber,
        startDate: startDate ?? this.startDate,
        endDate: endDate ?? this.endDate,
        isCurrent: isCurrent ?? this.isCurrent,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  TermsCacheData copyWithCompanion(TermsCacheCompanion data) {
    return TermsCacheData(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      academicYearId: data.academicYearId.present
          ? data.academicYearId.value
          : this.academicYearId,
      name: data.name.present ? data.name.value : this.name,
      termNumber:
          data.termNumber.present ? data.termNumber.value : this.termNumber,
      startDate: data.startDate.present ? data.startDate.value : this.startDate,
      endDate: data.endDate.present ? data.endDate.value : this.endDate,
      isCurrent: data.isCurrent.present ? data.isCurrent.value : this.isCurrent,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TermsCacheData(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('academicYearId: $academicYearId, ')
          ..write('name: $name, ')
          ..write('termNumber: $termNumber, ')
          ..write('startDate: $startDate, ')
          ..write('endDate: $endDate, ')
          ..write('isCurrent: $isCurrent, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      tenantId,
      schoolId,
      academicYearId,
      name,
      termNumber,
      startDate,
      endDate,
      isCurrent,
      serverRevision,
      deleted,
      createdAt,
      updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TermsCacheData &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.academicYearId == this.academicYearId &&
          other.name == this.name &&
          other.termNumber == this.termNumber &&
          other.startDate == this.startDate &&
          other.endDate == this.endDate &&
          other.isCurrent == this.isCurrent &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class TermsCacheCompanion extends UpdateCompanion<TermsCacheData> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String> academicYearId;
  final Value<String> name;
  final Value<int> termNumber;
  final Value<String> startDate;
  final Value<String> endDate;
  final Value<bool> isCurrent;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const TermsCacheCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.academicYearId = const Value.absent(),
    this.name = const Value.absent(),
    this.termNumber = const Value.absent(),
    this.startDate = const Value.absent(),
    this.endDate = const Value.absent(),
    this.isCurrent = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  TermsCacheCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    required String academicYearId,
    required String name,
    required int termNumber,
    required String startDate,
    required String endDate,
    this.isCurrent = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        academicYearId = Value(academicYearId),
        name = Value(name),
        termNumber = Value(termNumber),
        startDate = Value(startDate),
        endDate = Value(endDate);
  static Insertable<TermsCacheData> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? academicYearId,
    Expression<String>? name,
    Expression<int>? termNumber,
    Expression<String>? startDate,
    Expression<String>? endDate,
    Expression<bool>? isCurrent,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (academicYearId != null) 'academic_year_id': academicYearId,
      if (name != null) 'name': name,
      if (termNumber != null) 'term_number': termNumber,
      if (startDate != null) 'start_date': startDate,
      if (endDate != null) 'end_date': endDate,
      if (isCurrent != null) 'is_current': isCurrent,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  TermsCacheCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String>? academicYearId,
      Value<String>? name,
      Value<int>? termNumber,
      Value<String>? startDate,
      Value<String>? endDate,
      Value<bool>? isCurrent,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return TermsCacheCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      academicYearId: academicYearId ?? this.academicYearId,
      name: name ?? this.name,
      termNumber: termNumber ?? this.termNumber,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      isCurrent: isCurrent ?? this.isCurrent,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (academicYearId.present) {
      map['academic_year_id'] = Variable<String>(academicYearId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (termNumber.present) {
      map['term_number'] = Variable<int>(termNumber.value);
    }
    if (startDate.present) {
      map['start_date'] = Variable<String>(startDate.value);
    }
    if (endDate.present) {
      map['end_date'] = Variable<String>(endDate.value);
    }
    if (isCurrent.present) {
      map['is_current'] = Variable<bool>(isCurrent.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TermsCacheCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('academicYearId: $academicYearId, ')
          ..write('name: $name, ')
          ..write('termNumber: $termNumber, ')
          ..write('startDate: $startDate, ')
          ..write('endDate: $endDate, ')
          ..write('isCurrent: $isCurrent, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ClassLevelsCacheTable extends ClassLevelsCache
    with TableInfo<$ClassLevelsCacheTable, ClassLevelsCacheData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ClassLevelsCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _sortOrderMeta =
      const VerificationMeta('sortOrder');
  @override
  late final GeneratedColumn<int> sortOrder = GeneratedColumn<int>(
      'sort_order', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        name,
        sortOrder,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'class_levels_cache';
  @override
  VerificationContext validateIntegrity(
      Insertable<ClassLevelsCacheData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('sort_order')) {
      context.handle(_sortOrderMeta,
          sortOrder.isAcceptableOrUnknown(data['sort_order']!, _sortOrderMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ClassLevelsCacheData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ClassLevelsCacheData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      sortOrder: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}sort_order'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $ClassLevelsCacheTable createAlias(String alias) {
    return $ClassLevelsCacheTable(attachedDatabase, alias);
  }
}

class ClassLevelsCacheData extends DataClass
    implements Insertable<ClassLevelsCacheData> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String name;
  final int sortOrder;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const ClassLevelsCacheData(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      required this.name,
      required this.sortOrder,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    map['name'] = Variable<String>(name);
    map['sort_order'] = Variable<int>(sortOrder);
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  ClassLevelsCacheCompanion toCompanion(bool nullToAbsent) {
    return ClassLevelsCacheCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      name: Value(name),
      sortOrder: Value(sortOrder),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory ClassLevelsCacheData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ClassLevelsCacheData(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      name: serializer.fromJson<String>(json['name']),
      sortOrder: serializer.fromJson<int>(json['sortOrder']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'name': serializer.toJson<String>(name),
      'sortOrder': serializer.toJson<int>(sortOrder),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  ClassLevelsCacheData copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          String? name,
          int? sortOrder,
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      ClassLevelsCacheData(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        name: name ?? this.name,
        sortOrder: sortOrder ?? this.sortOrder,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  ClassLevelsCacheData copyWithCompanion(ClassLevelsCacheCompanion data) {
    return ClassLevelsCacheData(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      name: data.name.present ? data.name.value : this.name,
      sortOrder: data.sortOrder.present ? data.sortOrder.value : this.sortOrder,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ClassLevelsCacheData(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('name: $name, ')
          ..write('sortOrder: $sortOrder, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, tenantId, schoolId, name, sortOrder,
      serverRevision, deleted, createdAt, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ClassLevelsCacheData &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.name == this.name &&
          other.sortOrder == this.sortOrder &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class ClassLevelsCacheCompanion extends UpdateCompanion<ClassLevelsCacheData> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String> name;
  final Value<int> sortOrder;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const ClassLevelsCacheCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.name = const Value.absent(),
    this.sortOrder = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ClassLevelsCacheCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    required String name,
    this.sortOrder = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        name = Value(name);
  static Insertable<ClassLevelsCacheData> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? name,
    Expression<int>? sortOrder,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (name != null) 'name': name,
      if (sortOrder != null) 'sort_order': sortOrder,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ClassLevelsCacheCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String>? name,
      Value<int>? sortOrder,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return ClassLevelsCacheCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      name: name ?? this.name,
      sortOrder: sortOrder ?? this.sortOrder,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (sortOrder.present) {
      map['sort_order'] = Variable<int>(sortOrder.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ClassLevelsCacheCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('name: $name, ')
          ..write('sortOrder: $sortOrder, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ClassArmsCacheTable extends ClassArmsCache
    with TableInfo<$ClassArmsCacheTable, ClassArmsCacheData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ClassArmsCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _classLevelIdMeta =
      const VerificationMeta('classLevelId');
  @override
  late final GeneratedColumn<String> classLevelId = GeneratedColumn<String>(
      'class_level_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _armMeta = const VerificationMeta('arm');
  @override
  late final GeneratedColumn<String> arm = GeneratedColumn<String>(
      'arm', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _displayNameMeta =
      const VerificationMeta('displayName');
  @override
  late final GeneratedColumn<String> displayName = GeneratedColumn<String>(
      'display_name', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        classLevelId,
        arm,
        displayName,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'class_arms_cache';
  @override
  VerificationContext validateIntegrity(Insertable<ClassArmsCacheData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('class_level_id')) {
      context.handle(
          _classLevelIdMeta,
          classLevelId.isAcceptableOrUnknown(
              data['class_level_id']!, _classLevelIdMeta));
    } else if (isInserting) {
      context.missing(_classLevelIdMeta);
    }
    if (data.containsKey('arm')) {
      context.handle(
          _armMeta, arm.isAcceptableOrUnknown(data['arm']!, _armMeta));
    } else if (isInserting) {
      context.missing(_armMeta);
    }
    if (data.containsKey('display_name')) {
      context.handle(
          _displayNameMeta,
          displayName.isAcceptableOrUnknown(
              data['display_name']!, _displayNameMeta));
    } else if (isInserting) {
      context.missing(_displayNameMeta);
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ClassArmsCacheData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ClassArmsCacheData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      classLevelId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}class_level_id'])!,
      arm: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}arm'])!,
      displayName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}display_name'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $ClassArmsCacheTable createAlias(String alias) {
    return $ClassArmsCacheTable(attachedDatabase, alias);
  }
}

class ClassArmsCacheData extends DataClass
    implements Insertable<ClassArmsCacheData> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String classLevelId;
  final String arm;
  final String displayName;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const ClassArmsCacheData(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      required this.classLevelId,
      required this.arm,
      required this.displayName,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    map['class_level_id'] = Variable<String>(classLevelId);
    map['arm'] = Variable<String>(arm);
    map['display_name'] = Variable<String>(displayName);
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  ClassArmsCacheCompanion toCompanion(bool nullToAbsent) {
    return ClassArmsCacheCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      classLevelId: Value(classLevelId),
      arm: Value(arm),
      displayName: Value(displayName),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory ClassArmsCacheData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ClassArmsCacheData(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      classLevelId: serializer.fromJson<String>(json['classLevelId']),
      arm: serializer.fromJson<String>(json['arm']),
      displayName: serializer.fromJson<String>(json['displayName']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'classLevelId': serializer.toJson<String>(classLevelId),
      'arm': serializer.toJson<String>(arm),
      'displayName': serializer.toJson<String>(displayName),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  ClassArmsCacheData copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          String? classLevelId,
          String? arm,
          String? displayName,
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      ClassArmsCacheData(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        classLevelId: classLevelId ?? this.classLevelId,
        arm: arm ?? this.arm,
        displayName: displayName ?? this.displayName,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  ClassArmsCacheData copyWithCompanion(ClassArmsCacheCompanion data) {
    return ClassArmsCacheData(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      classLevelId: data.classLevelId.present
          ? data.classLevelId.value
          : this.classLevelId,
      arm: data.arm.present ? data.arm.value : this.arm,
      displayName:
          data.displayName.present ? data.displayName.value : this.displayName,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ClassArmsCacheData(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('classLevelId: $classLevelId, ')
          ..write('arm: $arm, ')
          ..write('displayName: $displayName, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, tenantId, schoolId, classLevelId, arm,
      displayName, serverRevision, deleted, createdAt, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ClassArmsCacheData &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.classLevelId == this.classLevelId &&
          other.arm == this.arm &&
          other.displayName == this.displayName &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class ClassArmsCacheCompanion extends UpdateCompanion<ClassArmsCacheData> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String> classLevelId;
  final Value<String> arm;
  final Value<String> displayName;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const ClassArmsCacheCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.classLevelId = const Value.absent(),
    this.arm = const Value.absent(),
    this.displayName = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ClassArmsCacheCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    required String classLevelId,
    required String arm,
    required String displayName,
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        classLevelId = Value(classLevelId),
        arm = Value(arm),
        displayName = Value(displayName);
  static Insertable<ClassArmsCacheData> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? classLevelId,
    Expression<String>? arm,
    Expression<String>? displayName,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (classLevelId != null) 'class_level_id': classLevelId,
      if (arm != null) 'arm': arm,
      if (displayName != null) 'display_name': displayName,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ClassArmsCacheCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String>? classLevelId,
      Value<String>? arm,
      Value<String>? displayName,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return ClassArmsCacheCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      classLevelId: classLevelId ?? this.classLevelId,
      arm: arm ?? this.arm,
      displayName: displayName ?? this.displayName,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (classLevelId.present) {
      map['class_level_id'] = Variable<String>(classLevelId.value);
    }
    if (arm.present) {
      map['arm'] = Variable<String>(arm.value);
    }
    if (displayName.present) {
      map['display_name'] = Variable<String>(displayName.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ClassArmsCacheCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('classLevelId: $classLevelId, ')
          ..write('arm: $arm, ')
          ..write('displayName: $displayName, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SubjectsCacheTable extends SubjectsCache
    with TableInfo<$SubjectsCacheTable, SubjectsCacheData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SubjectsCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _codeMeta = const VerificationMeta('code');
  @override
  late final GeneratedColumn<String> code = GeneratedColumn<String>(
      'code', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        name,
        code,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'subjects_cache';
  @override
  VerificationContext validateIntegrity(Insertable<SubjectsCacheData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('code')) {
      context.handle(
          _codeMeta, code.isAcceptableOrUnknown(data['code']!, _codeMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SubjectsCacheData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SubjectsCacheData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      code: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}code']),
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $SubjectsCacheTable createAlias(String alias) {
    return $SubjectsCacheTable(attachedDatabase, alias);
  }
}

class SubjectsCacheData extends DataClass
    implements Insertable<SubjectsCacheData> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String name;
  final String? code;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const SubjectsCacheData(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      required this.name,
      this.code,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || code != null) {
      map['code'] = Variable<String>(code);
    }
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  SubjectsCacheCompanion toCompanion(bool nullToAbsent) {
    return SubjectsCacheCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      name: Value(name),
      code: code == null && nullToAbsent ? const Value.absent() : Value(code),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory SubjectsCacheData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SubjectsCacheData(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      name: serializer.fromJson<String>(json['name']),
      code: serializer.fromJson<String?>(json['code']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'name': serializer.toJson<String>(name),
      'code': serializer.toJson<String?>(code),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  SubjectsCacheData copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          String? name,
          Value<String?> code = const Value.absent(),
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      SubjectsCacheData(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        name: name ?? this.name,
        code: code.present ? code.value : this.code,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  SubjectsCacheData copyWithCompanion(SubjectsCacheCompanion data) {
    return SubjectsCacheData(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      name: data.name.present ? data.name.value : this.name,
      code: data.code.present ? data.code.value : this.code,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SubjectsCacheData(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('name: $name, ')
          ..write('code: $code, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, tenantId, schoolId, name, code,
      serverRevision, deleted, createdAt, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SubjectsCacheData &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.name == this.name &&
          other.code == this.code &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class SubjectsCacheCompanion extends UpdateCompanion<SubjectsCacheData> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String> name;
  final Value<String?> code;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const SubjectsCacheCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.name = const Value.absent(),
    this.code = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SubjectsCacheCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    required String name,
    this.code = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        name = Value(name);
  static Insertable<SubjectsCacheData> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? name,
    Expression<String>? code,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (name != null) 'name': name,
      if (code != null) 'code': code,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SubjectsCacheCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String>? name,
      Value<String?>? code,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return SubjectsCacheCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      name: name ?? this.name,
      code: code ?? this.code,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (code.present) {
      map['code'] = Variable<String>(code.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SubjectsCacheCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('name: $name, ')
          ..write('code: $code, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $GradingSchemesCacheTable extends GradingSchemesCache
    with TableInfo<$GradingSchemesCacheTable, GradingSchemesCacheData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GradingSchemesCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _bandsJsonMeta =
      const VerificationMeta('bandsJson');
  @override
  late final GeneratedColumn<String> bandsJson = GeneratedColumn<String>(
      'bands_json', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _isDefaultMeta =
      const VerificationMeta('isDefault');
  @override
  late final GeneratedColumn<bool> isDefault = GeneratedColumn<bool>(
      'is_default', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_default" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        name,
        bandsJson,
        isDefault,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'grading_schemes_cache';
  @override
  VerificationContext validateIntegrity(
      Insertable<GradingSchemesCacheData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('bands_json')) {
      context.handle(_bandsJsonMeta,
          bandsJson.isAcceptableOrUnknown(data['bands_json']!, _bandsJsonMeta));
    } else if (isInserting) {
      context.missing(_bandsJsonMeta);
    }
    if (data.containsKey('is_default')) {
      context.handle(_isDefaultMeta,
          isDefault.isAcceptableOrUnknown(data['is_default']!, _isDefaultMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GradingSchemesCacheData map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GradingSchemesCacheData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      bandsJson: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bands_json'])!,
      isDefault: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_default'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $GradingSchemesCacheTable createAlias(String alias) {
    return $GradingSchemesCacheTable(attachedDatabase, alias);
  }
}

class GradingSchemesCacheData extends DataClass
    implements Insertable<GradingSchemesCacheData> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String name;
  final String bandsJson;
  final bool isDefault;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const GradingSchemesCacheData(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      required this.name,
      required this.bandsJson,
      required this.isDefault,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    map['name'] = Variable<String>(name);
    map['bands_json'] = Variable<String>(bandsJson);
    map['is_default'] = Variable<bool>(isDefault);
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  GradingSchemesCacheCompanion toCompanion(bool nullToAbsent) {
    return GradingSchemesCacheCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      name: Value(name),
      bandsJson: Value(bandsJson),
      isDefault: Value(isDefault),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory GradingSchemesCacheData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GradingSchemesCacheData(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      name: serializer.fromJson<String>(json['name']),
      bandsJson: serializer.fromJson<String>(json['bandsJson']),
      isDefault: serializer.fromJson<bool>(json['isDefault']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'name': serializer.toJson<String>(name),
      'bandsJson': serializer.toJson<String>(bandsJson),
      'isDefault': serializer.toJson<bool>(isDefault),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  GradingSchemesCacheData copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          String? name,
          String? bandsJson,
          bool? isDefault,
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      GradingSchemesCacheData(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        name: name ?? this.name,
        bandsJson: bandsJson ?? this.bandsJson,
        isDefault: isDefault ?? this.isDefault,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  GradingSchemesCacheData copyWithCompanion(GradingSchemesCacheCompanion data) {
    return GradingSchemesCacheData(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      name: data.name.present ? data.name.value : this.name,
      bandsJson: data.bandsJson.present ? data.bandsJson.value : this.bandsJson,
      isDefault: data.isDefault.present ? data.isDefault.value : this.isDefault,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('GradingSchemesCacheData(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('name: $name, ')
          ..write('bandsJson: $bandsJson, ')
          ..write('isDefault: $isDefault, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, tenantId, schoolId, name, bandsJson,
      isDefault, serverRevision, deleted, createdAt, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GradingSchemesCacheData &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.name == this.name &&
          other.bandsJson == this.bandsJson &&
          other.isDefault == this.isDefault &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class GradingSchemesCacheCompanion
    extends UpdateCompanion<GradingSchemesCacheData> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String> name;
  final Value<String> bandsJson;
  final Value<bool> isDefault;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const GradingSchemesCacheCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.name = const Value.absent(),
    this.bandsJson = const Value.absent(),
    this.isDefault = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  GradingSchemesCacheCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    required String name,
    required String bandsJson,
    this.isDefault = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        name = Value(name),
        bandsJson = Value(bandsJson);
  static Insertable<GradingSchemesCacheData> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? name,
    Expression<String>? bandsJson,
    Expression<bool>? isDefault,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (name != null) 'name': name,
      if (bandsJson != null) 'bands_json': bandsJson,
      if (isDefault != null) 'is_default': isDefault,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  GradingSchemesCacheCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String>? name,
      Value<String>? bandsJson,
      Value<bool>? isDefault,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return GradingSchemesCacheCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      name: name ?? this.name,
      bandsJson: bandsJson ?? this.bandsJson,
      isDefault: isDefault ?? this.isDefault,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (bandsJson.present) {
      map['bands_json'] = Variable<String>(bandsJson.value);
    }
    if (isDefault.present) {
      map['is_default'] = Variable<bool>(isDefault.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GradingSchemesCacheCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('name: $name, ')
          ..write('bandsJson: $bandsJson, ')
          ..write('isDefault: $isDefault, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $FeeCategoriesTable extends FeeCategories
    with TableInfo<$FeeCategoriesTable, FeeCategory> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FeeCategoriesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _billingTermMeta =
      const VerificationMeta('billingTerm');
  @override
  late final GeneratedColumn<String> billingTerm = GeneratedColumn<String>(
      'billing_term', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('per_term'));
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(true));
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        name,
        billingTerm,
        isActive,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fee_categories';
  @override
  VerificationContext validateIntegrity(Insertable<FeeCategory> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('billing_term')) {
      context.handle(
          _billingTermMeta,
          billingTerm.isAcceptableOrUnknown(
              data['billing_term']!, _billingTermMeta));
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FeeCategory map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FeeCategory(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      billingTerm: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}billing_term'])!,
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $FeeCategoriesTable createAlias(String alias) {
    return $FeeCategoriesTable(attachedDatabase, alias);
  }
}

class FeeCategory extends DataClass implements Insertable<FeeCategory> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String name;
  final String billingTerm;
  final bool isActive;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const FeeCategory(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      required this.name,
      required this.billingTerm,
      required this.isActive,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    map['name'] = Variable<String>(name);
    map['billing_term'] = Variable<String>(billingTerm);
    map['is_active'] = Variable<bool>(isActive);
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  FeeCategoriesCompanion toCompanion(bool nullToAbsent) {
    return FeeCategoriesCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      name: Value(name),
      billingTerm: Value(billingTerm),
      isActive: Value(isActive),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory FeeCategory.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FeeCategory(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      name: serializer.fromJson<String>(json['name']),
      billingTerm: serializer.fromJson<String>(json['billingTerm']),
      isActive: serializer.fromJson<bool>(json['isActive']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'name': serializer.toJson<String>(name),
      'billingTerm': serializer.toJson<String>(billingTerm),
      'isActive': serializer.toJson<bool>(isActive),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  FeeCategory copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          String? name,
          String? billingTerm,
          bool? isActive,
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      FeeCategory(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        name: name ?? this.name,
        billingTerm: billingTerm ?? this.billingTerm,
        isActive: isActive ?? this.isActive,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  FeeCategory copyWithCompanion(FeeCategoriesCompanion data) {
    return FeeCategory(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      name: data.name.present ? data.name.value : this.name,
      billingTerm:
          data.billingTerm.present ? data.billingTerm.value : this.billingTerm,
      isActive: data.isActive.present ? data.isActive.value : this.isActive,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FeeCategory(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('name: $name, ')
          ..write('billingTerm: $billingTerm, ')
          ..write('isActive: $isActive, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, tenantId, schoolId, name, billingTerm,
      isActive, serverRevision, deleted, createdAt, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FeeCategory &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.name == this.name &&
          other.billingTerm == this.billingTerm &&
          other.isActive == this.isActive &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class FeeCategoriesCompanion extends UpdateCompanion<FeeCategory> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String> name;
  final Value<String> billingTerm;
  final Value<bool> isActive;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const FeeCategoriesCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.name = const Value.absent(),
    this.billingTerm = const Value.absent(),
    this.isActive = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  FeeCategoriesCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    required String name,
    this.billingTerm = const Value.absent(),
    this.isActive = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        name = Value(name);
  static Insertable<FeeCategory> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? name,
    Expression<String>? billingTerm,
    Expression<bool>? isActive,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (name != null) 'name': name,
      if (billingTerm != null) 'billing_term': billingTerm,
      if (isActive != null) 'is_active': isActive,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  FeeCategoriesCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String>? name,
      Value<String>? billingTerm,
      Value<bool>? isActive,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return FeeCategoriesCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      name: name ?? this.name,
      billingTerm: billingTerm ?? this.billingTerm,
      isActive: isActive ?? this.isActive,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (billingTerm.present) {
      map['billing_term'] = Variable<String>(billingTerm.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FeeCategoriesCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('name: $name, ')
          ..write('billingTerm: $billingTerm, ')
          ..write('isActive: $isActive, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $FeeStructureItemsTable extends FeeStructureItems
    with TableInfo<$FeeStructureItemsTable, FeeStructureItem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FeeStructureItemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _feeCategoryIdMeta =
      const VerificationMeta('feeCategoryId');
  @override
  late final GeneratedColumn<String> feeCategoryId = GeneratedColumn<String>(
      'fee_category_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _classLevelIdMeta =
      const VerificationMeta('classLevelId');
  @override
  late final GeneratedColumn<String> classLevelId = GeneratedColumn<String>(
      'class_level_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _termIdMeta = const VerificationMeta('termId');
  @override
  late final GeneratedColumn<String> termId = GeneratedColumn<String>(
      'term_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _amountMeta = const VerificationMeta('amount');
  @override
  late final GeneratedColumn<double> amount = GeneratedColumn<double>(
      'amount', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _notesMeta = const VerificationMeta('notes');
  @override
  late final GeneratedColumn<String> notes = GeneratedColumn<String>(
      'notes', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        feeCategoryId,
        classLevelId,
        termId,
        amount,
        notes,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fee_structure_items';
  @override
  VerificationContext validateIntegrity(Insertable<FeeStructureItem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('fee_category_id')) {
      context.handle(
          _feeCategoryIdMeta,
          feeCategoryId.isAcceptableOrUnknown(
              data['fee_category_id']!, _feeCategoryIdMeta));
    } else if (isInserting) {
      context.missing(_feeCategoryIdMeta);
    }
    if (data.containsKey('class_level_id')) {
      context.handle(
          _classLevelIdMeta,
          classLevelId.isAcceptableOrUnknown(
              data['class_level_id']!, _classLevelIdMeta));
    }
    if (data.containsKey('term_id')) {
      context.handle(_termIdMeta,
          termId.isAcceptableOrUnknown(data['term_id']!, _termIdMeta));
    }
    if (data.containsKey('amount')) {
      context.handle(_amountMeta,
          amount.isAcceptableOrUnknown(data['amount']!, _amountMeta));
    } else if (isInserting) {
      context.missing(_amountMeta);
    }
    if (data.containsKey('notes')) {
      context.handle(
          _notesMeta, notes.isAcceptableOrUnknown(data['notes']!, _notesMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FeeStructureItem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FeeStructureItem(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      feeCategoryId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}fee_category_id'])!,
      classLevelId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}class_level_id']),
      termId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}term_id']),
      amount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}amount'])!,
      notes: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}notes']),
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $FeeStructureItemsTable createAlias(String alias) {
    return $FeeStructureItemsTable(attachedDatabase, alias);
  }
}

class FeeStructureItem extends DataClass
    implements Insertable<FeeStructureItem> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String feeCategoryId;
  final String? classLevelId;
  final String? termId;
  final double amount;
  final String? notes;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const FeeStructureItem(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      required this.feeCategoryId,
      this.classLevelId,
      this.termId,
      required this.amount,
      this.notes,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    map['fee_category_id'] = Variable<String>(feeCategoryId);
    if (!nullToAbsent || classLevelId != null) {
      map['class_level_id'] = Variable<String>(classLevelId);
    }
    if (!nullToAbsent || termId != null) {
      map['term_id'] = Variable<String>(termId);
    }
    map['amount'] = Variable<double>(amount);
    if (!nullToAbsent || notes != null) {
      map['notes'] = Variable<String>(notes);
    }
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  FeeStructureItemsCompanion toCompanion(bool nullToAbsent) {
    return FeeStructureItemsCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      feeCategoryId: Value(feeCategoryId),
      classLevelId: classLevelId == null && nullToAbsent
          ? const Value.absent()
          : Value(classLevelId),
      termId:
          termId == null && nullToAbsent ? const Value.absent() : Value(termId),
      amount: Value(amount),
      notes:
          notes == null && nullToAbsent ? const Value.absent() : Value(notes),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory FeeStructureItem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FeeStructureItem(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      feeCategoryId: serializer.fromJson<String>(json['feeCategoryId']),
      classLevelId: serializer.fromJson<String?>(json['classLevelId']),
      termId: serializer.fromJson<String?>(json['termId']),
      amount: serializer.fromJson<double>(json['amount']),
      notes: serializer.fromJson<String?>(json['notes']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'feeCategoryId': serializer.toJson<String>(feeCategoryId),
      'classLevelId': serializer.toJson<String?>(classLevelId),
      'termId': serializer.toJson<String?>(termId),
      'amount': serializer.toJson<double>(amount),
      'notes': serializer.toJson<String?>(notes),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  FeeStructureItem copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          String? feeCategoryId,
          Value<String?> classLevelId = const Value.absent(),
          Value<String?> termId = const Value.absent(),
          double? amount,
          Value<String?> notes = const Value.absent(),
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      FeeStructureItem(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        feeCategoryId: feeCategoryId ?? this.feeCategoryId,
        classLevelId:
            classLevelId.present ? classLevelId.value : this.classLevelId,
        termId: termId.present ? termId.value : this.termId,
        amount: amount ?? this.amount,
        notes: notes.present ? notes.value : this.notes,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  FeeStructureItem copyWithCompanion(FeeStructureItemsCompanion data) {
    return FeeStructureItem(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      feeCategoryId: data.feeCategoryId.present
          ? data.feeCategoryId.value
          : this.feeCategoryId,
      classLevelId: data.classLevelId.present
          ? data.classLevelId.value
          : this.classLevelId,
      termId: data.termId.present ? data.termId.value : this.termId,
      amount: data.amount.present ? data.amount.value : this.amount,
      notes: data.notes.present ? data.notes.value : this.notes,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FeeStructureItem(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('feeCategoryId: $feeCategoryId, ')
          ..write('classLevelId: $classLevelId, ')
          ..write('termId: $termId, ')
          ..write('amount: $amount, ')
          ..write('notes: $notes, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      tenantId,
      schoolId,
      feeCategoryId,
      classLevelId,
      termId,
      amount,
      notes,
      serverRevision,
      deleted,
      createdAt,
      updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FeeStructureItem &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.feeCategoryId == this.feeCategoryId &&
          other.classLevelId == this.classLevelId &&
          other.termId == this.termId &&
          other.amount == this.amount &&
          other.notes == this.notes &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class FeeStructureItemsCompanion extends UpdateCompanion<FeeStructureItem> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String> feeCategoryId;
  final Value<String?> classLevelId;
  final Value<String?> termId;
  final Value<double> amount;
  final Value<String?> notes;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const FeeStructureItemsCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.feeCategoryId = const Value.absent(),
    this.classLevelId = const Value.absent(),
    this.termId = const Value.absent(),
    this.amount = const Value.absent(),
    this.notes = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  FeeStructureItemsCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    required String feeCategoryId,
    this.classLevelId = const Value.absent(),
    this.termId = const Value.absent(),
    required double amount,
    this.notes = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        feeCategoryId = Value(feeCategoryId),
        amount = Value(amount);
  static Insertable<FeeStructureItem> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? feeCategoryId,
    Expression<String>? classLevelId,
    Expression<String>? termId,
    Expression<double>? amount,
    Expression<String>? notes,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (feeCategoryId != null) 'fee_category_id': feeCategoryId,
      if (classLevelId != null) 'class_level_id': classLevelId,
      if (termId != null) 'term_id': termId,
      if (amount != null) 'amount': amount,
      if (notes != null) 'notes': notes,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  FeeStructureItemsCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String>? feeCategoryId,
      Value<String?>? classLevelId,
      Value<String?>? termId,
      Value<double>? amount,
      Value<String?>? notes,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return FeeStructureItemsCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      feeCategoryId: feeCategoryId ?? this.feeCategoryId,
      classLevelId: classLevelId ?? this.classLevelId,
      termId: termId ?? this.termId,
      amount: amount ?? this.amount,
      notes: notes ?? this.notes,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (feeCategoryId.present) {
      map['fee_category_id'] = Variable<String>(feeCategoryId.value);
    }
    if (classLevelId.present) {
      map['class_level_id'] = Variable<String>(classLevelId.value);
    }
    if (termId.present) {
      map['term_id'] = Variable<String>(termId.value);
    }
    if (amount.present) {
      map['amount'] = Variable<double>(amount.value);
    }
    if (notes.present) {
      map['notes'] = Variable<String>(notes.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FeeStructureItemsCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('feeCategoryId: $feeCategoryId, ')
          ..write('classLevelId: $classLevelId, ')
          ..write('termId: $termId, ')
          ..write('amount: $amount, ')
          ..write('notes: $notes, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $InvoicesTable extends Invoices with TableInfo<$InvoicesTable, Invoice> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $InvoicesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _campusIdMeta =
      const VerificationMeta('campusId');
  @override
  late final GeneratedColumn<String> campusId = GeneratedColumn<String>(
      'campus_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _studentIdMeta =
      const VerificationMeta('studentId');
  @override
  late final GeneratedColumn<String> studentId = GeneratedColumn<String>(
      'student_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _academicYearIdMeta =
      const VerificationMeta('academicYearId');
  @override
  late final GeneratedColumn<String> academicYearId = GeneratedColumn<String>(
      'academic_year_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _termIdMeta = const VerificationMeta('termId');
  @override
  late final GeneratedColumn<String> termId = GeneratedColumn<String>(
      'term_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _classArmIdMeta =
      const VerificationMeta('classArmId');
  @override
  late final GeneratedColumn<String> classArmId = GeneratedColumn<String>(
      'class_arm_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _invoiceCodeMeta =
      const VerificationMeta('invoiceCode');
  @override
  late final GeneratedColumn<String> invoiceCode = GeneratedColumn<String>(
      'invoice_code', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 64),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('draft'));
  static const VerificationMeta _lineItemsJsonMeta =
      const VerificationMeta('lineItemsJson');
  @override
  late final GeneratedColumn<String> lineItemsJson = GeneratedColumn<String>(
      'line_items_json', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _totalAmountMeta =
      const VerificationMeta('totalAmount');
  @override
  late final GeneratedColumn<double> totalAmount = GeneratedColumn<double>(
      'total_amount', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _generatedByUserIdMeta =
      const VerificationMeta('generatedByUserId');
  @override
  late final GeneratedColumn<String> generatedByUserId =
      GeneratedColumn<String>('generated_by_user_id', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _postedAtMeta =
      const VerificationMeta('postedAt');
  @override
  late final GeneratedColumn<DateTime> postedAt = GeneratedColumn<DateTime>(
      'posted_at', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('synced'));
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        campusId,
        studentId,
        academicYearId,
        termId,
        classArmId,
        invoiceCode,
        status,
        lineItemsJson,
        totalAmount,
        generatedByUserId,
        postedAt,
        syncStatus,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'invoices';
  @override
  VerificationContext validateIntegrity(Insertable<Invoice> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('campus_id')) {
      context.handle(_campusIdMeta,
          campusId.isAcceptableOrUnknown(data['campus_id']!, _campusIdMeta));
    }
    if (data.containsKey('student_id')) {
      context.handle(_studentIdMeta,
          studentId.isAcceptableOrUnknown(data['student_id']!, _studentIdMeta));
    } else if (isInserting) {
      context.missing(_studentIdMeta);
    }
    if (data.containsKey('academic_year_id')) {
      context.handle(
          _academicYearIdMeta,
          academicYearId.isAcceptableOrUnknown(
              data['academic_year_id']!, _academicYearIdMeta));
    } else if (isInserting) {
      context.missing(_academicYearIdMeta);
    }
    if (data.containsKey('term_id')) {
      context.handle(_termIdMeta,
          termId.isAcceptableOrUnknown(data['term_id']!, _termIdMeta));
    } else if (isInserting) {
      context.missing(_termIdMeta);
    }
    if (data.containsKey('class_arm_id')) {
      context.handle(
          _classArmIdMeta,
          classArmId.isAcceptableOrUnknown(
              data['class_arm_id']!, _classArmIdMeta));
    } else if (isInserting) {
      context.missing(_classArmIdMeta);
    }
    if (data.containsKey('invoice_code')) {
      context.handle(
          _invoiceCodeMeta,
          invoiceCode.isAcceptableOrUnknown(
              data['invoice_code']!, _invoiceCodeMeta));
    } else if (isInserting) {
      context.missing(_invoiceCodeMeta);
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('line_items_json')) {
      context.handle(
          _lineItemsJsonMeta,
          lineItemsJson.isAcceptableOrUnknown(
              data['line_items_json']!, _lineItemsJsonMeta));
    } else if (isInserting) {
      context.missing(_lineItemsJsonMeta);
    }
    if (data.containsKey('total_amount')) {
      context.handle(
          _totalAmountMeta,
          totalAmount.isAcceptableOrUnknown(
              data['total_amount']!, _totalAmountMeta));
    } else if (isInserting) {
      context.missing(_totalAmountMeta);
    }
    if (data.containsKey('generated_by_user_id')) {
      context.handle(
          _generatedByUserIdMeta,
          generatedByUserId.isAcceptableOrUnknown(
              data['generated_by_user_id']!, _generatedByUserIdMeta));
    }
    if (data.containsKey('posted_at')) {
      context.handle(_postedAtMeta,
          postedAt.isAcceptableOrUnknown(data['posted_at']!, _postedAtMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Invoice map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Invoice(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      campusId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}campus_id']),
      studentId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}student_id'])!,
      academicYearId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}academic_year_id'])!,
      termId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}term_id'])!,
      classArmId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}class_arm_id'])!,
      invoiceCode: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}invoice_code'])!,
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      lineItemsJson: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}line_items_json'])!,
      totalAmount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}total_amount'])!,
      generatedByUserId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}generated_by_user_id']),
      postedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}posted_at']),
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $InvoicesTable createAlias(String alias) {
    return $InvoicesTable(attachedDatabase, alias);
  }
}

class Invoice extends DataClass implements Insertable<Invoice> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String? campusId;
  final String studentId;
  final String academicYearId;
  final String termId;
  final String classArmId;
  final String invoiceCode;
  final String status;
  final String lineItemsJson;
  final double totalAmount;
  final String? generatedByUserId;
  final DateTime? postedAt;
  final String syncStatus;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const Invoice(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      this.campusId,
      required this.studentId,
      required this.academicYearId,
      required this.termId,
      required this.classArmId,
      required this.invoiceCode,
      required this.status,
      required this.lineItemsJson,
      required this.totalAmount,
      this.generatedByUserId,
      this.postedAt,
      required this.syncStatus,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    if (!nullToAbsent || campusId != null) {
      map['campus_id'] = Variable<String>(campusId);
    }
    map['student_id'] = Variable<String>(studentId);
    map['academic_year_id'] = Variable<String>(academicYearId);
    map['term_id'] = Variable<String>(termId);
    map['class_arm_id'] = Variable<String>(classArmId);
    map['invoice_code'] = Variable<String>(invoiceCode);
    map['status'] = Variable<String>(status);
    map['line_items_json'] = Variable<String>(lineItemsJson);
    map['total_amount'] = Variable<double>(totalAmount);
    if (!nullToAbsent || generatedByUserId != null) {
      map['generated_by_user_id'] = Variable<String>(generatedByUserId);
    }
    if (!nullToAbsent || postedAt != null) {
      map['posted_at'] = Variable<DateTime>(postedAt);
    }
    map['sync_status'] = Variable<String>(syncStatus);
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  InvoicesCompanion toCompanion(bool nullToAbsent) {
    return InvoicesCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      campusId: campusId == null && nullToAbsent
          ? const Value.absent()
          : Value(campusId),
      studentId: Value(studentId),
      academicYearId: Value(academicYearId),
      termId: Value(termId),
      classArmId: Value(classArmId),
      invoiceCode: Value(invoiceCode),
      status: Value(status),
      lineItemsJson: Value(lineItemsJson),
      totalAmount: Value(totalAmount),
      generatedByUserId: generatedByUserId == null && nullToAbsent
          ? const Value.absent()
          : Value(generatedByUserId),
      postedAt: postedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(postedAt),
      syncStatus: Value(syncStatus),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory Invoice.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Invoice(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      campusId: serializer.fromJson<String?>(json['campusId']),
      studentId: serializer.fromJson<String>(json['studentId']),
      academicYearId: serializer.fromJson<String>(json['academicYearId']),
      termId: serializer.fromJson<String>(json['termId']),
      classArmId: serializer.fromJson<String>(json['classArmId']),
      invoiceCode: serializer.fromJson<String>(json['invoiceCode']),
      status: serializer.fromJson<String>(json['status']),
      lineItemsJson: serializer.fromJson<String>(json['lineItemsJson']),
      totalAmount: serializer.fromJson<double>(json['totalAmount']),
      generatedByUserId:
          serializer.fromJson<String?>(json['generatedByUserId']),
      postedAt: serializer.fromJson<DateTime?>(json['postedAt']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'campusId': serializer.toJson<String?>(campusId),
      'studentId': serializer.toJson<String>(studentId),
      'academicYearId': serializer.toJson<String>(academicYearId),
      'termId': serializer.toJson<String>(termId),
      'classArmId': serializer.toJson<String>(classArmId),
      'invoiceCode': serializer.toJson<String>(invoiceCode),
      'status': serializer.toJson<String>(status),
      'lineItemsJson': serializer.toJson<String>(lineItemsJson),
      'totalAmount': serializer.toJson<double>(totalAmount),
      'generatedByUserId': serializer.toJson<String?>(generatedByUserId),
      'postedAt': serializer.toJson<DateTime?>(postedAt),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  Invoice copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          Value<String?> campusId = const Value.absent(),
          String? studentId,
          String? academicYearId,
          String? termId,
          String? classArmId,
          String? invoiceCode,
          String? status,
          String? lineItemsJson,
          double? totalAmount,
          Value<String?> generatedByUserId = const Value.absent(),
          Value<DateTime?> postedAt = const Value.absent(),
          String? syncStatus,
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      Invoice(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        campusId: campusId.present ? campusId.value : this.campusId,
        studentId: studentId ?? this.studentId,
        academicYearId: academicYearId ?? this.academicYearId,
        termId: termId ?? this.termId,
        classArmId: classArmId ?? this.classArmId,
        invoiceCode: invoiceCode ?? this.invoiceCode,
        status: status ?? this.status,
        lineItemsJson: lineItemsJson ?? this.lineItemsJson,
        totalAmount: totalAmount ?? this.totalAmount,
        generatedByUserId: generatedByUserId.present
            ? generatedByUserId.value
            : this.generatedByUserId,
        postedAt: postedAt.present ? postedAt.value : this.postedAt,
        syncStatus: syncStatus ?? this.syncStatus,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  Invoice copyWithCompanion(InvoicesCompanion data) {
    return Invoice(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      campusId: data.campusId.present ? data.campusId.value : this.campusId,
      studentId: data.studentId.present ? data.studentId.value : this.studentId,
      academicYearId: data.academicYearId.present
          ? data.academicYearId.value
          : this.academicYearId,
      termId: data.termId.present ? data.termId.value : this.termId,
      classArmId:
          data.classArmId.present ? data.classArmId.value : this.classArmId,
      invoiceCode:
          data.invoiceCode.present ? data.invoiceCode.value : this.invoiceCode,
      status: data.status.present ? data.status.value : this.status,
      lineItemsJson: data.lineItemsJson.present
          ? data.lineItemsJson.value
          : this.lineItemsJson,
      totalAmount:
          data.totalAmount.present ? data.totalAmount.value : this.totalAmount,
      generatedByUserId: data.generatedByUserId.present
          ? data.generatedByUserId.value
          : this.generatedByUserId,
      postedAt: data.postedAt.present ? data.postedAt.value : this.postedAt,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Invoice(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('studentId: $studentId, ')
          ..write('academicYearId: $academicYearId, ')
          ..write('termId: $termId, ')
          ..write('classArmId: $classArmId, ')
          ..write('invoiceCode: $invoiceCode, ')
          ..write('status: $status, ')
          ..write('lineItemsJson: $lineItemsJson, ')
          ..write('totalAmount: $totalAmount, ')
          ..write('generatedByUserId: $generatedByUserId, ')
          ..write('postedAt: $postedAt, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      tenantId,
      schoolId,
      campusId,
      studentId,
      academicYearId,
      termId,
      classArmId,
      invoiceCode,
      status,
      lineItemsJson,
      totalAmount,
      generatedByUserId,
      postedAt,
      syncStatus,
      serverRevision,
      deleted,
      createdAt,
      updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Invoice &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.campusId == this.campusId &&
          other.studentId == this.studentId &&
          other.academicYearId == this.academicYearId &&
          other.termId == this.termId &&
          other.classArmId == this.classArmId &&
          other.invoiceCode == this.invoiceCode &&
          other.status == this.status &&
          other.lineItemsJson == this.lineItemsJson &&
          other.totalAmount == this.totalAmount &&
          other.generatedByUserId == this.generatedByUserId &&
          other.postedAt == this.postedAt &&
          other.syncStatus == this.syncStatus &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class InvoicesCompanion extends UpdateCompanion<Invoice> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String?> campusId;
  final Value<String> studentId;
  final Value<String> academicYearId;
  final Value<String> termId;
  final Value<String> classArmId;
  final Value<String> invoiceCode;
  final Value<String> status;
  final Value<String> lineItemsJson;
  final Value<double> totalAmount;
  final Value<String?> generatedByUserId;
  final Value<DateTime?> postedAt;
  final Value<String> syncStatus;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const InvoicesCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.campusId = const Value.absent(),
    this.studentId = const Value.absent(),
    this.academicYearId = const Value.absent(),
    this.termId = const Value.absent(),
    this.classArmId = const Value.absent(),
    this.invoiceCode = const Value.absent(),
    this.status = const Value.absent(),
    this.lineItemsJson = const Value.absent(),
    this.totalAmount = const Value.absent(),
    this.generatedByUserId = const Value.absent(),
    this.postedAt = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  InvoicesCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    this.campusId = const Value.absent(),
    required String studentId,
    required String academicYearId,
    required String termId,
    required String classArmId,
    required String invoiceCode,
    this.status = const Value.absent(),
    required String lineItemsJson,
    required double totalAmount,
    this.generatedByUserId = const Value.absent(),
    this.postedAt = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        studentId = Value(studentId),
        academicYearId = Value(academicYearId),
        termId = Value(termId),
        classArmId = Value(classArmId),
        invoiceCode = Value(invoiceCode),
        lineItemsJson = Value(lineItemsJson),
        totalAmount = Value(totalAmount);
  static Insertable<Invoice> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? campusId,
    Expression<String>? studentId,
    Expression<String>? academicYearId,
    Expression<String>? termId,
    Expression<String>? classArmId,
    Expression<String>? invoiceCode,
    Expression<String>? status,
    Expression<String>? lineItemsJson,
    Expression<double>? totalAmount,
    Expression<String>? generatedByUserId,
    Expression<DateTime>? postedAt,
    Expression<String>? syncStatus,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (campusId != null) 'campus_id': campusId,
      if (studentId != null) 'student_id': studentId,
      if (academicYearId != null) 'academic_year_id': academicYearId,
      if (termId != null) 'term_id': termId,
      if (classArmId != null) 'class_arm_id': classArmId,
      if (invoiceCode != null) 'invoice_code': invoiceCode,
      if (status != null) 'status': status,
      if (lineItemsJson != null) 'line_items_json': lineItemsJson,
      if (totalAmount != null) 'total_amount': totalAmount,
      if (generatedByUserId != null) 'generated_by_user_id': generatedByUserId,
      if (postedAt != null) 'posted_at': postedAt,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  InvoicesCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String?>? campusId,
      Value<String>? studentId,
      Value<String>? academicYearId,
      Value<String>? termId,
      Value<String>? classArmId,
      Value<String>? invoiceCode,
      Value<String>? status,
      Value<String>? lineItemsJson,
      Value<double>? totalAmount,
      Value<String?>? generatedByUserId,
      Value<DateTime?>? postedAt,
      Value<String>? syncStatus,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return InvoicesCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      campusId: campusId ?? this.campusId,
      studentId: studentId ?? this.studentId,
      academicYearId: academicYearId ?? this.academicYearId,
      termId: termId ?? this.termId,
      classArmId: classArmId ?? this.classArmId,
      invoiceCode: invoiceCode ?? this.invoiceCode,
      status: status ?? this.status,
      lineItemsJson: lineItemsJson ?? this.lineItemsJson,
      totalAmount: totalAmount ?? this.totalAmount,
      generatedByUserId: generatedByUserId ?? this.generatedByUserId,
      postedAt: postedAt ?? this.postedAt,
      syncStatus: syncStatus ?? this.syncStatus,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (campusId.present) {
      map['campus_id'] = Variable<String>(campusId.value);
    }
    if (studentId.present) {
      map['student_id'] = Variable<String>(studentId.value);
    }
    if (academicYearId.present) {
      map['academic_year_id'] = Variable<String>(academicYearId.value);
    }
    if (termId.present) {
      map['term_id'] = Variable<String>(termId.value);
    }
    if (classArmId.present) {
      map['class_arm_id'] = Variable<String>(classArmId.value);
    }
    if (invoiceCode.present) {
      map['invoice_code'] = Variable<String>(invoiceCode.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (lineItemsJson.present) {
      map['line_items_json'] = Variable<String>(lineItemsJson.value);
    }
    if (totalAmount.present) {
      map['total_amount'] = Variable<double>(totalAmount.value);
    }
    if (generatedByUserId.present) {
      map['generated_by_user_id'] = Variable<String>(generatedByUserId.value);
    }
    if (postedAt.present) {
      map['posted_at'] = Variable<DateTime>(postedAt.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('InvoicesCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('studentId: $studentId, ')
          ..write('academicYearId: $academicYearId, ')
          ..write('termId: $termId, ')
          ..write('classArmId: $classArmId, ')
          ..write('invoiceCode: $invoiceCode, ')
          ..write('status: $status, ')
          ..write('lineItemsJson: $lineItemsJson, ')
          ..write('totalAmount: $totalAmount, ')
          ..write('generatedByUserId: $generatedByUserId, ')
          ..write('postedAt: $postedAt, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $PaymentsTable extends Payments with TableInfo<$PaymentsTable, Payment> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PaymentsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _campusIdMeta =
      const VerificationMeta('campusId');
  @override
  late final GeneratedColumn<String> campusId = GeneratedColumn<String>(
      'campus_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _invoiceIdMeta =
      const VerificationMeta('invoiceId');
  @override
  late final GeneratedColumn<String> invoiceId = GeneratedColumn<String>(
      'invoice_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _paymentCodeMeta =
      const VerificationMeta('paymentCode');
  @override
  late final GeneratedColumn<String> paymentCode = GeneratedColumn<String>(
      'payment_code', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 64),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('draft'));
  static const VerificationMeta _amountMeta = const VerificationMeta('amount');
  @override
  late final GeneratedColumn<double> amount = GeneratedColumn<double>(
      'amount', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _paymentModeMeta =
      const VerificationMeta('paymentMode');
  @override
  late final GeneratedColumn<String> paymentMode = GeneratedColumn<String>(
      'payment_mode', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 32),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _paymentDateMeta =
      const VerificationMeta('paymentDate');
  @override
  late final GeneratedColumn<String> paymentDate = GeneratedColumn<String>(
      'payment_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _referenceMeta =
      const VerificationMeta('reference');
  @override
  late final GeneratedColumn<String> reference = GeneratedColumn<String>(
      'reference', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _notesMeta = const VerificationMeta('notes');
  @override
  late final GeneratedColumn<String> notes = GeneratedColumn<String>(
      'notes', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _receivedByUserIdMeta =
      const VerificationMeta('receivedByUserId');
  @override
  late final GeneratedColumn<String> receivedByUserId = GeneratedColumn<String>(
      'received_by_user_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _postedAtMeta =
      const VerificationMeta('postedAt');
  @override
  late final GeneratedColumn<DateTime> postedAt = GeneratedColumn<DateTime>(
      'posted_at', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('synced'));
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        campusId,
        invoiceId,
        paymentCode,
        status,
        amount,
        paymentMode,
        paymentDate,
        reference,
        notes,
        receivedByUserId,
        postedAt,
        syncStatus,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'payments';
  @override
  VerificationContext validateIntegrity(Insertable<Payment> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('campus_id')) {
      context.handle(_campusIdMeta,
          campusId.isAcceptableOrUnknown(data['campus_id']!, _campusIdMeta));
    }
    if (data.containsKey('invoice_id')) {
      context.handle(_invoiceIdMeta,
          invoiceId.isAcceptableOrUnknown(data['invoice_id']!, _invoiceIdMeta));
    } else if (isInserting) {
      context.missing(_invoiceIdMeta);
    }
    if (data.containsKey('payment_code')) {
      context.handle(
          _paymentCodeMeta,
          paymentCode.isAcceptableOrUnknown(
              data['payment_code']!, _paymentCodeMeta));
    } else if (isInserting) {
      context.missing(_paymentCodeMeta);
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('amount')) {
      context.handle(_amountMeta,
          amount.isAcceptableOrUnknown(data['amount']!, _amountMeta));
    } else if (isInserting) {
      context.missing(_amountMeta);
    }
    if (data.containsKey('payment_mode')) {
      context.handle(
          _paymentModeMeta,
          paymentMode.isAcceptableOrUnknown(
              data['payment_mode']!, _paymentModeMeta));
    } else if (isInserting) {
      context.missing(_paymentModeMeta);
    }
    if (data.containsKey('payment_date')) {
      context.handle(
          _paymentDateMeta,
          paymentDate.isAcceptableOrUnknown(
              data['payment_date']!, _paymentDateMeta));
    } else if (isInserting) {
      context.missing(_paymentDateMeta);
    }
    if (data.containsKey('reference')) {
      context.handle(_referenceMeta,
          reference.isAcceptableOrUnknown(data['reference']!, _referenceMeta));
    }
    if (data.containsKey('notes')) {
      context.handle(
          _notesMeta, notes.isAcceptableOrUnknown(data['notes']!, _notesMeta));
    }
    if (data.containsKey('received_by_user_id')) {
      context.handle(
          _receivedByUserIdMeta,
          receivedByUserId.isAcceptableOrUnknown(
              data['received_by_user_id']!, _receivedByUserIdMeta));
    }
    if (data.containsKey('posted_at')) {
      context.handle(_postedAtMeta,
          postedAt.isAcceptableOrUnknown(data['posted_at']!, _postedAtMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Payment map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Payment(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      campusId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}campus_id']),
      invoiceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}invoice_id'])!,
      paymentCode: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payment_code'])!,
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      amount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}amount'])!,
      paymentMode: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payment_mode'])!,
      paymentDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payment_date'])!,
      reference: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}reference']),
      notes: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}notes']),
      receivedByUserId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}received_by_user_id']),
      postedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}posted_at']),
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $PaymentsTable createAlias(String alias) {
    return $PaymentsTable(attachedDatabase, alias);
  }
}

class Payment extends DataClass implements Insertable<Payment> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String? campusId;
  final String invoiceId;
  final String paymentCode;
  final String status;
  final double amount;
  final String paymentMode;
  final String paymentDate;
  final String? reference;
  final String? notes;
  final String? receivedByUserId;
  final DateTime? postedAt;
  final String syncStatus;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const Payment(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      this.campusId,
      required this.invoiceId,
      required this.paymentCode,
      required this.status,
      required this.amount,
      required this.paymentMode,
      required this.paymentDate,
      this.reference,
      this.notes,
      this.receivedByUserId,
      this.postedAt,
      required this.syncStatus,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    if (!nullToAbsent || campusId != null) {
      map['campus_id'] = Variable<String>(campusId);
    }
    map['invoice_id'] = Variable<String>(invoiceId);
    map['payment_code'] = Variable<String>(paymentCode);
    map['status'] = Variable<String>(status);
    map['amount'] = Variable<double>(amount);
    map['payment_mode'] = Variable<String>(paymentMode);
    map['payment_date'] = Variable<String>(paymentDate);
    if (!nullToAbsent || reference != null) {
      map['reference'] = Variable<String>(reference);
    }
    if (!nullToAbsent || notes != null) {
      map['notes'] = Variable<String>(notes);
    }
    if (!nullToAbsent || receivedByUserId != null) {
      map['received_by_user_id'] = Variable<String>(receivedByUserId);
    }
    if (!nullToAbsent || postedAt != null) {
      map['posted_at'] = Variable<DateTime>(postedAt);
    }
    map['sync_status'] = Variable<String>(syncStatus);
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  PaymentsCompanion toCompanion(bool nullToAbsent) {
    return PaymentsCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      campusId: campusId == null && nullToAbsent
          ? const Value.absent()
          : Value(campusId),
      invoiceId: Value(invoiceId),
      paymentCode: Value(paymentCode),
      status: Value(status),
      amount: Value(amount),
      paymentMode: Value(paymentMode),
      paymentDate: Value(paymentDate),
      reference: reference == null && nullToAbsent
          ? const Value.absent()
          : Value(reference),
      notes:
          notes == null && nullToAbsent ? const Value.absent() : Value(notes),
      receivedByUserId: receivedByUserId == null && nullToAbsent
          ? const Value.absent()
          : Value(receivedByUserId),
      postedAt: postedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(postedAt),
      syncStatus: Value(syncStatus),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory Payment.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Payment(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      campusId: serializer.fromJson<String?>(json['campusId']),
      invoiceId: serializer.fromJson<String>(json['invoiceId']),
      paymentCode: serializer.fromJson<String>(json['paymentCode']),
      status: serializer.fromJson<String>(json['status']),
      amount: serializer.fromJson<double>(json['amount']),
      paymentMode: serializer.fromJson<String>(json['paymentMode']),
      paymentDate: serializer.fromJson<String>(json['paymentDate']),
      reference: serializer.fromJson<String?>(json['reference']),
      notes: serializer.fromJson<String?>(json['notes']),
      receivedByUserId: serializer.fromJson<String?>(json['receivedByUserId']),
      postedAt: serializer.fromJson<DateTime?>(json['postedAt']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'campusId': serializer.toJson<String?>(campusId),
      'invoiceId': serializer.toJson<String>(invoiceId),
      'paymentCode': serializer.toJson<String>(paymentCode),
      'status': serializer.toJson<String>(status),
      'amount': serializer.toJson<double>(amount),
      'paymentMode': serializer.toJson<String>(paymentMode),
      'paymentDate': serializer.toJson<String>(paymentDate),
      'reference': serializer.toJson<String?>(reference),
      'notes': serializer.toJson<String?>(notes),
      'receivedByUserId': serializer.toJson<String?>(receivedByUserId),
      'postedAt': serializer.toJson<DateTime?>(postedAt),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  Payment copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          Value<String?> campusId = const Value.absent(),
          String? invoiceId,
          String? paymentCode,
          String? status,
          double? amount,
          String? paymentMode,
          String? paymentDate,
          Value<String?> reference = const Value.absent(),
          Value<String?> notes = const Value.absent(),
          Value<String?> receivedByUserId = const Value.absent(),
          Value<DateTime?> postedAt = const Value.absent(),
          String? syncStatus,
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      Payment(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        campusId: campusId.present ? campusId.value : this.campusId,
        invoiceId: invoiceId ?? this.invoiceId,
        paymentCode: paymentCode ?? this.paymentCode,
        status: status ?? this.status,
        amount: amount ?? this.amount,
        paymentMode: paymentMode ?? this.paymentMode,
        paymentDate: paymentDate ?? this.paymentDate,
        reference: reference.present ? reference.value : this.reference,
        notes: notes.present ? notes.value : this.notes,
        receivedByUserId: receivedByUserId.present
            ? receivedByUserId.value
            : this.receivedByUserId,
        postedAt: postedAt.present ? postedAt.value : this.postedAt,
        syncStatus: syncStatus ?? this.syncStatus,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  Payment copyWithCompanion(PaymentsCompanion data) {
    return Payment(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      campusId: data.campusId.present ? data.campusId.value : this.campusId,
      invoiceId: data.invoiceId.present ? data.invoiceId.value : this.invoiceId,
      paymentCode:
          data.paymentCode.present ? data.paymentCode.value : this.paymentCode,
      status: data.status.present ? data.status.value : this.status,
      amount: data.amount.present ? data.amount.value : this.amount,
      paymentMode:
          data.paymentMode.present ? data.paymentMode.value : this.paymentMode,
      paymentDate:
          data.paymentDate.present ? data.paymentDate.value : this.paymentDate,
      reference: data.reference.present ? data.reference.value : this.reference,
      notes: data.notes.present ? data.notes.value : this.notes,
      receivedByUserId: data.receivedByUserId.present
          ? data.receivedByUserId.value
          : this.receivedByUserId,
      postedAt: data.postedAt.present ? data.postedAt.value : this.postedAt,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Payment(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('invoiceId: $invoiceId, ')
          ..write('paymentCode: $paymentCode, ')
          ..write('status: $status, ')
          ..write('amount: $amount, ')
          ..write('paymentMode: $paymentMode, ')
          ..write('paymentDate: $paymentDate, ')
          ..write('reference: $reference, ')
          ..write('notes: $notes, ')
          ..write('receivedByUserId: $receivedByUserId, ')
          ..write('postedAt: $postedAt, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      tenantId,
      schoolId,
      campusId,
      invoiceId,
      paymentCode,
      status,
      amount,
      paymentMode,
      paymentDate,
      reference,
      notes,
      receivedByUserId,
      postedAt,
      syncStatus,
      serverRevision,
      deleted,
      createdAt,
      updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Payment &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.campusId == this.campusId &&
          other.invoiceId == this.invoiceId &&
          other.paymentCode == this.paymentCode &&
          other.status == this.status &&
          other.amount == this.amount &&
          other.paymentMode == this.paymentMode &&
          other.paymentDate == this.paymentDate &&
          other.reference == this.reference &&
          other.notes == this.notes &&
          other.receivedByUserId == this.receivedByUserId &&
          other.postedAt == this.postedAt &&
          other.syncStatus == this.syncStatus &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class PaymentsCompanion extends UpdateCompanion<Payment> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String?> campusId;
  final Value<String> invoiceId;
  final Value<String> paymentCode;
  final Value<String> status;
  final Value<double> amount;
  final Value<String> paymentMode;
  final Value<String> paymentDate;
  final Value<String?> reference;
  final Value<String?> notes;
  final Value<String?> receivedByUserId;
  final Value<DateTime?> postedAt;
  final Value<String> syncStatus;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const PaymentsCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.campusId = const Value.absent(),
    this.invoiceId = const Value.absent(),
    this.paymentCode = const Value.absent(),
    this.status = const Value.absent(),
    this.amount = const Value.absent(),
    this.paymentMode = const Value.absent(),
    this.paymentDate = const Value.absent(),
    this.reference = const Value.absent(),
    this.notes = const Value.absent(),
    this.receivedByUserId = const Value.absent(),
    this.postedAt = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  PaymentsCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    this.campusId = const Value.absent(),
    required String invoiceId,
    required String paymentCode,
    this.status = const Value.absent(),
    required double amount,
    required String paymentMode,
    required String paymentDate,
    this.reference = const Value.absent(),
    this.notes = const Value.absent(),
    this.receivedByUserId = const Value.absent(),
    this.postedAt = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        invoiceId = Value(invoiceId),
        paymentCode = Value(paymentCode),
        amount = Value(amount),
        paymentMode = Value(paymentMode),
        paymentDate = Value(paymentDate);
  static Insertable<Payment> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? campusId,
    Expression<String>? invoiceId,
    Expression<String>? paymentCode,
    Expression<String>? status,
    Expression<double>? amount,
    Expression<String>? paymentMode,
    Expression<String>? paymentDate,
    Expression<String>? reference,
    Expression<String>? notes,
    Expression<String>? receivedByUserId,
    Expression<DateTime>? postedAt,
    Expression<String>? syncStatus,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (campusId != null) 'campus_id': campusId,
      if (invoiceId != null) 'invoice_id': invoiceId,
      if (paymentCode != null) 'payment_code': paymentCode,
      if (status != null) 'status': status,
      if (amount != null) 'amount': amount,
      if (paymentMode != null) 'payment_mode': paymentMode,
      if (paymentDate != null) 'payment_date': paymentDate,
      if (reference != null) 'reference': reference,
      if (notes != null) 'notes': notes,
      if (receivedByUserId != null) 'received_by_user_id': receivedByUserId,
      if (postedAt != null) 'posted_at': postedAt,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  PaymentsCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String?>? campusId,
      Value<String>? invoiceId,
      Value<String>? paymentCode,
      Value<String>? status,
      Value<double>? amount,
      Value<String>? paymentMode,
      Value<String>? paymentDate,
      Value<String?>? reference,
      Value<String?>? notes,
      Value<String?>? receivedByUserId,
      Value<DateTime?>? postedAt,
      Value<String>? syncStatus,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return PaymentsCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      campusId: campusId ?? this.campusId,
      invoiceId: invoiceId ?? this.invoiceId,
      paymentCode: paymentCode ?? this.paymentCode,
      status: status ?? this.status,
      amount: amount ?? this.amount,
      paymentMode: paymentMode ?? this.paymentMode,
      paymentDate: paymentDate ?? this.paymentDate,
      reference: reference ?? this.reference,
      notes: notes ?? this.notes,
      receivedByUserId: receivedByUserId ?? this.receivedByUserId,
      postedAt: postedAt ?? this.postedAt,
      syncStatus: syncStatus ?? this.syncStatus,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (campusId.present) {
      map['campus_id'] = Variable<String>(campusId.value);
    }
    if (invoiceId.present) {
      map['invoice_id'] = Variable<String>(invoiceId.value);
    }
    if (paymentCode.present) {
      map['payment_code'] = Variable<String>(paymentCode.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (amount.present) {
      map['amount'] = Variable<double>(amount.value);
    }
    if (paymentMode.present) {
      map['payment_mode'] = Variable<String>(paymentMode.value);
    }
    if (paymentDate.present) {
      map['payment_date'] = Variable<String>(paymentDate.value);
    }
    if (reference.present) {
      map['reference'] = Variable<String>(reference.value);
    }
    if (notes.present) {
      map['notes'] = Variable<String>(notes.value);
    }
    if (receivedByUserId.present) {
      map['received_by_user_id'] = Variable<String>(receivedByUserId.value);
    }
    if (postedAt.present) {
      map['posted_at'] = Variable<DateTime>(postedAt.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PaymentsCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('invoiceId: $invoiceId, ')
          ..write('paymentCode: $paymentCode, ')
          ..write('status: $status, ')
          ..write('amount: $amount, ')
          ..write('paymentMode: $paymentMode, ')
          ..write('paymentDate: $paymentDate, ')
          ..write('reference: $reference, ')
          ..write('notes: $notes, ')
          ..write('receivedByUserId: $receivedByUserId, ')
          ..write('postedAt: $postedAt, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $PaymentReversalsTable extends PaymentReversals
    with TableInfo<$PaymentReversalsTable, PaymentReversal> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PaymentReversalsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _campusIdMeta =
      const VerificationMeta('campusId');
  @override
  late final GeneratedColumn<String> campusId = GeneratedColumn<String>(
      'campus_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _paymentIdMeta =
      const VerificationMeta('paymentId');
  @override
  late final GeneratedColumn<String> paymentId = GeneratedColumn<String>(
      'payment_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _invoiceIdMeta =
      const VerificationMeta('invoiceId');
  @override
  late final GeneratedColumn<String> invoiceId = GeneratedColumn<String>(
      'invoice_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _amountMeta = const VerificationMeta('amount');
  @override
  late final GeneratedColumn<double> amount = GeneratedColumn<double>(
      'amount', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _reasonMeta = const VerificationMeta('reason');
  @override
  late final GeneratedColumn<String> reason = GeneratedColumn<String>(
      'reason', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 500),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _reversedByUserIdMeta =
      const VerificationMeta('reversedByUserId');
  @override
  late final GeneratedColumn<String> reversedByUserId = GeneratedColumn<String>(
      'reversed_by_user_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('synced'));
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        campusId,
        paymentId,
        invoiceId,
        amount,
        reason,
        reversedByUserId,
        syncStatus,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'payment_reversals';
  @override
  VerificationContext validateIntegrity(Insertable<PaymentReversal> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('campus_id')) {
      context.handle(_campusIdMeta,
          campusId.isAcceptableOrUnknown(data['campus_id']!, _campusIdMeta));
    }
    if (data.containsKey('payment_id')) {
      context.handle(_paymentIdMeta,
          paymentId.isAcceptableOrUnknown(data['payment_id']!, _paymentIdMeta));
    } else if (isInserting) {
      context.missing(_paymentIdMeta);
    }
    if (data.containsKey('invoice_id')) {
      context.handle(_invoiceIdMeta,
          invoiceId.isAcceptableOrUnknown(data['invoice_id']!, _invoiceIdMeta));
    } else if (isInserting) {
      context.missing(_invoiceIdMeta);
    }
    if (data.containsKey('amount')) {
      context.handle(_amountMeta,
          amount.isAcceptableOrUnknown(data['amount']!, _amountMeta));
    } else if (isInserting) {
      context.missing(_amountMeta);
    }
    if (data.containsKey('reason')) {
      context.handle(_reasonMeta,
          reason.isAcceptableOrUnknown(data['reason']!, _reasonMeta));
    } else if (isInserting) {
      context.missing(_reasonMeta);
    }
    if (data.containsKey('reversed_by_user_id')) {
      context.handle(
          _reversedByUserIdMeta,
          reversedByUserId.isAcceptableOrUnknown(
              data['reversed_by_user_id']!, _reversedByUserIdMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PaymentReversal map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PaymentReversal(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      campusId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}campus_id']),
      paymentId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payment_id'])!,
      invoiceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}invoice_id'])!,
      amount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}amount'])!,
      reason: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}reason'])!,
      reversedByUserId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}reversed_by_user_id']),
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $PaymentReversalsTable createAlias(String alias) {
    return $PaymentReversalsTable(attachedDatabase, alias);
  }
}

class PaymentReversal extends DataClass implements Insertable<PaymentReversal> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String? campusId;
  final String paymentId;
  final String invoiceId;
  final double amount;
  final String reason;
  final String? reversedByUserId;
  final String syncStatus;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const PaymentReversal(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      this.campusId,
      required this.paymentId,
      required this.invoiceId,
      required this.amount,
      required this.reason,
      this.reversedByUserId,
      required this.syncStatus,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    if (!nullToAbsent || campusId != null) {
      map['campus_id'] = Variable<String>(campusId);
    }
    map['payment_id'] = Variable<String>(paymentId);
    map['invoice_id'] = Variable<String>(invoiceId);
    map['amount'] = Variable<double>(amount);
    map['reason'] = Variable<String>(reason);
    if (!nullToAbsent || reversedByUserId != null) {
      map['reversed_by_user_id'] = Variable<String>(reversedByUserId);
    }
    map['sync_status'] = Variable<String>(syncStatus);
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  PaymentReversalsCompanion toCompanion(bool nullToAbsent) {
    return PaymentReversalsCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      campusId: campusId == null && nullToAbsent
          ? const Value.absent()
          : Value(campusId),
      paymentId: Value(paymentId),
      invoiceId: Value(invoiceId),
      amount: Value(amount),
      reason: Value(reason),
      reversedByUserId: reversedByUserId == null && nullToAbsent
          ? const Value.absent()
          : Value(reversedByUserId),
      syncStatus: Value(syncStatus),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory PaymentReversal.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PaymentReversal(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      campusId: serializer.fromJson<String?>(json['campusId']),
      paymentId: serializer.fromJson<String>(json['paymentId']),
      invoiceId: serializer.fromJson<String>(json['invoiceId']),
      amount: serializer.fromJson<double>(json['amount']),
      reason: serializer.fromJson<String>(json['reason']),
      reversedByUserId: serializer.fromJson<String?>(json['reversedByUserId']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'campusId': serializer.toJson<String?>(campusId),
      'paymentId': serializer.toJson<String>(paymentId),
      'invoiceId': serializer.toJson<String>(invoiceId),
      'amount': serializer.toJson<double>(amount),
      'reason': serializer.toJson<String>(reason),
      'reversedByUserId': serializer.toJson<String?>(reversedByUserId),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  PaymentReversal copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          Value<String?> campusId = const Value.absent(),
          String? paymentId,
          String? invoiceId,
          double? amount,
          String? reason,
          Value<String?> reversedByUserId = const Value.absent(),
          String? syncStatus,
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      PaymentReversal(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        campusId: campusId.present ? campusId.value : this.campusId,
        paymentId: paymentId ?? this.paymentId,
        invoiceId: invoiceId ?? this.invoiceId,
        amount: amount ?? this.amount,
        reason: reason ?? this.reason,
        reversedByUserId: reversedByUserId.present
            ? reversedByUserId.value
            : this.reversedByUserId,
        syncStatus: syncStatus ?? this.syncStatus,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  PaymentReversal copyWithCompanion(PaymentReversalsCompanion data) {
    return PaymentReversal(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      campusId: data.campusId.present ? data.campusId.value : this.campusId,
      paymentId: data.paymentId.present ? data.paymentId.value : this.paymentId,
      invoiceId: data.invoiceId.present ? data.invoiceId.value : this.invoiceId,
      amount: data.amount.present ? data.amount.value : this.amount,
      reason: data.reason.present ? data.reason.value : this.reason,
      reversedByUserId: data.reversedByUserId.present
          ? data.reversedByUserId.value
          : this.reversedByUserId,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PaymentReversal(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('paymentId: $paymentId, ')
          ..write('invoiceId: $invoiceId, ')
          ..write('amount: $amount, ')
          ..write('reason: $reason, ')
          ..write('reversedByUserId: $reversedByUserId, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      tenantId,
      schoolId,
      campusId,
      paymentId,
      invoiceId,
      amount,
      reason,
      reversedByUserId,
      syncStatus,
      serverRevision,
      deleted,
      createdAt,
      updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PaymentReversal &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.campusId == this.campusId &&
          other.paymentId == this.paymentId &&
          other.invoiceId == this.invoiceId &&
          other.amount == this.amount &&
          other.reason == this.reason &&
          other.reversedByUserId == this.reversedByUserId &&
          other.syncStatus == this.syncStatus &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class PaymentReversalsCompanion extends UpdateCompanion<PaymentReversal> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String?> campusId;
  final Value<String> paymentId;
  final Value<String> invoiceId;
  final Value<double> amount;
  final Value<String> reason;
  final Value<String?> reversedByUserId;
  final Value<String> syncStatus;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const PaymentReversalsCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.campusId = const Value.absent(),
    this.paymentId = const Value.absent(),
    this.invoiceId = const Value.absent(),
    this.amount = const Value.absent(),
    this.reason = const Value.absent(),
    this.reversedByUserId = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  PaymentReversalsCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    this.campusId = const Value.absent(),
    required String paymentId,
    required String invoiceId,
    required double amount,
    required String reason,
    this.reversedByUserId = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        paymentId = Value(paymentId),
        invoiceId = Value(invoiceId),
        amount = Value(amount),
        reason = Value(reason);
  static Insertable<PaymentReversal> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? campusId,
    Expression<String>? paymentId,
    Expression<String>? invoiceId,
    Expression<double>? amount,
    Expression<String>? reason,
    Expression<String>? reversedByUserId,
    Expression<String>? syncStatus,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (campusId != null) 'campus_id': campusId,
      if (paymentId != null) 'payment_id': paymentId,
      if (invoiceId != null) 'invoice_id': invoiceId,
      if (amount != null) 'amount': amount,
      if (reason != null) 'reason': reason,
      if (reversedByUserId != null) 'reversed_by_user_id': reversedByUserId,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  PaymentReversalsCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String?>? campusId,
      Value<String>? paymentId,
      Value<String>? invoiceId,
      Value<double>? amount,
      Value<String>? reason,
      Value<String?>? reversedByUserId,
      Value<String>? syncStatus,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return PaymentReversalsCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      campusId: campusId ?? this.campusId,
      paymentId: paymentId ?? this.paymentId,
      invoiceId: invoiceId ?? this.invoiceId,
      amount: amount ?? this.amount,
      reason: reason ?? this.reason,
      reversedByUserId: reversedByUserId ?? this.reversedByUserId,
      syncStatus: syncStatus ?? this.syncStatus,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (campusId.present) {
      map['campus_id'] = Variable<String>(campusId.value);
    }
    if (paymentId.present) {
      map['payment_id'] = Variable<String>(paymentId.value);
    }
    if (invoiceId.present) {
      map['invoice_id'] = Variable<String>(invoiceId.value);
    }
    if (amount.present) {
      map['amount'] = Variable<double>(amount.value);
    }
    if (reason.present) {
      map['reason'] = Variable<String>(reason.value);
    }
    if (reversedByUserId.present) {
      map['reversed_by_user_id'] = Variable<String>(reversedByUserId.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PaymentReversalsCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('paymentId: $paymentId, ')
          ..write('invoiceId: $invoiceId, ')
          ..write('amount: $amount, ')
          ..write('reason: $reason, ')
          ..write('reversedByUserId: $reversedByUserId, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SchoolProfileCacheTable extends SchoolProfileCache
    with TableInfo<$SchoolProfileCacheTable, SchoolProfileCacheData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SchoolProfileCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 255),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _shortNameMeta =
      const VerificationMeta('shortName');
  @override
  late final GeneratedColumn<String> shortName = GeneratedColumn<String>(
      'short_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _schoolTypeMeta =
      const VerificationMeta('schoolType');
  @override
  late final GeneratedColumn<String> schoolType = GeneratedColumn<String>(
      'school_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _addressMeta =
      const VerificationMeta('address');
  @override
  late final GeneratedColumn<String> address = GeneratedColumn<String>(
      'address', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _regionMeta = const VerificationMeta('region');
  @override
  late final GeneratedColumn<String> region = GeneratedColumn<String>(
      'region', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _districtMeta =
      const VerificationMeta('district');
  @override
  late final GeneratedColumn<String> district = GeneratedColumn<String>(
      'district', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _contactPhoneMeta =
      const VerificationMeta('contactPhone');
  @override
  late final GeneratedColumn<String> contactPhone = GeneratedColumn<String>(
      'contact_phone', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _contactEmailMeta =
      const VerificationMeta('contactEmail');
  @override
  late final GeneratedColumn<String> contactEmail = GeneratedColumn<String>(
      'contact_email', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _onboardingDefaultsJsonMeta =
      const VerificationMeta('onboardingDefaultsJson');
  @override
  late final GeneratedColumn<String> onboardingDefaultsJson =
      GeneratedColumn<String>('onboarding_defaults_json', aliasedName, false,
          type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        name,
        shortName,
        schoolType,
        address,
        region,
        district,
        contactPhone,
        contactEmail,
        onboardingDefaultsJson,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'school_profile_cache';
  @override
  VerificationContext validateIntegrity(
      Insertable<SchoolProfileCacheData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('short_name')) {
      context.handle(_shortNameMeta,
          shortName.isAcceptableOrUnknown(data['short_name']!, _shortNameMeta));
    }
    if (data.containsKey('school_type')) {
      context.handle(
          _schoolTypeMeta,
          schoolType.isAcceptableOrUnknown(
              data['school_type']!, _schoolTypeMeta));
    } else if (isInserting) {
      context.missing(_schoolTypeMeta);
    }
    if (data.containsKey('address')) {
      context.handle(_addressMeta,
          address.isAcceptableOrUnknown(data['address']!, _addressMeta));
    }
    if (data.containsKey('region')) {
      context.handle(_regionMeta,
          region.isAcceptableOrUnknown(data['region']!, _regionMeta));
    }
    if (data.containsKey('district')) {
      context.handle(_districtMeta,
          district.isAcceptableOrUnknown(data['district']!, _districtMeta));
    }
    if (data.containsKey('contact_phone')) {
      context.handle(
          _contactPhoneMeta,
          contactPhone.isAcceptableOrUnknown(
              data['contact_phone']!, _contactPhoneMeta));
    }
    if (data.containsKey('contact_email')) {
      context.handle(
          _contactEmailMeta,
          contactEmail.isAcceptableOrUnknown(
              data['contact_email']!, _contactEmailMeta));
    }
    if (data.containsKey('onboarding_defaults_json')) {
      context.handle(
          _onboardingDefaultsJsonMeta,
          onboardingDefaultsJson.isAcceptableOrUnknown(
              data['onboarding_defaults_json']!, _onboardingDefaultsJsonMeta));
    } else if (isInserting) {
      context.missing(_onboardingDefaultsJsonMeta);
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SchoolProfileCacheData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SchoolProfileCacheData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      shortName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}short_name']),
      schoolType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_type'])!,
      address: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}address']),
      region: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}region']),
      district: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}district']),
      contactPhone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}contact_phone']),
      contactEmail: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}contact_email']),
      onboardingDefaultsJson: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}onboarding_defaults_json'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $SchoolProfileCacheTable createAlias(String alias) {
    return $SchoolProfileCacheTable(attachedDatabase, alias);
  }
}

class SchoolProfileCacheData extends DataClass
    implements Insertable<SchoolProfileCacheData> {
  final String id;
  final String tenantId;
  final String name;
  final String? shortName;
  final String schoolType;
  final String? address;
  final String? region;
  final String? district;
  final String? contactPhone;
  final String? contactEmail;
  final String onboardingDefaultsJson;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const SchoolProfileCacheData(
      {required this.id,
      required this.tenantId,
      required this.name,
      this.shortName,
      required this.schoolType,
      this.address,
      this.region,
      this.district,
      this.contactPhone,
      this.contactEmail,
      required this.onboardingDefaultsJson,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || shortName != null) {
      map['short_name'] = Variable<String>(shortName);
    }
    map['school_type'] = Variable<String>(schoolType);
    if (!nullToAbsent || address != null) {
      map['address'] = Variable<String>(address);
    }
    if (!nullToAbsent || region != null) {
      map['region'] = Variable<String>(region);
    }
    if (!nullToAbsent || district != null) {
      map['district'] = Variable<String>(district);
    }
    if (!nullToAbsent || contactPhone != null) {
      map['contact_phone'] = Variable<String>(contactPhone);
    }
    if (!nullToAbsent || contactEmail != null) {
      map['contact_email'] = Variable<String>(contactEmail);
    }
    map['onboarding_defaults_json'] = Variable<String>(onboardingDefaultsJson);
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  SchoolProfileCacheCompanion toCompanion(bool nullToAbsent) {
    return SchoolProfileCacheCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      name: Value(name),
      shortName: shortName == null && nullToAbsent
          ? const Value.absent()
          : Value(shortName),
      schoolType: Value(schoolType),
      address: address == null && nullToAbsent
          ? const Value.absent()
          : Value(address),
      region:
          region == null && nullToAbsent ? const Value.absent() : Value(region),
      district: district == null && nullToAbsent
          ? const Value.absent()
          : Value(district),
      contactPhone: contactPhone == null && nullToAbsent
          ? const Value.absent()
          : Value(contactPhone),
      contactEmail: contactEmail == null && nullToAbsent
          ? const Value.absent()
          : Value(contactEmail),
      onboardingDefaultsJson: Value(onboardingDefaultsJson),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory SchoolProfileCacheData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SchoolProfileCacheData(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      name: serializer.fromJson<String>(json['name']),
      shortName: serializer.fromJson<String?>(json['shortName']),
      schoolType: serializer.fromJson<String>(json['schoolType']),
      address: serializer.fromJson<String?>(json['address']),
      region: serializer.fromJson<String?>(json['region']),
      district: serializer.fromJson<String?>(json['district']),
      contactPhone: serializer.fromJson<String?>(json['contactPhone']),
      contactEmail: serializer.fromJson<String?>(json['contactEmail']),
      onboardingDefaultsJson:
          serializer.fromJson<String>(json['onboardingDefaultsJson']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'name': serializer.toJson<String>(name),
      'shortName': serializer.toJson<String?>(shortName),
      'schoolType': serializer.toJson<String>(schoolType),
      'address': serializer.toJson<String?>(address),
      'region': serializer.toJson<String?>(region),
      'district': serializer.toJson<String?>(district),
      'contactPhone': serializer.toJson<String?>(contactPhone),
      'contactEmail': serializer.toJson<String?>(contactEmail),
      'onboardingDefaultsJson':
          serializer.toJson<String>(onboardingDefaultsJson),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  SchoolProfileCacheData copyWith(
          {String? id,
          String? tenantId,
          String? name,
          Value<String?> shortName = const Value.absent(),
          String? schoolType,
          Value<String?> address = const Value.absent(),
          Value<String?> region = const Value.absent(),
          Value<String?> district = const Value.absent(),
          Value<String?> contactPhone = const Value.absent(),
          Value<String?> contactEmail = const Value.absent(),
          String? onboardingDefaultsJson,
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      SchoolProfileCacheData(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        name: name ?? this.name,
        shortName: shortName.present ? shortName.value : this.shortName,
        schoolType: schoolType ?? this.schoolType,
        address: address.present ? address.value : this.address,
        region: region.present ? region.value : this.region,
        district: district.present ? district.value : this.district,
        contactPhone:
            contactPhone.present ? contactPhone.value : this.contactPhone,
        contactEmail:
            contactEmail.present ? contactEmail.value : this.contactEmail,
        onboardingDefaultsJson:
            onboardingDefaultsJson ?? this.onboardingDefaultsJson,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  SchoolProfileCacheData copyWithCompanion(SchoolProfileCacheCompanion data) {
    return SchoolProfileCacheData(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      name: data.name.present ? data.name.value : this.name,
      shortName: data.shortName.present ? data.shortName.value : this.shortName,
      schoolType:
          data.schoolType.present ? data.schoolType.value : this.schoolType,
      address: data.address.present ? data.address.value : this.address,
      region: data.region.present ? data.region.value : this.region,
      district: data.district.present ? data.district.value : this.district,
      contactPhone: data.contactPhone.present
          ? data.contactPhone.value
          : this.contactPhone,
      contactEmail: data.contactEmail.present
          ? data.contactEmail.value
          : this.contactEmail,
      onboardingDefaultsJson: data.onboardingDefaultsJson.present
          ? data.onboardingDefaultsJson.value
          : this.onboardingDefaultsJson,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SchoolProfileCacheData(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('name: $name, ')
          ..write('shortName: $shortName, ')
          ..write('schoolType: $schoolType, ')
          ..write('address: $address, ')
          ..write('region: $region, ')
          ..write('district: $district, ')
          ..write('contactPhone: $contactPhone, ')
          ..write('contactEmail: $contactEmail, ')
          ..write('onboardingDefaultsJson: $onboardingDefaultsJson, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      tenantId,
      name,
      shortName,
      schoolType,
      address,
      region,
      district,
      contactPhone,
      contactEmail,
      onboardingDefaultsJson,
      serverRevision,
      deleted,
      createdAt,
      updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SchoolProfileCacheData &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.name == this.name &&
          other.shortName == this.shortName &&
          other.schoolType == this.schoolType &&
          other.address == this.address &&
          other.region == this.region &&
          other.district == this.district &&
          other.contactPhone == this.contactPhone &&
          other.contactEmail == this.contactEmail &&
          other.onboardingDefaultsJson == this.onboardingDefaultsJson &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class SchoolProfileCacheCompanion
    extends UpdateCompanion<SchoolProfileCacheData> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> name;
  final Value<String?> shortName;
  final Value<String> schoolType;
  final Value<String?> address;
  final Value<String?> region;
  final Value<String?> district;
  final Value<String?> contactPhone;
  final Value<String?> contactEmail;
  final Value<String> onboardingDefaultsJson;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const SchoolProfileCacheCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.name = const Value.absent(),
    this.shortName = const Value.absent(),
    this.schoolType = const Value.absent(),
    this.address = const Value.absent(),
    this.region = const Value.absent(),
    this.district = const Value.absent(),
    this.contactPhone = const Value.absent(),
    this.contactEmail = const Value.absent(),
    this.onboardingDefaultsJson = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SchoolProfileCacheCompanion.insert({
    required String id,
    required String tenantId,
    required String name,
    this.shortName = const Value.absent(),
    required String schoolType,
    this.address = const Value.absent(),
    this.region = const Value.absent(),
    this.district = const Value.absent(),
    this.contactPhone = const Value.absent(),
    this.contactEmail = const Value.absent(),
    required String onboardingDefaultsJson,
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        name = Value(name),
        schoolType = Value(schoolType),
        onboardingDefaultsJson = Value(onboardingDefaultsJson);
  static Insertable<SchoolProfileCacheData> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? name,
    Expression<String>? shortName,
    Expression<String>? schoolType,
    Expression<String>? address,
    Expression<String>? region,
    Expression<String>? district,
    Expression<String>? contactPhone,
    Expression<String>? contactEmail,
    Expression<String>? onboardingDefaultsJson,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (name != null) 'name': name,
      if (shortName != null) 'short_name': shortName,
      if (schoolType != null) 'school_type': schoolType,
      if (address != null) 'address': address,
      if (region != null) 'region': region,
      if (district != null) 'district': district,
      if (contactPhone != null) 'contact_phone': contactPhone,
      if (contactEmail != null) 'contact_email': contactEmail,
      if (onboardingDefaultsJson != null)
        'onboarding_defaults_json': onboardingDefaultsJson,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SchoolProfileCacheCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? name,
      Value<String?>? shortName,
      Value<String>? schoolType,
      Value<String?>? address,
      Value<String?>? region,
      Value<String?>? district,
      Value<String?>? contactPhone,
      Value<String?>? contactEmail,
      Value<String>? onboardingDefaultsJson,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return SchoolProfileCacheCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      name: name ?? this.name,
      shortName: shortName ?? this.shortName,
      schoolType: schoolType ?? this.schoolType,
      address: address ?? this.address,
      region: region ?? this.region,
      district: district ?? this.district,
      contactPhone: contactPhone ?? this.contactPhone,
      contactEmail: contactEmail ?? this.contactEmail,
      onboardingDefaultsJson:
          onboardingDefaultsJson ?? this.onboardingDefaultsJson,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (shortName.present) {
      map['short_name'] = Variable<String>(shortName.value);
    }
    if (schoolType.present) {
      map['school_type'] = Variable<String>(schoolType.value);
    }
    if (address.present) {
      map['address'] = Variable<String>(address.value);
    }
    if (region.present) {
      map['region'] = Variable<String>(region.value);
    }
    if (district.present) {
      map['district'] = Variable<String>(district.value);
    }
    if (contactPhone.present) {
      map['contact_phone'] = Variable<String>(contactPhone.value);
    }
    if (contactEmail.present) {
      map['contact_email'] = Variable<String>(contactEmail.value);
    }
    if (onboardingDefaultsJson.present) {
      map['onboarding_defaults_json'] =
          Variable<String>(onboardingDefaultsJson.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SchoolProfileCacheCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('name: $name, ')
          ..write('shortName: $shortName, ')
          ..write('schoolType: $schoolType, ')
          ..write('address: $address, ')
          ..write('region: $region, ')
          ..write('district: $district, ')
          ..write('contactPhone: $contactPhone, ')
          ..write('contactEmail: $contactEmail, ')
          ..write('onboardingDefaultsJson: $onboardingDefaultsJson, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $CampusProfileCacheTable extends CampusProfileCache
    with TableInfo<$CampusProfileCacheTable, CampusProfileCacheData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CampusProfileCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 255),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _addressMeta =
      const VerificationMeta('address');
  @override
  late final GeneratedColumn<String> address = GeneratedColumn<String>(
      'address', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _contactPhoneMeta =
      const VerificationMeta('contactPhone');
  @override
  late final GeneratedColumn<String> contactPhone = GeneratedColumn<String>(
      'contact_phone', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _registrationCodeMeta =
      const VerificationMeta('registrationCode');
  @override
  late final GeneratedColumn<String> registrationCode = GeneratedColumn<String>(
      'registration_code', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        name,
        address,
        contactPhone,
        registrationCode,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'campus_profile_cache';
  @override
  VerificationContext validateIntegrity(
      Insertable<CampusProfileCacheData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('address')) {
      context.handle(_addressMeta,
          address.isAcceptableOrUnknown(data['address']!, _addressMeta));
    }
    if (data.containsKey('contact_phone')) {
      context.handle(
          _contactPhoneMeta,
          contactPhone.isAcceptableOrUnknown(
              data['contact_phone']!, _contactPhoneMeta));
    }
    if (data.containsKey('registration_code')) {
      context.handle(
          _registrationCodeMeta,
          registrationCode.isAcceptableOrUnknown(
              data['registration_code']!, _registrationCodeMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CampusProfileCacheData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CampusProfileCacheData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      address: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}address']),
      contactPhone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}contact_phone']),
      registrationCode: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}registration_code']),
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $CampusProfileCacheTable createAlias(String alias) {
    return $CampusProfileCacheTable(attachedDatabase, alias);
  }
}

class CampusProfileCacheData extends DataClass
    implements Insertable<CampusProfileCacheData> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String name;
  final String? address;
  final String? contactPhone;
  final String? registrationCode;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const CampusProfileCacheData(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      required this.name,
      this.address,
      this.contactPhone,
      this.registrationCode,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || address != null) {
      map['address'] = Variable<String>(address);
    }
    if (!nullToAbsent || contactPhone != null) {
      map['contact_phone'] = Variable<String>(contactPhone);
    }
    if (!nullToAbsent || registrationCode != null) {
      map['registration_code'] = Variable<String>(registrationCode);
    }
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  CampusProfileCacheCompanion toCompanion(bool nullToAbsent) {
    return CampusProfileCacheCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      name: Value(name),
      address: address == null && nullToAbsent
          ? const Value.absent()
          : Value(address),
      contactPhone: contactPhone == null && nullToAbsent
          ? const Value.absent()
          : Value(contactPhone),
      registrationCode: registrationCode == null && nullToAbsent
          ? const Value.absent()
          : Value(registrationCode),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory CampusProfileCacheData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CampusProfileCacheData(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      name: serializer.fromJson<String>(json['name']),
      address: serializer.fromJson<String?>(json['address']),
      contactPhone: serializer.fromJson<String?>(json['contactPhone']),
      registrationCode: serializer.fromJson<String?>(json['registrationCode']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'name': serializer.toJson<String>(name),
      'address': serializer.toJson<String?>(address),
      'contactPhone': serializer.toJson<String?>(contactPhone),
      'registrationCode': serializer.toJson<String?>(registrationCode),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  CampusProfileCacheData copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          String? name,
          Value<String?> address = const Value.absent(),
          Value<String?> contactPhone = const Value.absent(),
          Value<String?> registrationCode = const Value.absent(),
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      CampusProfileCacheData(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        name: name ?? this.name,
        address: address.present ? address.value : this.address,
        contactPhone:
            contactPhone.present ? contactPhone.value : this.contactPhone,
        registrationCode: registrationCode.present
            ? registrationCode.value
            : this.registrationCode,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  CampusProfileCacheData copyWithCompanion(CampusProfileCacheCompanion data) {
    return CampusProfileCacheData(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      name: data.name.present ? data.name.value : this.name,
      address: data.address.present ? data.address.value : this.address,
      contactPhone: data.contactPhone.present
          ? data.contactPhone.value
          : this.contactPhone,
      registrationCode: data.registrationCode.present
          ? data.registrationCode.value
          : this.registrationCode,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CampusProfileCacheData(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('name: $name, ')
          ..write('address: $address, ')
          ..write('contactPhone: $contactPhone, ')
          ..write('registrationCode: $registrationCode, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      tenantId,
      schoolId,
      name,
      address,
      contactPhone,
      registrationCode,
      serverRevision,
      deleted,
      createdAt,
      updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CampusProfileCacheData &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.name == this.name &&
          other.address == this.address &&
          other.contactPhone == this.contactPhone &&
          other.registrationCode == this.registrationCode &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class CampusProfileCacheCompanion
    extends UpdateCompanion<CampusProfileCacheData> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String> name;
  final Value<String?> address;
  final Value<String?> contactPhone;
  final Value<String?> registrationCode;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const CampusProfileCacheCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.name = const Value.absent(),
    this.address = const Value.absent(),
    this.contactPhone = const Value.absent(),
    this.registrationCode = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  CampusProfileCacheCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    required String name,
    this.address = const Value.absent(),
    this.contactPhone = const Value.absent(),
    this.registrationCode = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        name = Value(name);
  static Insertable<CampusProfileCacheData> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? name,
    Expression<String>? address,
    Expression<String>? contactPhone,
    Expression<String>? registrationCode,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (name != null) 'name': name,
      if (address != null) 'address': address,
      if (contactPhone != null) 'contact_phone': contactPhone,
      if (registrationCode != null) 'registration_code': registrationCode,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  CampusProfileCacheCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String>? name,
      Value<String?>? address,
      Value<String?>? contactPhone,
      Value<String?>? registrationCode,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return CampusProfileCacheCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      name: name ?? this.name,
      address: address ?? this.address,
      contactPhone: contactPhone ?? this.contactPhone,
      registrationCode: registrationCode ?? this.registrationCode,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (address.present) {
      map['address'] = Variable<String>(address.value);
    }
    if (contactPhone.present) {
      map['contact_phone'] = Variable<String>(contactPhone.value);
    }
    if (registrationCode.present) {
      map['registration_code'] = Variable<String>(registrationCode.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CampusProfileCacheCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('name: $name, ')
          ..write('address: $address, ')
          ..write('contactPhone: $contactPhone, ')
          ..write('registrationCode: $registrationCode, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $StudentsTable extends Students with TableInfo<$StudentsTable, Student> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $StudentsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _campusIdMeta =
      const VerificationMeta('campusId');
  @override
  late final GeneratedColumn<String> campusId = GeneratedColumn<String>(
      'campus_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _studentNumberMeta =
      const VerificationMeta('studentNumber');
  @override
  late final GeneratedColumn<String> studentNumber = GeneratedColumn<String>(
      'student_number', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _firstNameMeta =
      const VerificationMeta('firstName');
  @override
  late final GeneratedColumn<String> firstName = GeneratedColumn<String>(
      'first_name', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _middleNameMeta =
      const VerificationMeta('middleName');
  @override
  late final GeneratedColumn<String> middleName = GeneratedColumn<String>(
      'middle_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _lastNameMeta =
      const VerificationMeta('lastName');
  @override
  late final GeneratedColumn<String> lastName = GeneratedColumn<String>(
      'last_name', aliasedName, false,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 1, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: true);
  static const VerificationMeta _dateOfBirthMeta =
      const VerificationMeta('dateOfBirth');
  @override
  late final GeneratedColumn<String> dateOfBirth = GeneratedColumn<String>(
      'date_of_birth', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _genderMeta = const VerificationMeta('gender');
  @override
  late final GeneratedColumn<String> gender = GeneratedColumn<String>(
      'gender', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('active'));
  static const VerificationMeta _profilePhotoUrlMeta =
      const VerificationMeta('profilePhotoUrl');
  @override
  late final GeneratedColumn<String> profilePhotoUrl = GeneratedColumn<String>(
      'profile_photo_url', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('local'));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        campusId,
        studentNumber,
        firstName,
        middleName,
        lastName,
        dateOfBirth,
        gender,
        status,
        profilePhotoUrl,
        serverRevision,
        syncStatus,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'students';
  @override
  VerificationContext validateIntegrity(Insertable<Student> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('campus_id')) {
      context.handle(_campusIdMeta,
          campusId.isAcceptableOrUnknown(data['campus_id']!, _campusIdMeta));
    }
    if (data.containsKey('student_number')) {
      context.handle(
          _studentNumberMeta,
          studentNumber.isAcceptableOrUnknown(
              data['student_number']!, _studentNumberMeta));
    }
    if (data.containsKey('first_name')) {
      context.handle(_firstNameMeta,
          firstName.isAcceptableOrUnknown(data['first_name']!, _firstNameMeta));
    } else if (isInserting) {
      context.missing(_firstNameMeta);
    }
    if (data.containsKey('middle_name')) {
      context.handle(
          _middleNameMeta,
          middleName.isAcceptableOrUnknown(
              data['middle_name']!, _middleNameMeta));
    }
    if (data.containsKey('last_name')) {
      context.handle(_lastNameMeta,
          lastName.isAcceptableOrUnknown(data['last_name']!, _lastNameMeta));
    } else if (isInserting) {
      context.missing(_lastNameMeta);
    }
    if (data.containsKey('date_of_birth')) {
      context.handle(
          _dateOfBirthMeta,
          dateOfBirth.isAcceptableOrUnknown(
              data['date_of_birth']!, _dateOfBirthMeta));
    }
    if (data.containsKey('gender')) {
      context.handle(_genderMeta,
          gender.isAcceptableOrUnknown(data['gender']!, _genderMeta));
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('profile_photo_url')) {
      context.handle(
          _profilePhotoUrlMeta,
          profilePhotoUrl.isAcceptableOrUnknown(
              data['profile_photo_url']!, _profilePhotoUrlMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Student map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Student(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      campusId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}campus_id']),
      studentNumber: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}student_number']),
      firstName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}first_name'])!,
      middleName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}middle_name']),
      lastName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}last_name'])!,
      dateOfBirth: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}date_of_birth']),
      gender: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gender']),
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      profilePhotoUrl: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}profile_photo_url']),
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $StudentsTable createAlias(String alias) {
    return $StudentsTable(attachedDatabase, alias);
  }
}

class Student extends DataClass implements Insertable<Student> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String? campusId;
  final String? studentNumber;
  final String firstName;
  final String? middleName;
  final String lastName;
  final String? dateOfBirth;
  final String? gender;
  final String status;
  final String? profilePhotoUrl;
  final int serverRevision;
  final String syncStatus;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const Student(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      this.campusId,
      this.studentNumber,
      required this.firstName,
      this.middleName,
      required this.lastName,
      this.dateOfBirth,
      this.gender,
      required this.status,
      this.profilePhotoUrl,
      required this.serverRevision,
      required this.syncStatus,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    if (!nullToAbsent || campusId != null) {
      map['campus_id'] = Variable<String>(campusId);
    }
    if (!nullToAbsent || studentNumber != null) {
      map['student_number'] = Variable<String>(studentNumber);
    }
    map['first_name'] = Variable<String>(firstName);
    if (!nullToAbsent || middleName != null) {
      map['middle_name'] = Variable<String>(middleName);
    }
    map['last_name'] = Variable<String>(lastName);
    if (!nullToAbsent || dateOfBirth != null) {
      map['date_of_birth'] = Variable<String>(dateOfBirth);
    }
    if (!nullToAbsent || gender != null) {
      map['gender'] = Variable<String>(gender);
    }
    map['status'] = Variable<String>(status);
    if (!nullToAbsent || profilePhotoUrl != null) {
      map['profile_photo_url'] = Variable<String>(profilePhotoUrl);
    }
    map['server_revision'] = Variable<int>(serverRevision);
    map['sync_status'] = Variable<String>(syncStatus);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  StudentsCompanion toCompanion(bool nullToAbsent) {
    return StudentsCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      campusId: campusId == null && nullToAbsent
          ? const Value.absent()
          : Value(campusId),
      studentNumber: studentNumber == null && nullToAbsent
          ? const Value.absent()
          : Value(studentNumber),
      firstName: Value(firstName),
      middleName: middleName == null && nullToAbsent
          ? const Value.absent()
          : Value(middleName),
      lastName: Value(lastName),
      dateOfBirth: dateOfBirth == null && nullToAbsent
          ? const Value.absent()
          : Value(dateOfBirth),
      gender:
          gender == null && nullToAbsent ? const Value.absent() : Value(gender),
      status: Value(status),
      profilePhotoUrl: profilePhotoUrl == null && nullToAbsent
          ? const Value.absent()
          : Value(profilePhotoUrl),
      serverRevision: Value(serverRevision),
      syncStatus: Value(syncStatus),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory Student.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Student(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      campusId: serializer.fromJson<String?>(json['campusId']),
      studentNumber: serializer.fromJson<String?>(json['studentNumber']),
      firstName: serializer.fromJson<String>(json['firstName']),
      middleName: serializer.fromJson<String?>(json['middleName']),
      lastName: serializer.fromJson<String>(json['lastName']),
      dateOfBirth: serializer.fromJson<String?>(json['dateOfBirth']),
      gender: serializer.fromJson<String?>(json['gender']),
      status: serializer.fromJson<String>(json['status']),
      profilePhotoUrl: serializer.fromJson<String?>(json['profilePhotoUrl']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'campusId': serializer.toJson<String?>(campusId),
      'studentNumber': serializer.toJson<String?>(studentNumber),
      'firstName': serializer.toJson<String>(firstName),
      'middleName': serializer.toJson<String?>(middleName),
      'lastName': serializer.toJson<String>(lastName),
      'dateOfBirth': serializer.toJson<String?>(dateOfBirth),
      'gender': serializer.toJson<String?>(gender),
      'status': serializer.toJson<String>(status),
      'profilePhotoUrl': serializer.toJson<String?>(profilePhotoUrl),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  Student copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          Value<String?> campusId = const Value.absent(),
          Value<String?> studentNumber = const Value.absent(),
          String? firstName,
          Value<String?> middleName = const Value.absent(),
          String? lastName,
          Value<String?> dateOfBirth = const Value.absent(),
          Value<String?> gender = const Value.absent(),
          String? status,
          Value<String?> profilePhotoUrl = const Value.absent(),
          int? serverRevision,
          String? syncStatus,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      Student(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        campusId: campusId.present ? campusId.value : this.campusId,
        studentNumber:
            studentNumber.present ? studentNumber.value : this.studentNumber,
        firstName: firstName ?? this.firstName,
        middleName: middleName.present ? middleName.value : this.middleName,
        lastName: lastName ?? this.lastName,
        dateOfBirth: dateOfBirth.present ? dateOfBirth.value : this.dateOfBirth,
        gender: gender.present ? gender.value : this.gender,
        status: status ?? this.status,
        profilePhotoUrl: profilePhotoUrl.present
            ? profilePhotoUrl.value
            : this.profilePhotoUrl,
        serverRevision: serverRevision ?? this.serverRevision,
        syncStatus: syncStatus ?? this.syncStatus,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  Student copyWithCompanion(StudentsCompanion data) {
    return Student(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      campusId: data.campusId.present ? data.campusId.value : this.campusId,
      studentNumber: data.studentNumber.present
          ? data.studentNumber.value
          : this.studentNumber,
      firstName: data.firstName.present ? data.firstName.value : this.firstName,
      middleName:
          data.middleName.present ? data.middleName.value : this.middleName,
      lastName: data.lastName.present ? data.lastName.value : this.lastName,
      dateOfBirth:
          data.dateOfBirth.present ? data.dateOfBirth.value : this.dateOfBirth,
      gender: data.gender.present ? data.gender.value : this.gender,
      status: data.status.present ? data.status.value : this.status,
      profilePhotoUrl: data.profilePhotoUrl.present
          ? data.profilePhotoUrl.value
          : this.profilePhotoUrl,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Student(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('studentNumber: $studentNumber, ')
          ..write('firstName: $firstName, ')
          ..write('middleName: $middleName, ')
          ..write('lastName: $lastName, ')
          ..write('dateOfBirth: $dateOfBirth, ')
          ..write('gender: $gender, ')
          ..write('status: $status, ')
          ..write('profilePhotoUrl: $profilePhotoUrl, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      tenantId,
      schoolId,
      campusId,
      studentNumber,
      firstName,
      middleName,
      lastName,
      dateOfBirth,
      gender,
      status,
      profilePhotoUrl,
      serverRevision,
      syncStatus,
      deleted,
      createdAt,
      updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Student &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.campusId == this.campusId &&
          other.studentNumber == this.studentNumber &&
          other.firstName == this.firstName &&
          other.middleName == this.middleName &&
          other.lastName == this.lastName &&
          other.dateOfBirth == this.dateOfBirth &&
          other.gender == this.gender &&
          other.status == this.status &&
          other.profilePhotoUrl == this.profilePhotoUrl &&
          other.serverRevision == this.serverRevision &&
          other.syncStatus == this.syncStatus &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class StudentsCompanion extends UpdateCompanion<Student> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String?> campusId;
  final Value<String?> studentNumber;
  final Value<String> firstName;
  final Value<String?> middleName;
  final Value<String> lastName;
  final Value<String?> dateOfBirth;
  final Value<String?> gender;
  final Value<String> status;
  final Value<String?> profilePhotoUrl;
  final Value<int> serverRevision;
  final Value<String> syncStatus;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const StudentsCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.campusId = const Value.absent(),
    this.studentNumber = const Value.absent(),
    this.firstName = const Value.absent(),
    this.middleName = const Value.absent(),
    this.lastName = const Value.absent(),
    this.dateOfBirth = const Value.absent(),
    this.gender = const Value.absent(),
    this.status = const Value.absent(),
    this.profilePhotoUrl = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  StudentsCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    this.campusId = const Value.absent(),
    this.studentNumber = const Value.absent(),
    required String firstName,
    this.middleName = const Value.absent(),
    required String lastName,
    this.dateOfBirth = const Value.absent(),
    this.gender = const Value.absent(),
    this.status = const Value.absent(),
    this.profilePhotoUrl = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        firstName = Value(firstName),
        lastName = Value(lastName);
  static Insertable<Student> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? campusId,
    Expression<String>? studentNumber,
    Expression<String>? firstName,
    Expression<String>? middleName,
    Expression<String>? lastName,
    Expression<String>? dateOfBirth,
    Expression<String>? gender,
    Expression<String>? status,
    Expression<String>? profilePhotoUrl,
    Expression<int>? serverRevision,
    Expression<String>? syncStatus,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (campusId != null) 'campus_id': campusId,
      if (studentNumber != null) 'student_number': studentNumber,
      if (firstName != null) 'first_name': firstName,
      if (middleName != null) 'middle_name': middleName,
      if (lastName != null) 'last_name': lastName,
      if (dateOfBirth != null) 'date_of_birth': dateOfBirth,
      if (gender != null) 'gender': gender,
      if (status != null) 'status': status,
      if (profilePhotoUrl != null) 'profile_photo_url': profilePhotoUrl,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  StudentsCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String?>? campusId,
      Value<String?>? studentNumber,
      Value<String>? firstName,
      Value<String?>? middleName,
      Value<String>? lastName,
      Value<String?>? dateOfBirth,
      Value<String?>? gender,
      Value<String>? status,
      Value<String?>? profilePhotoUrl,
      Value<int>? serverRevision,
      Value<String>? syncStatus,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return StudentsCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      campusId: campusId ?? this.campusId,
      studentNumber: studentNumber ?? this.studentNumber,
      firstName: firstName ?? this.firstName,
      middleName: middleName ?? this.middleName,
      lastName: lastName ?? this.lastName,
      dateOfBirth: dateOfBirth ?? this.dateOfBirth,
      gender: gender ?? this.gender,
      status: status ?? this.status,
      profilePhotoUrl: profilePhotoUrl ?? this.profilePhotoUrl,
      serverRevision: serverRevision ?? this.serverRevision,
      syncStatus: syncStatus ?? this.syncStatus,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (campusId.present) {
      map['campus_id'] = Variable<String>(campusId.value);
    }
    if (studentNumber.present) {
      map['student_number'] = Variable<String>(studentNumber.value);
    }
    if (firstName.present) {
      map['first_name'] = Variable<String>(firstName.value);
    }
    if (middleName.present) {
      map['middle_name'] = Variable<String>(middleName.value);
    }
    if (lastName.present) {
      map['last_name'] = Variable<String>(lastName.value);
    }
    if (dateOfBirth.present) {
      map['date_of_birth'] = Variable<String>(dateOfBirth.value);
    }
    if (gender.present) {
      map['gender'] = Variable<String>(gender.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (profilePhotoUrl.present) {
      map['profile_photo_url'] = Variable<String>(profilePhotoUrl.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('StudentsCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('studentNumber: $studentNumber, ')
          ..write('firstName: $firstName, ')
          ..write('middleName: $middleName, ')
          ..write('lastName: $lastName, ')
          ..write('dateOfBirth: $dateOfBirth, ')
          ..write('gender: $gender, ')
          ..write('status: $status, ')
          ..write('profilePhotoUrl: $profilePhotoUrl, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $GuardiansTable extends Guardians
    with TableInfo<$GuardiansTable, Guardian> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GuardiansTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _studentIdMeta =
      const VerificationMeta('studentId');
  @override
  late final GeneratedColumn<String> studentId = GeneratedColumn<String>(
      'student_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _firstNameMeta =
      const VerificationMeta('firstName');
  @override
  late final GeneratedColumn<String> firstName = GeneratedColumn<String>(
      'first_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _lastNameMeta =
      const VerificationMeta('lastName');
  @override
  late final GeneratedColumn<String> lastName = GeneratedColumn<String>(
      'last_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _relationshipMeta =
      const VerificationMeta('relationship');
  @override
  late final GeneratedColumn<String> relationship = GeneratedColumn<String>(
      'relationship', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('guardian'));
  static const VerificationMeta _phoneMeta = const VerificationMeta('phone');
  @override
  late final GeneratedColumn<String> phone = GeneratedColumn<String>(
      'phone', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _isPrimaryMeta =
      const VerificationMeta('isPrimary');
  @override
  late final GeneratedColumn<bool> isPrimary = GeneratedColumn<bool>(
      'is_primary', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_primary" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        studentId,
        firstName,
        lastName,
        relationship,
        phone,
        email,
        isPrimary,
        serverRevision,
        deleted,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'guardians';
  @override
  VerificationContext validateIntegrity(Insertable<Guardian> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('student_id')) {
      context.handle(_studentIdMeta,
          studentId.isAcceptableOrUnknown(data['student_id']!, _studentIdMeta));
    } else if (isInserting) {
      context.missing(_studentIdMeta);
    }
    if (data.containsKey('first_name')) {
      context.handle(_firstNameMeta,
          firstName.isAcceptableOrUnknown(data['first_name']!, _firstNameMeta));
    } else if (isInserting) {
      context.missing(_firstNameMeta);
    }
    if (data.containsKey('last_name')) {
      context.handle(_lastNameMeta,
          lastName.isAcceptableOrUnknown(data['last_name']!, _lastNameMeta));
    } else if (isInserting) {
      context.missing(_lastNameMeta);
    }
    if (data.containsKey('relationship')) {
      context.handle(
          _relationshipMeta,
          relationship.isAcceptableOrUnknown(
              data['relationship']!, _relationshipMeta));
    }
    if (data.containsKey('phone')) {
      context.handle(
          _phoneMeta, phone.isAcceptableOrUnknown(data['phone']!, _phoneMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('is_primary')) {
      context.handle(_isPrimaryMeta,
          isPrimary.isAcceptableOrUnknown(data['is_primary']!, _isPrimaryMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Guardian map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Guardian(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      studentId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}student_id'])!,
      firstName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}first_name'])!,
      lastName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}last_name'])!,
      relationship: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}relationship'])!,
      phone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}phone']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      isPrimary: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_primary'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $GuardiansTable createAlias(String alias) {
    return $GuardiansTable(attachedDatabase, alias);
  }
}

class Guardian extends DataClass implements Insertable<Guardian> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String studentId;
  final String firstName;
  final String lastName;
  final String relationship;
  final String? phone;
  final String? email;
  final bool isPrimary;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  const Guardian(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      required this.studentId,
      required this.firstName,
      required this.lastName,
      required this.relationship,
      this.phone,
      this.email,
      required this.isPrimary,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    map['student_id'] = Variable<String>(studentId);
    map['first_name'] = Variable<String>(firstName);
    map['last_name'] = Variable<String>(lastName);
    map['relationship'] = Variable<String>(relationship);
    if (!nullToAbsent || phone != null) {
      map['phone'] = Variable<String>(phone);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    map['is_primary'] = Variable<bool>(isPrimary);
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  GuardiansCompanion toCompanion(bool nullToAbsent) {
    return GuardiansCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      studentId: Value(studentId),
      firstName: Value(firstName),
      lastName: Value(lastName),
      relationship: Value(relationship),
      phone:
          phone == null && nullToAbsent ? const Value.absent() : Value(phone),
      email:
          email == null && nullToAbsent ? const Value.absent() : Value(email),
      isPrimary: Value(isPrimary),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
    );
  }

  factory Guardian.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Guardian(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      studentId: serializer.fromJson<String>(json['studentId']),
      firstName: serializer.fromJson<String>(json['firstName']),
      lastName: serializer.fromJson<String>(json['lastName']),
      relationship: serializer.fromJson<String>(json['relationship']),
      phone: serializer.fromJson<String?>(json['phone']),
      email: serializer.fromJson<String?>(json['email']),
      isPrimary: serializer.fromJson<bool>(json['isPrimary']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'studentId': serializer.toJson<String>(studentId),
      'firstName': serializer.toJson<String>(firstName),
      'lastName': serializer.toJson<String>(lastName),
      'relationship': serializer.toJson<String>(relationship),
      'phone': serializer.toJson<String?>(phone),
      'email': serializer.toJson<String?>(email),
      'isPrimary': serializer.toJson<bool>(isPrimary),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  Guardian copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          String? studentId,
          String? firstName,
          String? lastName,
          String? relationship,
          Value<String?> phone = const Value.absent(),
          Value<String?> email = const Value.absent(),
          bool? isPrimary,
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt}) =>
      Guardian(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        studentId: studentId ?? this.studentId,
        firstName: firstName ?? this.firstName,
        lastName: lastName ?? this.lastName,
        relationship: relationship ?? this.relationship,
        phone: phone.present ? phone.value : this.phone,
        email: email.present ? email.value : this.email,
        isPrimary: isPrimary ?? this.isPrimary,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
      );
  Guardian copyWithCompanion(GuardiansCompanion data) {
    return Guardian(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      studentId: data.studentId.present ? data.studentId.value : this.studentId,
      firstName: data.firstName.present ? data.firstName.value : this.firstName,
      lastName: data.lastName.present ? data.lastName.value : this.lastName,
      relationship: data.relationship.present
          ? data.relationship.value
          : this.relationship,
      phone: data.phone.present ? data.phone.value : this.phone,
      email: data.email.present ? data.email.value : this.email,
      isPrimary: data.isPrimary.present ? data.isPrimary.value : this.isPrimary,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Guardian(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('studentId: $studentId, ')
          ..write('firstName: $firstName, ')
          ..write('lastName: $lastName, ')
          ..write('relationship: $relationship, ')
          ..write('phone: $phone, ')
          ..write('email: $email, ')
          ..write('isPrimary: $isPrimary, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      tenantId,
      schoolId,
      studentId,
      firstName,
      lastName,
      relationship,
      phone,
      email,
      isPrimary,
      serverRevision,
      deleted,
      createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Guardian &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.studentId == this.studentId &&
          other.firstName == this.firstName &&
          other.lastName == this.lastName &&
          other.relationship == this.relationship &&
          other.phone == this.phone &&
          other.email == this.email &&
          other.isPrimary == this.isPrimary &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt);
}

class GuardiansCompanion extends UpdateCompanion<Guardian> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String> studentId;
  final Value<String> firstName;
  final Value<String> lastName;
  final Value<String> relationship;
  final Value<String?> phone;
  final Value<String?> email;
  final Value<bool> isPrimary;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const GuardiansCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.studentId = const Value.absent(),
    this.firstName = const Value.absent(),
    this.lastName = const Value.absent(),
    this.relationship = const Value.absent(),
    this.phone = const Value.absent(),
    this.email = const Value.absent(),
    this.isPrimary = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  GuardiansCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    required String studentId,
    required String firstName,
    required String lastName,
    this.relationship = const Value.absent(),
    this.phone = const Value.absent(),
    this.email = const Value.absent(),
    this.isPrimary = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        studentId = Value(studentId),
        firstName = Value(firstName),
        lastName = Value(lastName);
  static Insertable<Guardian> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? studentId,
    Expression<String>? firstName,
    Expression<String>? lastName,
    Expression<String>? relationship,
    Expression<String>? phone,
    Expression<String>? email,
    Expression<bool>? isPrimary,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (studentId != null) 'student_id': studentId,
      if (firstName != null) 'first_name': firstName,
      if (lastName != null) 'last_name': lastName,
      if (relationship != null) 'relationship': relationship,
      if (phone != null) 'phone': phone,
      if (email != null) 'email': email,
      if (isPrimary != null) 'is_primary': isPrimary,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  GuardiansCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String>? studentId,
      Value<String>? firstName,
      Value<String>? lastName,
      Value<String>? relationship,
      Value<String?>? phone,
      Value<String?>? email,
      Value<bool>? isPrimary,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return GuardiansCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      studentId: studentId ?? this.studentId,
      firstName: firstName ?? this.firstName,
      lastName: lastName ?? this.lastName,
      relationship: relationship ?? this.relationship,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      isPrimary: isPrimary ?? this.isPrimary,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (studentId.present) {
      map['student_id'] = Variable<String>(studentId.value);
    }
    if (firstName.present) {
      map['first_name'] = Variable<String>(firstName.value);
    }
    if (lastName.present) {
      map['last_name'] = Variable<String>(lastName.value);
    }
    if (relationship.present) {
      map['relationship'] = Variable<String>(relationship.value);
    }
    if (phone.present) {
      map['phone'] = Variable<String>(phone.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (isPrimary.present) {
      map['is_primary'] = Variable<bool>(isPrimary.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GuardiansCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('studentId: $studentId, ')
          ..write('firstName: $firstName, ')
          ..write('lastName: $lastName, ')
          ..write('relationship: $relationship, ')
          ..write('phone: $phone, ')
          ..write('email: $email, ')
          ..write('isPrimary: $isPrimary, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $EnrollmentsTable extends Enrollments
    with TableInfo<$EnrollmentsTable, Enrollment> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EnrollmentsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _studentIdMeta =
      const VerificationMeta('studentId');
  @override
  late final GeneratedColumn<String> studentId = GeneratedColumn<String>(
      'student_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _classArmIdMeta =
      const VerificationMeta('classArmId');
  @override
  late final GeneratedColumn<String> classArmId = GeneratedColumn<String>(
      'class_arm_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _academicYearIdMeta =
      const VerificationMeta('academicYearId');
  @override
  late final GeneratedColumn<String> academicYearId = GeneratedColumn<String>(
      'academic_year_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _enrollmentDateMeta =
      const VerificationMeta('enrollmentDate');
  @override
  late final GeneratedColumn<String> enrollmentDate = GeneratedColumn<String>(
      'enrollment_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        studentId,
        classArmId,
        academicYearId,
        enrollmentDate,
        serverRevision,
        deleted,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'enrollments';
  @override
  VerificationContext validateIntegrity(Insertable<Enrollment> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('student_id')) {
      context.handle(_studentIdMeta,
          studentId.isAcceptableOrUnknown(data['student_id']!, _studentIdMeta));
    } else if (isInserting) {
      context.missing(_studentIdMeta);
    }
    if (data.containsKey('class_arm_id')) {
      context.handle(
          _classArmIdMeta,
          classArmId.isAcceptableOrUnknown(
              data['class_arm_id']!, _classArmIdMeta));
    } else if (isInserting) {
      context.missing(_classArmIdMeta);
    }
    if (data.containsKey('academic_year_id')) {
      context.handle(
          _academicYearIdMeta,
          academicYearId.isAcceptableOrUnknown(
              data['academic_year_id']!, _academicYearIdMeta));
    } else if (isInserting) {
      context.missing(_academicYearIdMeta);
    }
    if (data.containsKey('enrollment_date')) {
      context.handle(
          _enrollmentDateMeta,
          enrollmentDate.isAcceptableOrUnknown(
              data['enrollment_date']!, _enrollmentDateMeta));
    } else if (isInserting) {
      context.missing(_enrollmentDateMeta);
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Enrollment map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Enrollment(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      studentId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}student_id'])!,
      classArmId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}class_arm_id'])!,
      academicYearId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}academic_year_id'])!,
      enrollmentDate: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}enrollment_date'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $EnrollmentsTable createAlias(String alias) {
    return $EnrollmentsTable(attachedDatabase, alias);
  }
}

class Enrollment extends DataClass implements Insertable<Enrollment> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String studentId;
  final String classArmId;
  final String academicYearId;
  final String enrollmentDate;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  const Enrollment(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      required this.studentId,
      required this.classArmId,
      required this.academicYearId,
      required this.enrollmentDate,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    map['student_id'] = Variable<String>(studentId);
    map['class_arm_id'] = Variable<String>(classArmId);
    map['academic_year_id'] = Variable<String>(academicYearId);
    map['enrollment_date'] = Variable<String>(enrollmentDate);
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  EnrollmentsCompanion toCompanion(bool nullToAbsent) {
    return EnrollmentsCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      studentId: Value(studentId),
      classArmId: Value(classArmId),
      academicYearId: Value(academicYearId),
      enrollmentDate: Value(enrollmentDate),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
    );
  }

  factory Enrollment.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Enrollment(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      studentId: serializer.fromJson<String>(json['studentId']),
      classArmId: serializer.fromJson<String>(json['classArmId']),
      academicYearId: serializer.fromJson<String>(json['academicYearId']),
      enrollmentDate: serializer.fromJson<String>(json['enrollmentDate']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'studentId': serializer.toJson<String>(studentId),
      'classArmId': serializer.toJson<String>(classArmId),
      'academicYearId': serializer.toJson<String>(academicYearId),
      'enrollmentDate': serializer.toJson<String>(enrollmentDate),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  Enrollment copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          String? studentId,
          String? classArmId,
          String? academicYearId,
          String? enrollmentDate,
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt}) =>
      Enrollment(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        studentId: studentId ?? this.studentId,
        classArmId: classArmId ?? this.classArmId,
        academicYearId: academicYearId ?? this.academicYearId,
        enrollmentDate: enrollmentDate ?? this.enrollmentDate,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
      );
  Enrollment copyWithCompanion(EnrollmentsCompanion data) {
    return Enrollment(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      studentId: data.studentId.present ? data.studentId.value : this.studentId,
      classArmId:
          data.classArmId.present ? data.classArmId.value : this.classArmId,
      academicYearId: data.academicYearId.present
          ? data.academicYearId.value
          : this.academicYearId,
      enrollmentDate: data.enrollmentDate.present
          ? data.enrollmentDate.value
          : this.enrollmentDate,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Enrollment(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('studentId: $studentId, ')
          ..write('classArmId: $classArmId, ')
          ..write('academicYearId: $academicYearId, ')
          ..write('enrollmentDate: $enrollmentDate, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, tenantId, schoolId, studentId, classArmId,
      academicYearId, enrollmentDate, serverRevision, deleted, createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Enrollment &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.studentId == this.studentId &&
          other.classArmId == this.classArmId &&
          other.academicYearId == this.academicYearId &&
          other.enrollmentDate == this.enrollmentDate &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt);
}

class EnrollmentsCompanion extends UpdateCompanion<Enrollment> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String> studentId;
  final Value<String> classArmId;
  final Value<String> academicYearId;
  final Value<String> enrollmentDate;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const EnrollmentsCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.studentId = const Value.absent(),
    this.classArmId = const Value.absent(),
    this.academicYearId = const Value.absent(),
    this.enrollmentDate = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  EnrollmentsCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    required String studentId,
    required String classArmId,
    required String academicYearId,
    required String enrollmentDate,
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        studentId = Value(studentId),
        classArmId = Value(classArmId),
        academicYearId = Value(academicYearId),
        enrollmentDate = Value(enrollmentDate);
  static Insertable<Enrollment> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? studentId,
    Expression<String>? classArmId,
    Expression<String>? academicYearId,
    Expression<String>? enrollmentDate,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (studentId != null) 'student_id': studentId,
      if (classArmId != null) 'class_arm_id': classArmId,
      if (academicYearId != null) 'academic_year_id': academicYearId,
      if (enrollmentDate != null) 'enrollment_date': enrollmentDate,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  EnrollmentsCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String>? studentId,
      Value<String>? classArmId,
      Value<String>? academicYearId,
      Value<String>? enrollmentDate,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return EnrollmentsCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      studentId: studentId ?? this.studentId,
      classArmId: classArmId ?? this.classArmId,
      academicYearId: academicYearId ?? this.academicYearId,
      enrollmentDate: enrollmentDate ?? this.enrollmentDate,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (studentId.present) {
      map['student_id'] = Variable<String>(studentId.value);
    }
    if (classArmId.present) {
      map['class_arm_id'] = Variable<String>(classArmId.value);
    }
    if (academicYearId.present) {
      map['academic_year_id'] = Variable<String>(academicYearId.value);
    }
    if (enrollmentDate.present) {
      map['enrollment_date'] = Variable<String>(enrollmentDate.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EnrollmentsCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('studentId: $studentId, ')
          ..write('classArmId: $classArmId, ')
          ..write('academicYearId: $academicYearId, ')
          ..write('enrollmentDate: $enrollmentDate, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $StaffTable extends Staff with TableInfo<$StaffTable, StaffData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $StaffTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _campusIdMeta =
      const VerificationMeta('campusId');
  @override
  late final GeneratedColumn<String> campusId = GeneratedColumn<String>(
      'campus_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _staffNumberMeta =
      const VerificationMeta('staffNumber');
  @override
  late final GeneratedColumn<String> staffNumber = GeneratedColumn<String>(
      'staff_number', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _firstNameMeta =
      const VerificationMeta('firstName');
  @override
  late final GeneratedColumn<String> firstName = GeneratedColumn<String>(
      'first_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _middleNameMeta =
      const VerificationMeta('middleName');
  @override
  late final GeneratedColumn<String> middleName = GeneratedColumn<String>(
      'middle_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _lastNameMeta =
      const VerificationMeta('lastName');
  @override
  late final GeneratedColumn<String> lastName = GeneratedColumn<String>(
      'last_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _genderMeta = const VerificationMeta('gender');
  @override
  late final GeneratedColumn<String> gender = GeneratedColumn<String>(
      'gender', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _phoneMeta = const VerificationMeta('phone');
  @override
  late final GeneratedColumn<String> phone = GeneratedColumn<String>(
      'phone', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _departmentMeta =
      const VerificationMeta('department');
  @override
  late final GeneratedColumn<String> department = GeneratedColumn<String>(
      'department', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _systemRoleMeta =
      const VerificationMeta('systemRole');
  @override
  late final GeneratedColumn<String> systemRole = GeneratedColumn<String>(
      'system_role', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('teacher'));
  static const VerificationMeta _employmentTypeMeta =
      const VerificationMeta('employmentType');
  @override
  late final GeneratedColumn<String> employmentType = GeneratedColumn<String>(
      'employment_type', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('permanent'));
  static const VerificationMeta _dateJoinedMeta =
      const VerificationMeta('dateJoined');
  @override
  late final GeneratedColumn<String> dateJoined = GeneratedColumn<String>(
      'date_joined', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(true));
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('local'));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        campusId,
        userId,
        staffNumber,
        firstName,
        middleName,
        lastName,
        gender,
        phone,
        email,
        department,
        systemRole,
        employmentType,
        dateJoined,
        isActive,
        serverRevision,
        syncStatus,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'staff';
  @override
  VerificationContext validateIntegrity(Insertable<StaffData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('campus_id')) {
      context.handle(_campusIdMeta,
          campusId.isAcceptableOrUnknown(data['campus_id']!, _campusIdMeta));
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    }
    if (data.containsKey('staff_number')) {
      context.handle(
          _staffNumberMeta,
          staffNumber.isAcceptableOrUnknown(
              data['staff_number']!, _staffNumberMeta));
    }
    if (data.containsKey('first_name')) {
      context.handle(_firstNameMeta,
          firstName.isAcceptableOrUnknown(data['first_name']!, _firstNameMeta));
    } else if (isInserting) {
      context.missing(_firstNameMeta);
    }
    if (data.containsKey('middle_name')) {
      context.handle(
          _middleNameMeta,
          middleName.isAcceptableOrUnknown(
              data['middle_name']!, _middleNameMeta));
    }
    if (data.containsKey('last_name')) {
      context.handle(_lastNameMeta,
          lastName.isAcceptableOrUnknown(data['last_name']!, _lastNameMeta));
    } else if (isInserting) {
      context.missing(_lastNameMeta);
    }
    if (data.containsKey('gender')) {
      context.handle(_genderMeta,
          gender.isAcceptableOrUnknown(data['gender']!, _genderMeta));
    }
    if (data.containsKey('phone')) {
      context.handle(
          _phoneMeta, phone.isAcceptableOrUnknown(data['phone']!, _phoneMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('department')) {
      context.handle(
          _departmentMeta,
          department.isAcceptableOrUnknown(
              data['department']!, _departmentMeta));
    }
    if (data.containsKey('system_role')) {
      context.handle(
          _systemRoleMeta,
          systemRole.isAcceptableOrUnknown(
              data['system_role']!, _systemRoleMeta));
    }
    if (data.containsKey('employment_type')) {
      context.handle(
          _employmentTypeMeta,
          employmentType.isAcceptableOrUnknown(
              data['employment_type']!, _employmentTypeMeta));
    }
    if (data.containsKey('date_joined')) {
      context.handle(
          _dateJoinedMeta,
          dateJoined.isAcceptableOrUnknown(
              data['date_joined']!, _dateJoinedMeta));
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  StaffData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return StaffData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      campusId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}campus_id']),
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id']),
      staffNumber: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}staff_number']),
      firstName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}first_name'])!,
      middleName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}middle_name']),
      lastName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}last_name'])!,
      gender: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gender']),
      phone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}phone']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      department: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}department']),
      systemRole: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}system_role'])!,
      employmentType: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}employment_type'])!,
      dateJoined: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}date_joined']),
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $StaffTable createAlias(String alias) {
    return $StaffTable(attachedDatabase, alias);
  }
}

class StaffData extends DataClass implements Insertable<StaffData> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String? campusId;
  final String? userId;
  final String? staffNumber;
  final String firstName;
  final String? middleName;
  final String lastName;
  final String? gender;
  final String? phone;
  final String? email;
  final String? department;
  final String systemRole;
  final String employmentType;
  final String? dateJoined;
  final bool isActive;
  final int serverRevision;
  final String syncStatus;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const StaffData(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      this.campusId,
      this.userId,
      this.staffNumber,
      required this.firstName,
      this.middleName,
      required this.lastName,
      this.gender,
      this.phone,
      this.email,
      this.department,
      required this.systemRole,
      required this.employmentType,
      this.dateJoined,
      required this.isActive,
      required this.serverRevision,
      required this.syncStatus,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    if (!nullToAbsent || campusId != null) {
      map['campus_id'] = Variable<String>(campusId);
    }
    if (!nullToAbsent || userId != null) {
      map['user_id'] = Variable<String>(userId);
    }
    if (!nullToAbsent || staffNumber != null) {
      map['staff_number'] = Variable<String>(staffNumber);
    }
    map['first_name'] = Variable<String>(firstName);
    if (!nullToAbsent || middleName != null) {
      map['middle_name'] = Variable<String>(middleName);
    }
    map['last_name'] = Variable<String>(lastName);
    if (!nullToAbsent || gender != null) {
      map['gender'] = Variable<String>(gender);
    }
    if (!nullToAbsent || phone != null) {
      map['phone'] = Variable<String>(phone);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || department != null) {
      map['department'] = Variable<String>(department);
    }
    map['system_role'] = Variable<String>(systemRole);
    map['employment_type'] = Variable<String>(employmentType);
    if (!nullToAbsent || dateJoined != null) {
      map['date_joined'] = Variable<String>(dateJoined);
    }
    map['is_active'] = Variable<bool>(isActive);
    map['server_revision'] = Variable<int>(serverRevision);
    map['sync_status'] = Variable<String>(syncStatus);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  StaffCompanion toCompanion(bool nullToAbsent) {
    return StaffCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      campusId: campusId == null && nullToAbsent
          ? const Value.absent()
          : Value(campusId),
      userId:
          userId == null && nullToAbsent ? const Value.absent() : Value(userId),
      staffNumber: staffNumber == null && nullToAbsent
          ? const Value.absent()
          : Value(staffNumber),
      firstName: Value(firstName),
      middleName: middleName == null && nullToAbsent
          ? const Value.absent()
          : Value(middleName),
      lastName: Value(lastName),
      gender:
          gender == null && nullToAbsent ? const Value.absent() : Value(gender),
      phone:
          phone == null && nullToAbsent ? const Value.absent() : Value(phone),
      email:
          email == null && nullToAbsent ? const Value.absent() : Value(email),
      department: department == null && nullToAbsent
          ? const Value.absent()
          : Value(department),
      systemRole: Value(systemRole),
      employmentType: Value(employmentType),
      dateJoined: dateJoined == null && nullToAbsent
          ? const Value.absent()
          : Value(dateJoined),
      isActive: Value(isActive),
      serverRevision: Value(serverRevision),
      syncStatus: Value(syncStatus),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory StaffData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return StaffData(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      campusId: serializer.fromJson<String?>(json['campusId']),
      userId: serializer.fromJson<String?>(json['userId']),
      staffNumber: serializer.fromJson<String?>(json['staffNumber']),
      firstName: serializer.fromJson<String>(json['firstName']),
      middleName: serializer.fromJson<String?>(json['middleName']),
      lastName: serializer.fromJson<String>(json['lastName']),
      gender: serializer.fromJson<String?>(json['gender']),
      phone: serializer.fromJson<String?>(json['phone']),
      email: serializer.fromJson<String?>(json['email']),
      department: serializer.fromJson<String?>(json['department']),
      systemRole: serializer.fromJson<String>(json['systemRole']),
      employmentType: serializer.fromJson<String>(json['employmentType']),
      dateJoined: serializer.fromJson<String?>(json['dateJoined']),
      isActive: serializer.fromJson<bool>(json['isActive']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'campusId': serializer.toJson<String?>(campusId),
      'userId': serializer.toJson<String?>(userId),
      'staffNumber': serializer.toJson<String?>(staffNumber),
      'firstName': serializer.toJson<String>(firstName),
      'middleName': serializer.toJson<String?>(middleName),
      'lastName': serializer.toJson<String>(lastName),
      'gender': serializer.toJson<String?>(gender),
      'phone': serializer.toJson<String?>(phone),
      'email': serializer.toJson<String?>(email),
      'department': serializer.toJson<String?>(department),
      'systemRole': serializer.toJson<String>(systemRole),
      'employmentType': serializer.toJson<String>(employmentType),
      'dateJoined': serializer.toJson<String?>(dateJoined),
      'isActive': serializer.toJson<bool>(isActive),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  StaffData copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          Value<String?> campusId = const Value.absent(),
          Value<String?> userId = const Value.absent(),
          Value<String?> staffNumber = const Value.absent(),
          String? firstName,
          Value<String?> middleName = const Value.absent(),
          String? lastName,
          Value<String?> gender = const Value.absent(),
          Value<String?> phone = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> department = const Value.absent(),
          String? systemRole,
          String? employmentType,
          Value<String?> dateJoined = const Value.absent(),
          bool? isActive,
          int? serverRevision,
          String? syncStatus,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      StaffData(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        campusId: campusId.present ? campusId.value : this.campusId,
        userId: userId.present ? userId.value : this.userId,
        staffNumber: staffNumber.present ? staffNumber.value : this.staffNumber,
        firstName: firstName ?? this.firstName,
        middleName: middleName.present ? middleName.value : this.middleName,
        lastName: lastName ?? this.lastName,
        gender: gender.present ? gender.value : this.gender,
        phone: phone.present ? phone.value : this.phone,
        email: email.present ? email.value : this.email,
        department: department.present ? department.value : this.department,
        systemRole: systemRole ?? this.systemRole,
        employmentType: employmentType ?? this.employmentType,
        dateJoined: dateJoined.present ? dateJoined.value : this.dateJoined,
        isActive: isActive ?? this.isActive,
        serverRevision: serverRevision ?? this.serverRevision,
        syncStatus: syncStatus ?? this.syncStatus,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  StaffData copyWithCompanion(StaffCompanion data) {
    return StaffData(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      campusId: data.campusId.present ? data.campusId.value : this.campusId,
      userId: data.userId.present ? data.userId.value : this.userId,
      staffNumber:
          data.staffNumber.present ? data.staffNumber.value : this.staffNumber,
      firstName: data.firstName.present ? data.firstName.value : this.firstName,
      middleName:
          data.middleName.present ? data.middleName.value : this.middleName,
      lastName: data.lastName.present ? data.lastName.value : this.lastName,
      gender: data.gender.present ? data.gender.value : this.gender,
      phone: data.phone.present ? data.phone.value : this.phone,
      email: data.email.present ? data.email.value : this.email,
      department:
          data.department.present ? data.department.value : this.department,
      systemRole:
          data.systemRole.present ? data.systemRole.value : this.systemRole,
      employmentType: data.employmentType.present
          ? data.employmentType.value
          : this.employmentType,
      dateJoined:
          data.dateJoined.present ? data.dateJoined.value : this.dateJoined,
      isActive: data.isActive.present ? data.isActive.value : this.isActive,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('StaffData(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('userId: $userId, ')
          ..write('staffNumber: $staffNumber, ')
          ..write('firstName: $firstName, ')
          ..write('middleName: $middleName, ')
          ..write('lastName: $lastName, ')
          ..write('gender: $gender, ')
          ..write('phone: $phone, ')
          ..write('email: $email, ')
          ..write('department: $department, ')
          ..write('systemRole: $systemRole, ')
          ..write('employmentType: $employmentType, ')
          ..write('dateJoined: $dateJoined, ')
          ..write('isActive: $isActive, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        tenantId,
        schoolId,
        campusId,
        userId,
        staffNumber,
        firstName,
        middleName,
        lastName,
        gender,
        phone,
        email,
        department,
        systemRole,
        employmentType,
        dateJoined,
        isActive,
        serverRevision,
        syncStatus,
        deleted,
        createdAt,
        updatedAt
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is StaffData &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.campusId == this.campusId &&
          other.userId == this.userId &&
          other.staffNumber == this.staffNumber &&
          other.firstName == this.firstName &&
          other.middleName == this.middleName &&
          other.lastName == this.lastName &&
          other.gender == this.gender &&
          other.phone == this.phone &&
          other.email == this.email &&
          other.department == this.department &&
          other.systemRole == this.systemRole &&
          other.employmentType == this.employmentType &&
          other.dateJoined == this.dateJoined &&
          other.isActive == this.isActive &&
          other.serverRevision == this.serverRevision &&
          other.syncStatus == this.syncStatus &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class StaffCompanion extends UpdateCompanion<StaffData> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String?> campusId;
  final Value<String?> userId;
  final Value<String?> staffNumber;
  final Value<String> firstName;
  final Value<String?> middleName;
  final Value<String> lastName;
  final Value<String?> gender;
  final Value<String?> phone;
  final Value<String?> email;
  final Value<String?> department;
  final Value<String> systemRole;
  final Value<String> employmentType;
  final Value<String?> dateJoined;
  final Value<bool> isActive;
  final Value<int> serverRevision;
  final Value<String> syncStatus;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const StaffCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.campusId = const Value.absent(),
    this.userId = const Value.absent(),
    this.staffNumber = const Value.absent(),
    this.firstName = const Value.absent(),
    this.middleName = const Value.absent(),
    this.lastName = const Value.absent(),
    this.gender = const Value.absent(),
    this.phone = const Value.absent(),
    this.email = const Value.absent(),
    this.department = const Value.absent(),
    this.systemRole = const Value.absent(),
    this.employmentType = const Value.absent(),
    this.dateJoined = const Value.absent(),
    this.isActive = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  StaffCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    this.campusId = const Value.absent(),
    this.userId = const Value.absent(),
    this.staffNumber = const Value.absent(),
    required String firstName,
    this.middleName = const Value.absent(),
    required String lastName,
    this.gender = const Value.absent(),
    this.phone = const Value.absent(),
    this.email = const Value.absent(),
    this.department = const Value.absent(),
    this.systemRole = const Value.absent(),
    this.employmentType = const Value.absent(),
    this.dateJoined = const Value.absent(),
    this.isActive = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        firstName = Value(firstName),
        lastName = Value(lastName);
  static Insertable<StaffData> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? campusId,
    Expression<String>? userId,
    Expression<String>? staffNumber,
    Expression<String>? firstName,
    Expression<String>? middleName,
    Expression<String>? lastName,
    Expression<String>? gender,
    Expression<String>? phone,
    Expression<String>? email,
    Expression<String>? department,
    Expression<String>? systemRole,
    Expression<String>? employmentType,
    Expression<String>? dateJoined,
    Expression<bool>? isActive,
    Expression<int>? serverRevision,
    Expression<String>? syncStatus,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (campusId != null) 'campus_id': campusId,
      if (userId != null) 'user_id': userId,
      if (staffNumber != null) 'staff_number': staffNumber,
      if (firstName != null) 'first_name': firstName,
      if (middleName != null) 'middle_name': middleName,
      if (lastName != null) 'last_name': lastName,
      if (gender != null) 'gender': gender,
      if (phone != null) 'phone': phone,
      if (email != null) 'email': email,
      if (department != null) 'department': department,
      if (systemRole != null) 'system_role': systemRole,
      if (employmentType != null) 'employment_type': employmentType,
      if (dateJoined != null) 'date_joined': dateJoined,
      if (isActive != null) 'is_active': isActive,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  StaffCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String?>? campusId,
      Value<String?>? userId,
      Value<String?>? staffNumber,
      Value<String>? firstName,
      Value<String?>? middleName,
      Value<String>? lastName,
      Value<String?>? gender,
      Value<String?>? phone,
      Value<String?>? email,
      Value<String?>? department,
      Value<String>? systemRole,
      Value<String>? employmentType,
      Value<String?>? dateJoined,
      Value<bool>? isActive,
      Value<int>? serverRevision,
      Value<String>? syncStatus,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return StaffCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      campusId: campusId ?? this.campusId,
      userId: userId ?? this.userId,
      staffNumber: staffNumber ?? this.staffNumber,
      firstName: firstName ?? this.firstName,
      middleName: middleName ?? this.middleName,
      lastName: lastName ?? this.lastName,
      gender: gender ?? this.gender,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      department: department ?? this.department,
      systemRole: systemRole ?? this.systemRole,
      employmentType: employmentType ?? this.employmentType,
      dateJoined: dateJoined ?? this.dateJoined,
      isActive: isActive ?? this.isActive,
      serverRevision: serverRevision ?? this.serverRevision,
      syncStatus: syncStatus ?? this.syncStatus,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (campusId.present) {
      map['campus_id'] = Variable<String>(campusId.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (staffNumber.present) {
      map['staff_number'] = Variable<String>(staffNumber.value);
    }
    if (firstName.present) {
      map['first_name'] = Variable<String>(firstName.value);
    }
    if (middleName.present) {
      map['middle_name'] = Variable<String>(middleName.value);
    }
    if (lastName.present) {
      map['last_name'] = Variable<String>(lastName.value);
    }
    if (gender.present) {
      map['gender'] = Variable<String>(gender.value);
    }
    if (phone.present) {
      map['phone'] = Variable<String>(phone.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (department.present) {
      map['department'] = Variable<String>(department.value);
    }
    if (systemRole.present) {
      map['system_role'] = Variable<String>(systemRole.value);
    }
    if (employmentType.present) {
      map['employment_type'] = Variable<String>(employmentType.value);
    }
    if (dateJoined.present) {
      map['date_joined'] = Variable<String>(dateJoined.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('StaffCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('userId: $userId, ')
          ..write('staffNumber: $staffNumber, ')
          ..write('firstName: $firstName, ')
          ..write('middleName: $middleName, ')
          ..write('lastName: $lastName, ')
          ..write('gender: $gender, ')
          ..write('phone: $phone, ')
          ..write('email: $email, ')
          ..write('department: $department, ')
          ..write('systemRole: $systemRole, ')
          ..write('employmentType: $employmentType, ')
          ..write('dateJoined: $dateJoined, ')
          ..write('isActive: $isActive, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $StaffTeachingAssignmentsTable extends StaffTeachingAssignments
    with TableInfo<$StaffTeachingAssignmentsTable, StaffTeachingAssignment> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $StaffTeachingAssignmentsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _staffIdMeta =
      const VerificationMeta('staffId');
  @override
  late final GeneratedColumn<String> staffId = GeneratedColumn<String>(
      'staff_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _assignmentTypeMeta =
      const VerificationMeta('assignmentType');
  @override
  late final GeneratedColumn<String> assignmentType = GeneratedColumn<String>(
      'assignment_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _subjectIdMeta =
      const VerificationMeta('subjectId');
  @override
  late final GeneratedColumn<String> subjectId = GeneratedColumn<String>(
      'subject_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _classArmIdMeta =
      const VerificationMeta('classArmId');
  @override
  late final GeneratedColumn<String> classArmId = GeneratedColumn<String>(
      'class_arm_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        staffId,
        assignmentType,
        subjectId,
        classArmId,
        serverRevision,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'staff_teaching_assignments';
  @override
  VerificationContext validateIntegrity(
      Insertable<StaffTeachingAssignment> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('staff_id')) {
      context.handle(_staffIdMeta,
          staffId.isAcceptableOrUnknown(data['staff_id']!, _staffIdMeta));
    } else if (isInserting) {
      context.missing(_staffIdMeta);
    }
    if (data.containsKey('assignment_type')) {
      context.handle(
          _assignmentTypeMeta,
          assignmentType.isAcceptableOrUnknown(
              data['assignment_type']!, _assignmentTypeMeta));
    } else if (isInserting) {
      context.missing(_assignmentTypeMeta);
    }
    if (data.containsKey('subject_id')) {
      context.handle(_subjectIdMeta,
          subjectId.isAcceptableOrUnknown(data['subject_id']!, _subjectIdMeta));
    }
    if (data.containsKey('class_arm_id')) {
      context.handle(
          _classArmIdMeta,
          classArmId.isAcceptableOrUnknown(
              data['class_arm_id']!, _classArmIdMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  StaffTeachingAssignment map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return StaffTeachingAssignment(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      staffId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}staff_id'])!,
      assignmentType: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}assignment_type'])!,
      subjectId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}subject_id']),
      classArmId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}class_arm_id']),
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $StaffTeachingAssignmentsTable createAlias(String alias) {
    return $StaffTeachingAssignmentsTable(attachedDatabase, alias);
  }
}

class StaffTeachingAssignment extends DataClass
    implements Insertable<StaffTeachingAssignment> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String staffId;
  final String assignmentType;
  final String? subjectId;
  final String? classArmId;
  final int serverRevision;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const StaffTeachingAssignment(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      required this.staffId,
      required this.assignmentType,
      this.subjectId,
      this.classArmId,
      required this.serverRevision,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    map['staff_id'] = Variable<String>(staffId);
    map['assignment_type'] = Variable<String>(assignmentType);
    if (!nullToAbsent || subjectId != null) {
      map['subject_id'] = Variable<String>(subjectId);
    }
    if (!nullToAbsent || classArmId != null) {
      map['class_arm_id'] = Variable<String>(classArmId);
    }
    map['server_revision'] = Variable<int>(serverRevision);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  StaffTeachingAssignmentsCompanion toCompanion(bool nullToAbsent) {
    return StaffTeachingAssignmentsCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      staffId: Value(staffId),
      assignmentType: Value(assignmentType),
      subjectId: subjectId == null && nullToAbsent
          ? const Value.absent()
          : Value(subjectId),
      classArmId: classArmId == null && nullToAbsent
          ? const Value.absent()
          : Value(classArmId),
      serverRevision: Value(serverRevision),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory StaffTeachingAssignment.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return StaffTeachingAssignment(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      staffId: serializer.fromJson<String>(json['staffId']),
      assignmentType: serializer.fromJson<String>(json['assignmentType']),
      subjectId: serializer.fromJson<String?>(json['subjectId']),
      classArmId: serializer.fromJson<String?>(json['classArmId']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'staffId': serializer.toJson<String>(staffId),
      'assignmentType': serializer.toJson<String>(assignmentType),
      'subjectId': serializer.toJson<String?>(subjectId),
      'classArmId': serializer.toJson<String?>(classArmId),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  StaffTeachingAssignment copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          String? staffId,
          String? assignmentType,
          Value<String?> subjectId = const Value.absent(),
          Value<String?> classArmId = const Value.absent(),
          int? serverRevision,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      StaffTeachingAssignment(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        staffId: staffId ?? this.staffId,
        assignmentType: assignmentType ?? this.assignmentType,
        subjectId: subjectId.present ? subjectId.value : this.subjectId,
        classArmId: classArmId.present ? classArmId.value : this.classArmId,
        serverRevision: serverRevision ?? this.serverRevision,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  StaffTeachingAssignment copyWithCompanion(
      StaffTeachingAssignmentsCompanion data) {
    return StaffTeachingAssignment(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      staffId: data.staffId.present ? data.staffId.value : this.staffId,
      assignmentType: data.assignmentType.present
          ? data.assignmentType.value
          : this.assignmentType,
      subjectId: data.subjectId.present ? data.subjectId.value : this.subjectId,
      classArmId:
          data.classArmId.present ? data.classArmId.value : this.classArmId,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('StaffTeachingAssignment(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('staffId: $staffId, ')
          ..write('assignmentType: $assignmentType, ')
          ..write('subjectId: $subjectId, ')
          ..write('classArmId: $classArmId, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      tenantId,
      schoolId,
      staffId,
      assignmentType,
      subjectId,
      classArmId,
      serverRevision,
      deleted,
      createdAt,
      updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is StaffTeachingAssignment &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.staffId == this.staffId &&
          other.assignmentType == this.assignmentType &&
          other.subjectId == this.subjectId &&
          other.classArmId == this.classArmId &&
          other.serverRevision == this.serverRevision &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class StaffTeachingAssignmentsCompanion
    extends UpdateCompanion<StaffTeachingAssignment> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String> staffId;
  final Value<String> assignmentType;
  final Value<String?> subjectId;
  final Value<String?> classArmId;
  final Value<int> serverRevision;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const StaffTeachingAssignmentsCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.staffId = const Value.absent(),
    this.assignmentType = const Value.absent(),
    this.subjectId = const Value.absent(),
    this.classArmId = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  StaffTeachingAssignmentsCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    required String staffId,
    required String assignmentType,
    this.subjectId = const Value.absent(),
    this.classArmId = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        staffId = Value(staffId),
        assignmentType = Value(assignmentType);
  static Insertable<StaffTeachingAssignment> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? staffId,
    Expression<String>? assignmentType,
    Expression<String>? subjectId,
    Expression<String>? classArmId,
    Expression<int>? serverRevision,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (staffId != null) 'staff_id': staffId,
      if (assignmentType != null) 'assignment_type': assignmentType,
      if (subjectId != null) 'subject_id': subjectId,
      if (classArmId != null) 'class_arm_id': classArmId,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  StaffTeachingAssignmentsCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String>? staffId,
      Value<String>? assignmentType,
      Value<String?>? subjectId,
      Value<String?>? classArmId,
      Value<int>? serverRevision,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return StaffTeachingAssignmentsCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      staffId: staffId ?? this.staffId,
      assignmentType: assignmentType ?? this.assignmentType,
      subjectId: subjectId ?? this.subjectId,
      classArmId: classArmId ?? this.classArmId,
      serverRevision: serverRevision ?? this.serverRevision,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (staffId.present) {
      map['staff_id'] = Variable<String>(staffId.value);
    }
    if (assignmentType.present) {
      map['assignment_type'] = Variable<String>(assignmentType.value);
    }
    if (subjectId.present) {
      map['subject_id'] = Variable<String>(subjectId.value);
    }
    if (classArmId.present) {
      map['class_arm_id'] = Variable<String>(classArmId.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('StaffTeachingAssignmentsCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('staffId: $staffId, ')
          ..write('assignmentType: $assignmentType, ')
          ..write('subjectId: $subjectId, ')
          ..write('classArmId: $classArmId, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ApplicantsTable extends Applicants
    with TableInfo<$ApplicantsTable, Applicant> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ApplicantsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _campusIdMeta =
      const VerificationMeta('campusId');
  @override
  late final GeneratedColumn<String> campusId = GeneratedColumn<String>(
      'campus_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _firstNameMeta =
      const VerificationMeta('firstName');
  @override
  late final GeneratedColumn<String> firstName = GeneratedColumn<String>(
      'first_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _middleNameMeta =
      const VerificationMeta('middleName');
  @override
  late final GeneratedColumn<String> middleName = GeneratedColumn<String>(
      'middle_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _lastNameMeta =
      const VerificationMeta('lastName');
  @override
  late final GeneratedColumn<String> lastName = GeneratedColumn<String>(
      'last_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _dateOfBirthMeta =
      const VerificationMeta('dateOfBirth');
  @override
  late final GeneratedColumn<String> dateOfBirth = GeneratedColumn<String>(
      'date_of_birth', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _genderMeta = const VerificationMeta('gender');
  @override
  late final GeneratedColumn<String> gender = GeneratedColumn<String>(
      'gender', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _classLevelIdMeta =
      const VerificationMeta('classLevelId');
  @override
  late final GeneratedColumn<String> classLevelId = GeneratedColumn<String>(
      'class_level_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _academicYearIdMeta =
      const VerificationMeta('academicYearId');
  @override
  late final GeneratedColumn<String> academicYearId = GeneratedColumn<String>(
      'academic_year_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('applied'));
  static const VerificationMeta _guardianNameMeta =
      const VerificationMeta('guardianName');
  @override
  late final GeneratedColumn<String> guardianName = GeneratedColumn<String>(
      'guardian_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _guardianPhoneMeta =
      const VerificationMeta('guardianPhone');
  @override
  late final GeneratedColumn<String> guardianPhone = GeneratedColumn<String>(
      'guardian_phone', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _guardianEmailMeta =
      const VerificationMeta('guardianEmail');
  @override
  late final GeneratedColumn<String> guardianEmail = GeneratedColumn<String>(
      'guardian_email', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _documentNotesMeta =
      const VerificationMeta('documentNotes');
  @override
  late final GeneratedColumn<String> documentNotes = GeneratedColumn<String>(
      'document_notes', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _studentIdMeta =
      const VerificationMeta('studentId');
  @override
  late final GeneratedColumn<String> studentId = GeneratedColumn<String>(
      'student_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _admittedAtMeta =
      const VerificationMeta('admittedAt');
  @override
  late final GeneratedColumn<DateTime> admittedAt = GeneratedColumn<DateTime>(
      'admitted_at', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('local'));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        campusId,
        firstName,
        middleName,
        lastName,
        dateOfBirth,
        gender,
        classLevelId,
        academicYearId,
        status,
        guardianName,
        guardianPhone,
        guardianEmail,
        documentNotes,
        studentId,
        admittedAt,
        serverRevision,
        syncStatus,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'applicants';
  @override
  VerificationContext validateIntegrity(Insertable<Applicant> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('campus_id')) {
      context.handle(_campusIdMeta,
          campusId.isAcceptableOrUnknown(data['campus_id']!, _campusIdMeta));
    }
    if (data.containsKey('first_name')) {
      context.handle(_firstNameMeta,
          firstName.isAcceptableOrUnknown(data['first_name']!, _firstNameMeta));
    } else if (isInserting) {
      context.missing(_firstNameMeta);
    }
    if (data.containsKey('middle_name')) {
      context.handle(
          _middleNameMeta,
          middleName.isAcceptableOrUnknown(
              data['middle_name']!, _middleNameMeta));
    }
    if (data.containsKey('last_name')) {
      context.handle(_lastNameMeta,
          lastName.isAcceptableOrUnknown(data['last_name']!, _lastNameMeta));
    } else if (isInserting) {
      context.missing(_lastNameMeta);
    }
    if (data.containsKey('date_of_birth')) {
      context.handle(
          _dateOfBirthMeta,
          dateOfBirth.isAcceptableOrUnknown(
              data['date_of_birth']!, _dateOfBirthMeta));
    }
    if (data.containsKey('gender')) {
      context.handle(_genderMeta,
          gender.isAcceptableOrUnknown(data['gender']!, _genderMeta));
    }
    if (data.containsKey('class_level_id')) {
      context.handle(
          _classLevelIdMeta,
          classLevelId.isAcceptableOrUnknown(
              data['class_level_id']!, _classLevelIdMeta));
    }
    if (data.containsKey('academic_year_id')) {
      context.handle(
          _academicYearIdMeta,
          academicYearId.isAcceptableOrUnknown(
              data['academic_year_id']!, _academicYearIdMeta));
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('guardian_name')) {
      context.handle(
          _guardianNameMeta,
          guardianName.isAcceptableOrUnknown(
              data['guardian_name']!, _guardianNameMeta));
    }
    if (data.containsKey('guardian_phone')) {
      context.handle(
          _guardianPhoneMeta,
          guardianPhone.isAcceptableOrUnknown(
              data['guardian_phone']!, _guardianPhoneMeta));
    }
    if (data.containsKey('guardian_email')) {
      context.handle(
          _guardianEmailMeta,
          guardianEmail.isAcceptableOrUnknown(
              data['guardian_email']!, _guardianEmailMeta));
    }
    if (data.containsKey('document_notes')) {
      context.handle(
          _documentNotesMeta,
          documentNotes.isAcceptableOrUnknown(
              data['document_notes']!, _documentNotesMeta));
    }
    if (data.containsKey('student_id')) {
      context.handle(_studentIdMeta,
          studentId.isAcceptableOrUnknown(data['student_id']!, _studentIdMeta));
    }
    if (data.containsKey('admitted_at')) {
      context.handle(
          _admittedAtMeta,
          admittedAt.isAcceptableOrUnknown(
              data['admitted_at']!, _admittedAtMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Applicant map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Applicant(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      campusId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}campus_id']),
      firstName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}first_name'])!,
      middleName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}middle_name']),
      lastName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}last_name'])!,
      dateOfBirth: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}date_of_birth']),
      gender: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gender']),
      classLevelId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}class_level_id']),
      academicYearId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}academic_year_id']),
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      guardianName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}guardian_name']),
      guardianPhone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}guardian_phone']),
      guardianEmail: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}guardian_email']),
      documentNotes: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}document_notes']),
      studentId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}student_id']),
      admittedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}admitted_at']),
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $ApplicantsTable createAlias(String alias) {
    return $ApplicantsTable(attachedDatabase, alias);
  }
}

class Applicant extends DataClass implements Insertable<Applicant> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String? campusId;
  final String firstName;
  final String? middleName;
  final String lastName;
  final String? dateOfBirth;
  final String? gender;
  final String? classLevelId;
  final String? academicYearId;
  final String status;
  final String? guardianName;
  final String? guardianPhone;
  final String? guardianEmail;
  final String? documentNotes;
  final String? studentId;
  final DateTime? admittedAt;
  final int serverRevision;
  final String syncStatus;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const Applicant(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      this.campusId,
      required this.firstName,
      this.middleName,
      required this.lastName,
      this.dateOfBirth,
      this.gender,
      this.classLevelId,
      this.academicYearId,
      required this.status,
      this.guardianName,
      this.guardianPhone,
      this.guardianEmail,
      this.documentNotes,
      this.studentId,
      this.admittedAt,
      required this.serverRevision,
      required this.syncStatus,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    if (!nullToAbsent || campusId != null) {
      map['campus_id'] = Variable<String>(campusId);
    }
    map['first_name'] = Variable<String>(firstName);
    if (!nullToAbsent || middleName != null) {
      map['middle_name'] = Variable<String>(middleName);
    }
    map['last_name'] = Variable<String>(lastName);
    if (!nullToAbsent || dateOfBirth != null) {
      map['date_of_birth'] = Variable<String>(dateOfBirth);
    }
    if (!nullToAbsent || gender != null) {
      map['gender'] = Variable<String>(gender);
    }
    if (!nullToAbsent || classLevelId != null) {
      map['class_level_id'] = Variable<String>(classLevelId);
    }
    if (!nullToAbsent || academicYearId != null) {
      map['academic_year_id'] = Variable<String>(academicYearId);
    }
    map['status'] = Variable<String>(status);
    if (!nullToAbsent || guardianName != null) {
      map['guardian_name'] = Variable<String>(guardianName);
    }
    if (!nullToAbsent || guardianPhone != null) {
      map['guardian_phone'] = Variable<String>(guardianPhone);
    }
    if (!nullToAbsent || guardianEmail != null) {
      map['guardian_email'] = Variable<String>(guardianEmail);
    }
    if (!nullToAbsent || documentNotes != null) {
      map['document_notes'] = Variable<String>(documentNotes);
    }
    if (!nullToAbsent || studentId != null) {
      map['student_id'] = Variable<String>(studentId);
    }
    if (!nullToAbsent || admittedAt != null) {
      map['admitted_at'] = Variable<DateTime>(admittedAt);
    }
    map['server_revision'] = Variable<int>(serverRevision);
    map['sync_status'] = Variable<String>(syncStatus);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  ApplicantsCompanion toCompanion(bool nullToAbsent) {
    return ApplicantsCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      campusId: campusId == null && nullToAbsent
          ? const Value.absent()
          : Value(campusId),
      firstName: Value(firstName),
      middleName: middleName == null && nullToAbsent
          ? const Value.absent()
          : Value(middleName),
      lastName: Value(lastName),
      dateOfBirth: dateOfBirth == null && nullToAbsent
          ? const Value.absent()
          : Value(dateOfBirth),
      gender:
          gender == null && nullToAbsent ? const Value.absent() : Value(gender),
      classLevelId: classLevelId == null && nullToAbsent
          ? const Value.absent()
          : Value(classLevelId),
      academicYearId: academicYearId == null && nullToAbsent
          ? const Value.absent()
          : Value(academicYearId),
      status: Value(status),
      guardianName: guardianName == null && nullToAbsent
          ? const Value.absent()
          : Value(guardianName),
      guardianPhone: guardianPhone == null && nullToAbsent
          ? const Value.absent()
          : Value(guardianPhone),
      guardianEmail: guardianEmail == null && nullToAbsent
          ? const Value.absent()
          : Value(guardianEmail),
      documentNotes: documentNotes == null && nullToAbsent
          ? const Value.absent()
          : Value(documentNotes),
      studentId: studentId == null && nullToAbsent
          ? const Value.absent()
          : Value(studentId),
      admittedAt: admittedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(admittedAt),
      serverRevision: Value(serverRevision),
      syncStatus: Value(syncStatus),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory Applicant.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Applicant(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      campusId: serializer.fromJson<String?>(json['campusId']),
      firstName: serializer.fromJson<String>(json['firstName']),
      middleName: serializer.fromJson<String?>(json['middleName']),
      lastName: serializer.fromJson<String>(json['lastName']),
      dateOfBirth: serializer.fromJson<String?>(json['dateOfBirth']),
      gender: serializer.fromJson<String?>(json['gender']),
      classLevelId: serializer.fromJson<String?>(json['classLevelId']),
      academicYearId: serializer.fromJson<String?>(json['academicYearId']),
      status: serializer.fromJson<String>(json['status']),
      guardianName: serializer.fromJson<String?>(json['guardianName']),
      guardianPhone: serializer.fromJson<String?>(json['guardianPhone']),
      guardianEmail: serializer.fromJson<String?>(json['guardianEmail']),
      documentNotes: serializer.fromJson<String?>(json['documentNotes']),
      studentId: serializer.fromJson<String?>(json['studentId']),
      admittedAt: serializer.fromJson<DateTime?>(json['admittedAt']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'campusId': serializer.toJson<String?>(campusId),
      'firstName': serializer.toJson<String>(firstName),
      'middleName': serializer.toJson<String?>(middleName),
      'lastName': serializer.toJson<String>(lastName),
      'dateOfBirth': serializer.toJson<String?>(dateOfBirth),
      'gender': serializer.toJson<String?>(gender),
      'classLevelId': serializer.toJson<String?>(classLevelId),
      'academicYearId': serializer.toJson<String?>(academicYearId),
      'status': serializer.toJson<String>(status),
      'guardianName': serializer.toJson<String?>(guardianName),
      'guardianPhone': serializer.toJson<String?>(guardianPhone),
      'guardianEmail': serializer.toJson<String?>(guardianEmail),
      'documentNotes': serializer.toJson<String?>(documentNotes),
      'studentId': serializer.toJson<String?>(studentId),
      'admittedAt': serializer.toJson<DateTime?>(admittedAt),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  Applicant copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          Value<String?> campusId = const Value.absent(),
          String? firstName,
          Value<String?> middleName = const Value.absent(),
          String? lastName,
          Value<String?> dateOfBirth = const Value.absent(),
          Value<String?> gender = const Value.absent(),
          Value<String?> classLevelId = const Value.absent(),
          Value<String?> academicYearId = const Value.absent(),
          String? status,
          Value<String?> guardianName = const Value.absent(),
          Value<String?> guardianPhone = const Value.absent(),
          Value<String?> guardianEmail = const Value.absent(),
          Value<String?> documentNotes = const Value.absent(),
          Value<String?> studentId = const Value.absent(),
          Value<DateTime?> admittedAt = const Value.absent(),
          int? serverRevision,
          String? syncStatus,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      Applicant(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        campusId: campusId.present ? campusId.value : this.campusId,
        firstName: firstName ?? this.firstName,
        middleName: middleName.present ? middleName.value : this.middleName,
        lastName: lastName ?? this.lastName,
        dateOfBirth: dateOfBirth.present ? dateOfBirth.value : this.dateOfBirth,
        gender: gender.present ? gender.value : this.gender,
        classLevelId:
            classLevelId.present ? classLevelId.value : this.classLevelId,
        academicYearId:
            academicYearId.present ? academicYearId.value : this.academicYearId,
        status: status ?? this.status,
        guardianName:
            guardianName.present ? guardianName.value : this.guardianName,
        guardianPhone:
            guardianPhone.present ? guardianPhone.value : this.guardianPhone,
        guardianEmail:
            guardianEmail.present ? guardianEmail.value : this.guardianEmail,
        documentNotes:
            documentNotes.present ? documentNotes.value : this.documentNotes,
        studentId: studentId.present ? studentId.value : this.studentId,
        admittedAt: admittedAt.present ? admittedAt.value : this.admittedAt,
        serverRevision: serverRevision ?? this.serverRevision,
        syncStatus: syncStatus ?? this.syncStatus,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  Applicant copyWithCompanion(ApplicantsCompanion data) {
    return Applicant(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      campusId: data.campusId.present ? data.campusId.value : this.campusId,
      firstName: data.firstName.present ? data.firstName.value : this.firstName,
      middleName:
          data.middleName.present ? data.middleName.value : this.middleName,
      lastName: data.lastName.present ? data.lastName.value : this.lastName,
      dateOfBirth:
          data.dateOfBirth.present ? data.dateOfBirth.value : this.dateOfBirth,
      gender: data.gender.present ? data.gender.value : this.gender,
      classLevelId: data.classLevelId.present
          ? data.classLevelId.value
          : this.classLevelId,
      academicYearId: data.academicYearId.present
          ? data.academicYearId.value
          : this.academicYearId,
      status: data.status.present ? data.status.value : this.status,
      guardianName: data.guardianName.present
          ? data.guardianName.value
          : this.guardianName,
      guardianPhone: data.guardianPhone.present
          ? data.guardianPhone.value
          : this.guardianPhone,
      guardianEmail: data.guardianEmail.present
          ? data.guardianEmail.value
          : this.guardianEmail,
      documentNotes: data.documentNotes.present
          ? data.documentNotes.value
          : this.documentNotes,
      studentId: data.studentId.present ? data.studentId.value : this.studentId,
      admittedAt:
          data.admittedAt.present ? data.admittedAt.value : this.admittedAt,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Applicant(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('firstName: $firstName, ')
          ..write('middleName: $middleName, ')
          ..write('lastName: $lastName, ')
          ..write('dateOfBirth: $dateOfBirth, ')
          ..write('gender: $gender, ')
          ..write('classLevelId: $classLevelId, ')
          ..write('academicYearId: $academicYearId, ')
          ..write('status: $status, ')
          ..write('guardianName: $guardianName, ')
          ..write('guardianPhone: $guardianPhone, ')
          ..write('guardianEmail: $guardianEmail, ')
          ..write('documentNotes: $documentNotes, ')
          ..write('studentId: $studentId, ')
          ..write('admittedAt: $admittedAt, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        tenantId,
        schoolId,
        campusId,
        firstName,
        middleName,
        lastName,
        dateOfBirth,
        gender,
        classLevelId,
        academicYearId,
        status,
        guardianName,
        guardianPhone,
        guardianEmail,
        documentNotes,
        studentId,
        admittedAt,
        serverRevision,
        syncStatus,
        deleted,
        createdAt,
        updatedAt
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Applicant &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.campusId == this.campusId &&
          other.firstName == this.firstName &&
          other.middleName == this.middleName &&
          other.lastName == this.lastName &&
          other.dateOfBirth == this.dateOfBirth &&
          other.gender == this.gender &&
          other.classLevelId == this.classLevelId &&
          other.academicYearId == this.academicYearId &&
          other.status == this.status &&
          other.guardianName == this.guardianName &&
          other.guardianPhone == this.guardianPhone &&
          other.guardianEmail == this.guardianEmail &&
          other.documentNotes == this.documentNotes &&
          other.studentId == this.studentId &&
          other.admittedAt == this.admittedAt &&
          other.serverRevision == this.serverRevision &&
          other.syncStatus == this.syncStatus &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class ApplicantsCompanion extends UpdateCompanion<Applicant> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String?> campusId;
  final Value<String> firstName;
  final Value<String?> middleName;
  final Value<String> lastName;
  final Value<String?> dateOfBirth;
  final Value<String?> gender;
  final Value<String?> classLevelId;
  final Value<String?> academicYearId;
  final Value<String> status;
  final Value<String?> guardianName;
  final Value<String?> guardianPhone;
  final Value<String?> guardianEmail;
  final Value<String?> documentNotes;
  final Value<String?> studentId;
  final Value<DateTime?> admittedAt;
  final Value<int> serverRevision;
  final Value<String> syncStatus;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const ApplicantsCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.campusId = const Value.absent(),
    this.firstName = const Value.absent(),
    this.middleName = const Value.absent(),
    this.lastName = const Value.absent(),
    this.dateOfBirth = const Value.absent(),
    this.gender = const Value.absent(),
    this.classLevelId = const Value.absent(),
    this.academicYearId = const Value.absent(),
    this.status = const Value.absent(),
    this.guardianName = const Value.absent(),
    this.guardianPhone = const Value.absent(),
    this.guardianEmail = const Value.absent(),
    this.documentNotes = const Value.absent(),
    this.studentId = const Value.absent(),
    this.admittedAt = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ApplicantsCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    this.campusId = const Value.absent(),
    required String firstName,
    this.middleName = const Value.absent(),
    required String lastName,
    this.dateOfBirth = const Value.absent(),
    this.gender = const Value.absent(),
    this.classLevelId = const Value.absent(),
    this.academicYearId = const Value.absent(),
    this.status = const Value.absent(),
    this.guardianName = const Value.absent(),
    this.guardianPhone = const Value.absent(),
    this.guardianEmail = const Value.absent(),
    this.documentNotes = const Value.absent(),
    this.studentId = const Value.absent(),
    this.admittedAt = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        firstName = Value(firstName),
        lastName = Value(lastName);
  static Insertable<Applicant> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? campusId,
    Expression<String>? firstName,
    Expression<String>? middleName,
    Expression<String>? lastName,
    Expression<String>? dateOfBirth,
    Expression<String>? gender,
    Expression<String>? classLevelId,
    Expression<String>? academicYearId,
    Expression<String>? status,
    Expression<String>? guardianName,
    Expression<String>? guardianPhone,
    Expression<String>? guardianEmail,
    Expression<String>? documentNotes,
    Expression<String>? studentId,
    Expression<DateTime>? admittedAt,
    Expression<int>? serverRevision,
    Expression<String>? syncStatus,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (campusId != null) 'campus_id': campusId,
      if (firstName != null) 'first_name': firstName,
      if (middleName != null) 'middle_name': middleName,
      if (lastName != null) 'last_name': lastName,
      if (dateOfBirth != null) 'date_of_birth': dateOfBirth,
      if (gender != null) 'gender': gender,
      if (classLevelId != null) 'class_level_id': classLevelId,
      if (academicYearId != null) 'academic_year_id': academicYearId,
      if (status != null) 'status': status,
      if (guardianName != null) 'guardian_name': guardianName,
      if (guardianPhone != null) 'guardian_phone': guardianPhone,
      if (guardianEmail != null) 'guardian_email': guardianEmail,
      if (documentNotes != null) 'document_notes': documentNotes,
      if (studentId != null) 'student_id': studentId,
      if (admittedAt != null) 'admitted_at': admittedAt,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ApplicantsCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String?>? campusId,
      Value<String>? firstName,
      Value<String?>? middleName,
      Value<String>? lastName,
      Value<String?>? dateOfBirth,
      Value<String?>? gender,
      Value<String?>? classLevelId,
      Value<String?>? academicYearId,
      Value<String>? status,
      Value<String?>? guardianName,
      Value<String?>? guardianPhone,
      Value<String?>? guardianEmail,
      Value<String?>? documentNotes,
      Value<String?>? studentId,
      Value<DateTime?>? admittedAt,
      Value<int>? serverRevision,
      Value<String>? syncStatus,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return ApplicantsCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      campusId: campusId ?? this.campusId,
      firstName: firstName ?? this.firstName,
      middleName: middleName ?? this.middleName,
      lastName: lastName ?? this.lastName,
      dateOfBirth: dateOfBirth ?? this.dateOfBirth,
      gender: gender ?? this.gender,
      classLevelId: classLevelId ?? this.classLevelId,
      academicYearId: academicYearId ?? this.academicYearId,
      status: status ?? this.status,
      guardianName: guardianName ?? this.guardianName,
      guardianPhone: guardianPhone ?? this.guardianPhone,
      guardianEmail: guardianEmail ?? this.guardianEmail,
      documentNotes: documentNotes ?? this.documentNotes,
      studentId: studentId ?? this.studentId,
      admittedAt: admittedAt ?? this.admittedAt,
      serverRevision: serverRevision ?? this.serverRevision,
      syncStatus: syncStatus ?? this.syncStatus,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (campusId.present) {
      map['campus_id'] = Variable<String>(campusId.value);
    }
    if (firstName.present) {
      map['first_name'] = Variable<String>(firstName.value);
    }
    if (middleName.present) {
      map['middle_name'] = Variable<String>(middleName.value);
    }
    if (lastName.present) {
      map['last_name'] = Variable<String>(lastName.value);
    }
    if (dateOfBirth.present) {
      map['date_of_birth'] = Variable<String>(dateOfBirth.value);
    }
    if (gender.present) {
      map['gender'] = Variable<String>(gender.value);
    }
    if (classLevelId.present) {
      map['class_level_id'] = Variable<String>(classLevelId.value);
    }
    if (academicYearId.present) {
      map['academic_year_id'] = Variable<String>(academicYearId.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (guardianName.present) {
      map['guardian_name'] = Variable<String>(guardianName.value);
    }
    if (guardianPhone.present) {
      map['guardian_phone'] = Variable<String>(guardianPhone.value);
    }
    if (guardianEmail.present) {
      map['guardian_email'] = Variable<String>(guardianEmail.value);
    }
    if (documentNotes.present) {
      map['document_notes'] = Variable<String>(documentNotes.value);
    }
    if (studentId.present) {
      map['student_id'] = Variable<String>(studentId.value);
    }
    if (admittedAt.present) {
      map['admitted_at'] = Variable<DateTime>(admittedAt.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ApplicantsCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('firstName: $firstName, ')
          ..write('middleName: $middleName, ')
          ..write('lastName: $lastName, ')
          ..write('dateOfBirth: $dateOfBirth, ')
          ..write('gender: $gender, ')
          ..write('classLevelId: $classLevelId, ')
          ..write('academicYearId: $academicYearId, ')
          ..write('status: $status, ')
          ..write('guardianName: $guardianName, ')
          ..write('guardianPhone: $guardianPhone, ')
          ..write('guardianEmail: $guardianEmail, ')
          ..write('documentNotes: $documentNotes, ')
          ..write('studentId: $studentId, ')
          ..write('admittedAt: $admittedAt, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $AttendanceRecordsTable extends AttendanceRecords
    with TableInfo<$AttendanceRecordsTable, AttendanceRecord> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AttendanceRecordsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tenantIdMeta =
      const VerificationMeta('tenantId');
  @override
  late final GeneratedColumn<String> tenantId = GeneratedColumn<String>(
      'tenant_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _schoolIdMeta =
      const VerificationMeta('schoolId');
  @override
  late final GeneratedColumn<String> schoolId = GeneratedColumn<String>(
      'school_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _campusIdMeta =
      const VerificationMeta('campusId');
  @override
  late final GeneratedColumn<String> campusId = GeneratedColumn<String>(
      'campus_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _studentIdMeta =
      const VerificationMeta('studentId');
  @override
  late final GeneratedColumn<String> studentId = GeneratedColumn<String>(
      'student_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _classArmIdMeta =
      const VerificationMeta('classArmId');
  @override
  late final GeneratedColumn<String> classArmId = GeneratedColumn<String>(
      'class_arm_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _academicYearIdMeta =
      const VerificationMeta('academicYearId');
  @override
  late final GeneratedColumn<String> academicYearId = GeneratedColumn<String>(
      'academic_year_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _termIdMeta = const VerificationMeta('termId');
  @override
  late final GeneratedColumn<String> termId = GeneratedColumn<String>(
      'term_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _attendanceDateMeta =
      const VerificationMeta('attendanceDate');
  @override
  late final GeneratedColumn<String> attendanceDate = GeneratedColumn<String>(
      'attendance_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('present'));
  static const VerificationMeta _notesMeta = const VerificationMeta('notes');
  @override
  late final GeneratedColumn<String> notes = GeneratedColumn<String>(
      'notes', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _recordedByUserIdMeta =
      const VerificationMeta('recordedByUserId');
  @override
  late final GeneratedColumn<String> recordedByUserId = GeneratedColumn<String>(
      'recorded_by_user_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _serverRevisionMeta =
      const VerificationMeta('serverRevision');
  @override
  late final GeneratedColumn<int> serverRevision = GeneratedColumn<int>(
      'server_revision', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('local'));
  static const VerificationMeta _deletedMeta =
      const VerificationMeta('deleted');
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
      'deleted', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("deleted" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tenantId,
        schoolId,
        campusId,
        studentId,
        classArmId,
        academicYearId,
        termId,
        attendanceDate,
        status,
        notes,
        recordedByUserId,
        serverRevision,
        syncStatus,
        deleted,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'attendance_records';
  @override
  VerificationContext validateIntegrity(Insertable<AttendanceRecord> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('tenant_id')) {
      context.handle(_tenantIdMeta,
          tenantId.isAcceptableOrUnknown(data['tenant_id']!, _tenantIdMeta));
    } else if (isInserting) {
      context.missing(_tenantIdMeta);
    }
    if (data.containsKey('school_id')) {
      context.handle(_schoolIdMeta,
          schoolId.isAcceptableOrUnknown(data['school_id']!, _schoolIdMeta));
    } else if (isInserting) {
      context.missing(_schoolIdMeta);
    }
    if (data.containsKey('campus_id')) {
      context.handle(_campusIdMeta,
          campusId.isAcceptableOrUnknown(data['campus_id']!, _campusIdMeta));
    }
    if (data.containsKey('student_id')) {
      context.handle(_studentIdMeta,
          studentId.isAcceptableOrUnknown(data['student_id']!, _studentIdMeta));
    } else if (isInserting) {
      context.missing(_studentIdMeta);
    }
    if (data.containsKey('class_arm_id')) {
      context.handle(
          _classArmIdMeta,
          classArmId.isAcceptableOrUnknown(
              data['class_arm_id']!, _classArmIdMeta));
    } else if (isInserting) {
      context.missing(_classArmIdMeta);
    }
    if (data.containsKey('academic_year_id')) {
      context.handle(
          _academicYearIdMeta,
          academicYearId.isAcceptableOrUnknown(
              data['academic_year_id']!, _academicYearIdMeta));
    } else if (isInserting) {
      context.missing(_academicYearIdMeta);
    }
    if (data.containsKey('term_id')) {
      context.handle(_termIdMeta,
          termId.isAcceptableOrUnknown(data['term_id']!, _termIdMeta));
    } else if (isInserting) {
      context.missing(_termIdMeta);
    }
    if (data.containsKey('attendance_date')) {
      context.handle(
          _attendanceDateMeta,
          attendanceDate.isAcceptableOrUnknown(
              data['attendance_date']!, _attendanceDateMeta));
    } else if (isInserting) {
      context.missing(_attendanceDateMeta);
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('notes')) {
      context.handle(
          _notesMeta, notes.isAcceptableOrUnknown(data['notes']!, _notesMeta));
    }
    if (data.containsKey('recorded_by_user_id')) {
      context.handle(
          _recordedByUserIdMeta,
          recordedByUserId.isAcceptableOrUnknown(
              data['recorded_by_user_id']!, _recordedByUserIdMeta));
    }
    if (data.containsKey('server_revision')) {
      context.handle(
          _serverRevisionMeta,
          serverRevision.isAcceptableOrUnknown(
              data['server_revision']!, _serverRevisionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('deleted')) {
      context.handle(_deletedMeta,
          deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  AttendanceRecord map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AttendanceRecord(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      tenantId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tenant_id'])!,
      schoolId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}school_id'])!,
      campusId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}campus_id']),
      studentId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}student_id'])!,
      classArmId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}class_arm_id'])!,
      academicYearId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}academic_year_id'])!,
      termId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}term_id'])!,
      attendanceDate: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}attendance_date'])!,
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      notes: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}notes']),
      recordedByUserId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}recorded_by_user_id']),
      serverRevision: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}server_revision'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      deleted: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}deleted'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $AttendanceRecordsTable createAlias(String alias) {
    return $AttendanceRecordsTable(attachedDatabase, alias);
  }
}

class AttendanceRecord extends DataClass
    implements Insertable<AttendanceRecord> {
  final String id;
  final String tenantId;
  final String schoolId;
  final String? campusId;
  final String studentId;
  final String classArmId;
  final String academicYearId;
  final String termId;
  final String attendanceDate;
  final String status;
  final String? notes;
  final String? recordedByUserId;
  final int serverRevision;
  final String syncStatus;
  final bool deleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  const AttendanceRecord(
      {required this.id,
      required this.tenantId,
      required this.schoolId,
      this.campusId,
      required this.studentId,
      required this.classArmId,
      required this.academicYearId,
      required this.termId,
      required this.attendanceDate,
      required this.status,
      this.notes,
      this.recordedByUserId,
      required this.serverRevision,
      required this.syncStatus,
      required this.deleted,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['tenant_id'] = Variable<String>(tenantId);
    map['school_id'] = Variable<String>(schoolId);
    if (!nullToAbsent || campusId != null) {
      map['campus_id'] = Variable<String>(campusId);
    }
    map['student_id'] = Variable<String>(studentId);
    map['class_arm_id'] = Variable<String>(classArmId);
    map['academic_year_id'] = Variable<String>(academicYearId);
    map['term_id'] = Variable<String>(termId);
    map['attendance_date'] = Variable<String>(attendanceDate);
    map['status'] = Variable<String>(status);
    if (!nullToAbsent || notes != null) {
      map['notes'] = Variable<String>(notes);
    }
    if (!nullToAbsent || recordedByUserId != null) {
      map['recorded_by_user_id'] = Variable<String>(recordedByUserId);
    }
    map['server_revision'] = Variable<int>(serverRevision);
    map['sync_status'] = Variable<String>(syncStatus);
    map['deleted'] = Variable<bool>(deleted);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  AttendanceRecordsCompanion toCompanion(bool nullToAbsent) {
    return AttendanceRecordsCompanion(
      id: Value(id),
      tenantId: Value(tenantId),
      schoolId: Value(schoolId),
      campusId: campusId == null && nullToAbsent
          ? const Value.absent()
          : Value(campusId),
      studentId: Value(studentId),
      classArmId: Value(classArmId),
      academicYearId: Value(academicYearId),
      termId: Value(termId),
      attendanceDate: Value(attendanceDate),
      status: Value(status),
      notes:
          notes == null && nullToAbsent ? const Value.absent() : Value(notes),
      recordedByUserId: recordedByUserId == null && nullToAbsent
          ? const Value.absent()
          : Value(recordedByUserId),
      serverRevision: Value(serverRevision),
      syncStatus: Value(syncStatus),
      deleted: Value(deleted),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory AttendanceRecord.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AttendanceRecord(
      id: serializer.fromJson<String>(json['id']),
      tenantId: serializer.fromJson<String>(json['tenantId']),
      schoolId: serializer.fromJson<String>(json['schoolId']),
      campusId: serializer.fromJson<String?>(json['campusId']),
      studentId: serializer.fromJson<String>(json['studentId']),
      classArmId: serializer.fromJson<String>(json['classArmId']),
      academicYearId: serializer.fromJson<String>(json['academicYearId']),
      termId: serializer.fromJson<String>(json['termId']),
      attendanceDate: serializer.fromJson<String>(json['attendanceDate']),
      status: serializer.fromJson<String>(json['status']),
      notes: serializer.fromJson<String?>(json['notes']),
      recordedByUserId: serializer.fromJson<String?>(json['recordedByUserId']),
      serverRevision: serializer.fromJson<int>(json['serverRevision']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      deleted: serializer.fromJson<bool>(json['deleted']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'tenantId': serializer.toJson<String>(tenantId),
      'schoolId': serializer.toJson<String>(schoolId),
      'campusId': serializer.toJson<String?>(campusId),
      'studentId': serializer.toJson<String>(studentId),
      'classArmId': serializer.toJson<String>(classArmId),
      'academicYearId': serializer.toJson<String>(academicYearId),
      'termId': serializer.toJson<String>(termId),
      'attendanceDate': serializer.toJson<String>(attendanceDate),
      'status': serializer.toJson<String>(status),
      'notes': serializer.toJson<String?>(notes),
      'recordedByUserId': serializer.toJson<String?>(recordedByUserId),
      'serverRevision': serializer.toJson<int>(serverRevision),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'deleted': serializer.toJson<bool>(deleted),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  AttendanceRecord copyWith(
          {String? id,
          String? tenantId,
          String? schoolId,
          Value<String?> campusId = const Value.absent(),
          String? studentId,
          String? classArmId,
          String? academicYearId,
          String? termId,
          String? attendanceDate,
          String? status,
          Value<String?> notes = const Value.absent(),
          Value<String?> recordedByUserId = const Value.absent(),
          int? serverRevision,
          String? syncStatus,
          bool? deleted,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      AttendanceRecord(
        id: id ?? this.id,
        tenantId: tenantId ?? this.tenantId,
        schoolId: schoolId ?? this.schoolId,
        campusId: campusId.present ? campusId.value : this.campusId,
        studentId: studentId ?? this.studentId,
        classArmId: classArmId ?? this.classArmId,
        academicYearId: academicYearId ?? this.academicYearId,
        termId: termId ?? this.termId,
        attendanceDate: attendanceDate ?? this.attendanceDate,
        status: status ?? this.status,
        notes: notes.present ? notes.value : this.notes,
        recordedByUserId: recordedByUserId.present
            ? recordedByUserId.value
            : this.recordedByUserId,
        serverRevision: serverRevision ?? this.serverRevision,
        syncStatus: syncStatus ?? this.syncStatus,
        deleted: deleted ?? this.deleted,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  AttendanceRecord copyWithCompanion(AttendanceRecordsCompanion data) {
    return AttendanceRecord(
      id: data.id.present ? data.id.value : this.id,
      tenantId: data.tenantId.present ? data.tenantId.value : this.tenantId,
      schoolId: data.schoolId.present ? data.schoolId.value : this.schoolId,
      campusId: data.campusId.present ? data.campusId.value : this.campusId,
      studentId: data.studentId.present ? data.studentId.value : this.studentId,
      classArmId:
          data.classArmId.present ? data.classArmId.value : this.classArmId,
      academicYearId: data.academicYearId.present
          ? data.academicYearId.value
          : this.academicYearId,
      termId: data.termId.present ? data.termId.value : this.termId,
      attendanceDate: data.attendanceDate.present
          ? data.attendanceDate.value
          : this.attendanceDate,
      status: data.status.present ? data.status.value : this.status,
      notes: data.notes.present ? data.notes.value : this.notes,
      recordedByUserId: data.recordedByUserId.present
          ? data.recordedByUserId.value
          : this.recordedByUserId,
      serverRevision: data.serverRevision.present
          ? data.serverRevision.value
          : this.serverRevision,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('AttendanceRecord(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('studentId: $studentId, ')
          ..write('classArmId: $classArmId, ')
          ..write('academicYearId: $academicYearId, ')
          ..write('termId: $termId, ')
          ..write('attendanceDate: $attendanceDate, ')
          ..write('status: $status, ')
          ..write('notes: $notes, ')
          ..write('recordedByUserId: $recordedByUserId, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      tenantId,
      schoolId,
      campusId,
      studentId,
      classArmId,
      academicYearId,
      termId,
      attendanceDate,
      status,
      notes,
      recordedByUserId,
      serverRevision,
      syncStatus,
      deleted,
      createdAt,
      updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AttendanceRecord &&
          other.id == this.id &&
          other.tenantId == this.tenantId &&
          other.schoolId == this.schoolId &&
          other.campusId == this.campusId &&
          other.studentId == this.studentId &&
          other.classArmId == this.classArmId &&
          other.academicYearId == this.academicYearId &&
          other.termId == this.termId &&
          other.attendanceDate == this.attendanceDate &&
          other.status == this.status &&
          other.notes == this.notes &&
          other.recordedByUserId == this.recordedByUserId &&
          other.serverRevision == this.serverRevision &&
          other.syncStatus == this.syncStatus &&
          other.deleted == this.deleted &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class AttendanceRecordsCompanion extends UpdateCompanion<AttendanceRecord> {
  final Value<String> id;
  final Value<String> tenantId;
  final Value<String> schoolId;
  final Value<String?> campusId;
  final Value<String> studentId;
  final Value<String> classArmId;
  final Value<String> academicYearId;
  final Value<String> termId;
  final Value<String> attendanceDate;
  final Value<String> status;
  final Value<String?> notes;
  final Value<String?> recordedByUserId;
  final Value<int> serverRevision;
  final Value<String> syncStatus;
  final Value<bool> deleted;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const AttendanceRecordsCompanion({
    this.id = const Value.absent(),
    this.tenantId = const Value.absent(),
    this.schoolId = const Value.absent(),
    this.campusId = const Value.absent(),
    this.studentId = const Value.absent(),
    this.classArmId = const Value.absent(),
    this.academicYearId = const Value.absent(),
    this.termId = const Value.absent(),
    this.attendanceDate = const Value.absent(),
    this.status = const Value.absent(),
    this.notes = const Value.absent(),
    this.recordedByUserId = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  AttendanceRecordsCompanion.insert({
    required String id,
    required String tenantId,
    required String schoolId,
    this.campusId = const Value.absent(),
    required String studentId,
    required String classArmId,
    required String academicYearId,
    required String termId,
    required String attendanceDate,
    this.status = const Value.absent(),
    this.notes = const Value.absent(),
    this.recordedByUserId = const Value.absent(),
    this.serverRevision = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.deleted = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        tenantId = Value(tenantId),
        schoolId = Value(schoolId),
        studentId = Value(studentId),
        classArmId = Value(classArmId),
        academicYearId = Value(academicYearId),
        termId = Value(termId),
        attendanceDate = Value(attendanceDate);
  static Insertable<AttendanceRecord> custom({
    Expression<String>? id,
    Expression<String>? tenantId,
    Expression<String>? schoolId,
    Expression<String>? campusId,
    Expression<String>? studentId,
    Expression<String>? classArmId,
    Expression<String>? academicYearId,
    Expression<String>? termId,
    Expression<String>? attendanceDate,
    Expression<String>? status,
    Expression<String>? notes,
    Expression<String>? recordedByUserId,
    Expression<int>? serverRevision,
    Expression<String>? syncStatus,
    Expression<bool>? deleted,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tenantId != null) 'tenant_id': tenantId,
      if (schoolId != null) 'school_id': schoolId,
      if (campusId != null) 'campus_id': campusId,
      if (studentId != null) 'student_id': studentId,
      if (classArmId != null) 'class_arm_id': classArmId,
      if (academicYearId != null) 'academic_year_id': academicYearId,
      if (termId != null) 'term_id': termId,
      if (attendanceDate != null) 'attendance_date': attendanceDate,
      if (status != null) 'status': status,
      if (notes != null) 'notes': notes,
      if (recordedByUserId != null) 'recorded_by_user_id': recordedByUserId,
      if (serverRevision != null) 'server_revision': serverRevision,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (deleted != null) 'deleted': deleted,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  AttendanceRecordsCompanion copyWith(
      {Value<String>? id,
      Value<String>? tenantId,
      Value<String>? schoolId,
      Value<String?>? campusId,
      Value<String>? studentId,
      Value<String>? classArmId,
      Value<String>? academicYearId,
      Value<String>? termId,
      Value<String>? attendanceDate,
      Value<String>? status,
      Value<String?>? notes,
      Value<String?>? recordedByUserId,
      Value<int>? serverRevision,
      Value<String>? syncStatus,
      Value<bool>? deleted,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return AttendanceRecordsCompanion(
      id: id ?? this.id,
      tenantId: tenantId ?? this.tenantId,
      schoolId: schoolId ?? this.schoolId,
      campusId: campusId ?? this.campusId,
      studentId: studentId ?? this.studentId,
      classArmId: classArmId ?? this.classArmId,
      academicYearId: academicYearId ?? this.academicYearId,
      termId: termId ?? this.termId,
      attendanceDate: attendanceDate ?? this.attendanceDate,
      status: status ?? this.status,
      notes: notes ?? this.notes,
      recordedByUserId: recordedByUserId ?? this.recordedByUserId,
      serverRevision: serverRevision ?? this.serverRevision,
      syncStatus: syncStatus ?? this.syncStatus,
      deleted: deleted ?? this.deleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (tenantId.present) {
      map['tenant_id'] = Variable<String>(tenantId.value);
    }
    if (schoolId.present) {
      map['school_id'] = Variable<String>(schoolId.value);
    }
    if (campusId.present) {
      map['campus_id'] = Variable<String>(campusId.value);
    }
    if (studentId.present) {
      map['student_id'] = Variable<String>(studentId.value);
    }
    if (classArmId.present) {
      map['class_arm_id'] = Variable<String>(classArmId.value);
    }
    if (academicYearId.present) {
      map['academic_year_id'] = Variable<String>(academicYearId.value);
    }
    if (termId.present) {
      map['term_id'] = Variable<String>(termId.value);
    }
    if (attendanceDate.present) {
      map['attendance_date'] = Variable<String>(attendanceDate.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (notes.present) {
      map['notes'] = Variable<String>(notes.value);
    }
    if (recordedByUserId.present) {
      map['recorded_by_user_id'] = Variable<String>(recordedByUserId.value);
    }
    if (serverRevision.present) {
      map['server_revision'] = Variable<int>(serverRevision.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AttendanceRecordsCompanion(')
          ..write('id: $id, ')
          ..write('tenantId: $tenantId, ')
          ..write('schoolId: $schoolId, ')
          ..write('campusId: $campusId, ')
          ..write('studentId: $studentId, ')
          ..write('classArmId: $classArmId, ')
          ..write('academicYearId: $academicYearId, ')
          ..write('termId: $termId, ')
          ..write('attendanceDate: $attendanceDate, ')
          ..write('status: $status, ')
          ..write('notes: $notes, ')
          ..write('recordedByUserId: $recordedByUserId, ')
          ..write('serverRevision: $serverRevision, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('deleted: $deleted, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $SyncQueueTable syncQueue = $SyncQueueTable(this);
  late final $SyncStateTable syncState = $SyncStateTable(this);
  late final $SyncConflictsTable syncConflicts = $SyncConflictsTable(this);
  late final $SyncReconciliationRequestsCacheTable
      syncReconciliationRequestsCache =
      $SyncReconciliationRequestsCacheTable(this);
  late final $AcademicYearsCacheTable academicYearsCache =
      $AcademicYearsCacheTable(this);
  late final $TermsCacheTable termsCache = $TermsCacheTable(this);
  late final $ClassLevelsCacheTable classLevelsCache =
      $ClassLevelsCacheTable(this);
  late final $ClassArmsCacheTable classArmsCache = $ClassArmsCacheTable(this);
  late final $SubjectsCacheTable subjectsCache = $SubjectsCacheTable(this);
  late final $GradingSchemesCacheTable gradingSchemesCache =
      $GradingSchemesCacheTable(this);
  late final $FeeCategoriesTable feeCategories = $FeeCategoriesTable(this);
  late final $FeeStructureItemsTable feeStructureItems =
      $FeeStructureItemsTable(this);
  late final $InvoicesTable invoices = $InvoicesTable(this);
  late final $PaymentsTable payments = $PaymentsTable(this);
  late final $PaymentReversalsTable paymentReversals =
      $PaymentReversalsTable(this);
  late final $SchoolProfileCacheTable schoolProfileCache =
      $SchoolProfileCacheTable(this);
  late final $CampusProfileCacheTable campusProfileCache =
      $CampusProfileCacheTable(this);
  late final $StudentsTable students = $StudentsTable(this);
  late final $GuardiansTable guardians = $GuardiansTable(this);
  late final $EnrollmentsTable enrollments = $EnrollmentsTable(this);
  late final $StaffTable staff = $StaffTable(this);
  late final $StaffTeachingAssignmentsTable staffTeachingAssignments =
      $StaffTeachingAssignmentsTable(this);
  late final $ApplicantsTable applicants = $ApplicantsTable(this);
  late final $AttendanceRecordsTable attendanceRecords =
      $AttendanceRecordsTable(this);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        syncQueue,
        syncState,
        syncConflicts,
        syncReconciliationRequestsCache,
        academicYearsCache,
        termsCache,
        classLevelsCache,
        classArmsCache,
        subjectsCache,
        gradingSchemesCache,
        feeCategories,
        feeStructureItems,
        invoices,
        payments,
        paymentReversals,
        schoolProfileCache,
        campusProfileCache,
        students,
        guardians,
        enrollments,
        staff,
        staffTeachingAssignments,
        applicants,
        attendanceRecords
      ];
}

typedef $$SyncQueueTableCreateCompanionBuilder = SyncQueueCompanion Function({
  required String id,
  required String entityType,
  required String entityId,
  required String operation,
  required String payloadJson,
  Value<String> status,
  Value<int> retryCount,
  required String idempotencyKey,
  Value<int> lamportClock,
  Value<DateTime> createdAt,
  Value<int> rowid,
});
typedef $$SyncQueueTableUpdateCompanionBuilder = SyncQueueCompanion Function({
  Value<String> id,
  Value<String> entityType,
  Value<String> entityId,
  Value<String> operation,
  Value<String> payloadJson,
  Value<String> status,
  Value<int> retryCount,
  Value<String> idempotencyKey,
  Value<int> lamportClock,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$SyncQueueTableFilterComposer
    extends Composer<_$AppDatabase, $SyncQueueTable> {
  $$SyncQueueTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get operation => $composableBuilder(
      column: $table.operation, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get retryCount => $composableBuilder(
      column: $table.retryCount, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get idempotencyKey => $composableBuilder(
      column: $table.idempotencyKey,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get lamportClock => $composableBuilder(
      column: $table.lamportClock, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$SyncQueueTableOrderingComposer
    extends Composer<_$AppDatabase, $SyncQueueTable> {
  $$SyncQueueTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get operation => $composableBuilder(
      column: $table.operation, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get retryCount => $composableBuilder(
      column: $table.retryCount, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get idempotencyKey => $composableBuilder(
      column: $table.idempotencyKey,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get lamportClock => $composableBuilder(
      column: $table.lamportClock,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$SyncQueueTableAnnotationComposer
    extends Composer<_$AppDatabase, $SyncQueueTable> {
  $$SyncQueueTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => column);

  GeneratedColumn<String> get entityId =>
      $composableBuilder(column: $table.entityId, builder: (column) => column);

  GeneratedColumn<String> get operation =>
      $composableBuilder(column: $table.operation, builder: (column) => column);

  GeneratedColumn<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<int> get retryCount => $composableBuilder(
      column: $table.retryCount, builder: (column) => column);

  GeneratedColumn<String> get idempotencyKey => $composableBuilder(
      column: $table.idempotencyKey, builder: (column) => column);

  GeneratedColumn<int> get lamportClock => $composableBuilder(
      column: $table.lamportClock, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$SyncQueueTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SyncQueueTable,
    SyncQueueData,
    $$SyncQueueTableFilterComposer,
    $$SyncQueueTableOrderingComposer,
    $$SyncQueueTableAnnotationComposer,
    $$SyncQueueTableCreateCompanionBuilder,
    $$SyncQueueTableUpdateCompanionBuilder,
    (
      SyncQueueData,
      BaseReferences<_$AppDatabase, $SyncQueueTable, SyncQueueData>
    ),
    SyncQueueData,
    PrefetchHooks Function()> {
  $$SyncQueueTableTableManager(_$AppDatabase db, $SyncQueueTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SyncQueueTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SyncQueueTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SyncQueueTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> entityType = const Value.absent(),
            Value<String> entityId = const Value.absent(),
            Value<String> operation = const Value.absent(),
            Value<String> payloadJson = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<int> retryCount = const Value.absent(),
            Value<String> idempotencyKey = const Value.absent(),
            Value<int> lamportClock = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncQueueCompanion(
            id: id,
            entityType: entityType,
            entityId: entityId,
            operation: operation,
            payloadJson: payloadJson,
            status: status,
            retryCount: retryCount,
            idempotencyKey: idempotencyKey,
            lamportClock: lamportClock,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String entityType,
            required String entityId,
            required String operation,
            required String payloadJson,
            Value<String> status = const Value.absent(),
            Value<int> retryCount = const Value.absent(),
            required String idempotencyKey,
            Value<int> lamportClock = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncQueueCompanion.insert(
            id: id,
            entityType: entityType,
            entityId: entityId,
            operation: operation,
            payloadJson: payloadJson,
            status: status,
            retryCount: retryCount,
            idempotencyKey: idempotencyKey,
            lamportClock: lamportClock,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SyncQueueTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SyncQueueTable,
    SyncQueueData,
    $$SyncQueueTableFilterComposer,
    $$SyncQueueTableOrderingComposer,
    $$SyncQueueTableAnnotationComposer,
    $$SyncQueueTableCreateCompanionBuilder,
    $$SyncQueueTableUpdateCompanionBuilder,
    (
      SyncQueueData,
      BaseReferences<_$AppDatabase, $SyncQueueTable, SyncQueueData>
    ),
    SyncQueueData,
    PrefetchHooks Function()>;
typedef $$SyncStateTableCreateCompanionBuilder = SyncStateCompanion Function({
  required String entityType,
  Value<int> lastServerRevision,
  Value<DateTime?> lastPulledAt,
  Value<int> rowid,
});
typedef $$SyncStateTableUpdateCompanionBuilder = SyncStateCompanion Function({
  Value<String> entityType,
  Value<int> lastServerRevision,
  Value<DateTime?> lastPulledAt,
  Value<int> rowid,
});

class $$SyncStateTableFilterComposer
    extends Composer<_$AppDatabase, $SyncStateTable> {
  $$SyncStateTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get lastServerRevision => $composableBuilder(
      column: $table.lastServerRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get lastPulledAt => $composableBuilder(
      column: $table.lastPulledAt, builder: (column) => ColumnFilters(column));
}

class $$SyncStateTableOrderingComposer
    extends Composer<_$AppDatabase, $SyncStateTable> {
  $$SyncStateTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get lastServerRevision => $composableBuilder(
      column: $table.lastServerRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get lastPulledAt => $composableBuilder(
      column: $table.lastPulledAt,
      builder: (column) => ColumnOrderings(column));
}

class $$SyncStateTableAnnotationComposer
    extends Composer<_$AppDatabase, $SyncStateTable> {
  $$SyncStateTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => column);

  GeneratedColumn<int> get lastServerRevision => $composableBuilder(
      column: $table.lastServerRevision, builder: (column) => column);

  GeneratedColumn<DateTime> get lastPulledAt => $composableBuilder(
      column: $table.lastPulledAt, builder: (column) => column);
}

class $$SyncStateTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SyncStateTable,
    SyncStateData,
    $$SyncStateTableFilterComposer,
    $$SyncStateTableOrderingComposer,
    $$SyncStateTableAnnotationComposer,
    $$SyncStateTableCreateCompanionBuilder,
    $$SyncStateTableUpdateCompanionBuilder,
    (
      SyncStateData,
      BaseReferences<_$AppDatabase, $SyncStateTable, SyncStateData>
    ),
    SyncStateData,
    PrefetchHooks Function()> {
  $$SyncStateTableTableManager(_$AppDatabase db, $SyncStateTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SyncStateTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SyncStateTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SyncStateTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> entityType = const Value.absent(),
            Value<int> lastServerRevision = const Value.absent(),
            Value<DateTime?> lastPulledAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncStateCompanion(
            entityType: entityType,
            lastServerRevision: lastServerRevision,
            lastPulledAt: lastPulledAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String entityType,
            Value<int> lastServerRevision = const Value.absent(),
            Value<DateTime?> lastPulledAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncStateCompanion.insert(
            entityType: entityType,
            lastServerRevision: lastServerRevision,
            lastPulledAt: lastPulledAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SyncStateTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SyncStateTable,
    SyncStateData,
    $$SyncStateTableFilterComposer,
    $$SyncStateTableOrderingComposer,
    $$SyncStateTableAnnotationComposer,
    $$SyncStateTableCreateCompanionBuilder,
    $$SyncStateTableUpdateCompanionBuilder,
    (
      SyncStateData,
      BaseReferences<_$AppDatabase, $SyncStateTable, SyncStateData>
    ),
    SyncStateData,
    PrefetchHooks Function()>;
typedef $$SyncConflictsTableCreateCompanionBuilder = SyncConflictsCompanion
    Function({
  required String id,
  Value<String?> queueItemId,
  required String tenantId,
  required String schoolId,
  Value<String?> campusId,
  required String entityType,
  required String entityId,
  required String operation,
  required String conflictType,
  required String payloadJson,
  Value<String?> serverMessage,
  Value<String?> responseJson,
  Value<String> status,
  Value<DateTime> createdAt,
  Value<int> rowid,
});
typedef $$SyncConflictsTableUpdateCompanionBuilder = SyncConflictsCompanion
    Function({
  Value<String> id,
  Value<String?> queueItemId,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String?> campusId,
  Value<String> entityType,
  Value<String> entityId,
  Value<String> operation,
  Value<String> conflictType,
  Value<String> payloadJson,
  Value<String?> serverMessage,
  Value<String?> responseJson,
  Value<String> status,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$SyncConflictsTableFilterComposer
    extends Composer<_$AppDatabase, $SyncConflictsTable> {
  $$SyncConflictsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get queueItemId => $composableBuilder(
      column: $table.queueItemId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get operation => $composableBuilder(
      column: $table.operation, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get conflictType => $composableBuilder(
      column: $table.conflictType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get serverMessage => $composableBuilder(
      column: $table.serverMessage, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get responseJson => $composableBuilder(
      column: $table.responseJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$SyncConflictsTableOrderingComposer
    extends Composer<_$AppDatabase, $SyncConflictsTable> {
  $$SyncConflictsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get queueItemId => $composableBuilder(
      column: $table.queueItemId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get operation => $composableBuilder(
      column: $table.operation, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get conflictType => $composableBuilder(
      column: $table.conflictType,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get serverMessage => $composableBuilder(
      column: $table.serverMessage,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get responseJson => $composableBuilder(
      column: $table.responseJson,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$SyncConflictsTableAnnotationComposer
    extends Composer<_$AppDatabase, $SyncConflictsTable> {
  $$SyncConflictsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get queueItemId => $composableBuilder(
      column: $table.queueItemId, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get campusId =>
      $composableBuilder(column: $table.campusId, builder: (column) => column);

  GeneratedColumn<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => column);

  GeneratedColumn<String> get entityId =>
      $composableBuilder(column: $table.entityId, builder: (column) => column);

  GeneratedColumn<String> get operation =>
      $composableBuilder(column: $table.operation, builder: (column) => column);

  GeneratedColumn<String> get conflictType => $composableBuilder(
      column: $table.conflictType, builder: (column) => column);

  GeneratedColumn<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => column);

  GeneratedColumn<String> get serverMessage => $composableBuilder(
      column: $table.serverMessage, builder: (column) => column);

  GeneratedColumn<String> get responseJson => $composableBuilder(
      column: $table.responseJson, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$SyncConflictsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SyncConflictsTable,
    SyncConflict,
    $$SyncConflictsTableFilterComposer,
    $$SyncConflictsTableOrderingComposer,
    $$SyncConflictsTableAnnotationComposer,
    $$SyncConflictsTableCreateCompanionBuilder,
    $$SyncConflictsTableUpdateCompanionBuilder,
    (
      SyncConflict,
      BaseReferences<_$AppDatabase, $SyncConflictsTable, SyncConflict>
    ),
    SyncConflict,
    PrefetchHooks Function()> {
  $$SyncConflictsTableTableManager(_$AppDatabase db, $SyncConflictsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SyncConflictsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SyncConflictsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SyncConflictsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String?> queueItemId = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String?> campusId = const Value.absent(),
            Value<String> entityType = const Value.absent(),
            Value<String> entityId = const Value.absent(),
            Value<String> operation = const Value.absent(),
            Value<String> conflictType = const Value.absent(),
            Value<String> payloadJson = const Value.absent(),
            Value<String?> serverMessage = const Value.absent(),
            Value<String?> responseJson = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncConflictsCompanion(
            id: id,
            queueItemId: queueItemId,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            entityType: entityType,
            entityId: entityId,
            operation: operation,
            conflictType: conflictType,
            payloadJson: payloadJson,
            serverMessage: serverMessage,
            responseJson: responseJson,
            status: status,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            Value<String?> queueItemId = const Value.absent(),
            required String tenantId,
            required String schoolId,
            Value<String?> campusId = const Value.absent(),
            required String entityType,
            required String entityId,
            required String operation,
            required String conflictType,
            required String payloadJson,
            Value<String?> serverMessage = const Value.absent(),
            Value<String?> responseJson = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncConflictsCompanion.insert(
            id: id,
            queueItemId: queueItemId,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            entityType: entityType,
            entityId: entityId,
            operation: operation,
            conflictType: conflictType,
            payloadJson: payloadJson,
            serverMessage: serverMessage,
            responseJson: responseJson,
            status: status,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SyncConflictsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SyncConflictsTable,
    SyncConflict,
    $$SyncConflictsTableFilterComposer,
    $$SyncConflictsTableOrderingComposer,
    $$SyncConflictsTableAnnotationComposer,
    $$SyncConflictsTableCreateCompanionBuilder,
    $$SyncConflictsTableUpdateCompanionBuilder,
    (
      SyncConflict,
      BaseReferences<_$AppDatabase, $SyncConflictsTable, SyncConflict>
    ),
    SyncConflict,
    PrefetchHooks Function()>;
typedef $$SyncReconciliationRequestsCacheTableCreateCompanionBuilder
    = SyncReconciliationRequestsCacheCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  Value<String?> campusId,
  required String targetDeviceId,
  required String reason,
  Value<String> status,
  required DateTime requestedAt,
  Value<DateTime?> acknowledgedAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$SyncReconciliationRequestsCacheTableUpdateCompanionBuilder
    = SyncReconciliationRequestsCacheCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String?> campusId,
  Value<String> targetDeviceId,
  Value<String> reason,
  Value<String> status,
  Value<DateTime> requestedAt,
  Value<DateTime?> acknowledgedAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$SyncReconciliationRequestsCacheTableFilterComposer
    extends Composer<_$AppDatabase, $SyncReconciliationRequestsCacheTable> {
  $$SyncReconciliationRequestsCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get targetDeviceId => $composableBuilder(
      column: $table.targetDeviceId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get reason => $composableBuilder(
      column: $table.reason, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get requestedAt => $composableBuilder(
      column: $table.requestedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get acknowledgedAt => $composableBuilder(
      column: $table.acknowledgedAt,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$SyncReconciliationRequestsCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $SyncReconciliationRequestsCacheTable> {
  $$SyncReconciliationRequestsCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get targetDeviceId => $composableBuilder(
      column: $table.targetDeviceId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get reason => $composableBuilder(
      column: $table.reason, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get requestedAt => $composableBuilder(
      column: $table.requestedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get acknowledgedAt => $composableBuilder(
      column: $table.acknowledgedAt,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$SyncReconciliationRequestsCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $SyncReconciliationRequestsCacheTable> {
  $$SyncReconciliationRequestsCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get campusId =>
      $composableBuilder(column: $table.campusId, builder: (column) => column);

  GeneratedColumn<String> get targetDeviceId => $composableBuilder(
      column: $table.targetDeviceId, builder: (column) => column);

  GeneratedColumn<String> get reason =>
      $composableBuilder(column: $table.reason, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<DateTime> get requestedAt => $composableBuilder(
      column: $table.requestedAt, builder: (column) => column);

  GeneratedColumn<DateTime> get acknowledgedAt => $composableBuilder(
      column: $table.acknowledgedAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$SyncReconciliationRequestsCacheTableTableManager
    extends RootTableManager<
        _$AppDatabase,
        $SyncReconciliationRequestsCacheTable,
        SyncReconciliationRequestsCacheData,
        $$SyncReconciliationRequestsCacheTableFilterComposer,
        $$SyncReconciliationRequestsCacheTableOrderingComposer,
        $$SyncReconciliationRequestsCacheTableAnnotationComposer,
        $$SyncReconciliationRequestsCacheTableCreateCompanionBuilder,
        $$SyncReconciliationRequestsCacheTableUpdateCompanionBuilder,
        (
          SyncReconciliationRequestsCacheData,
          BaseReferences<_$AppDatabase, $SyncReconciliationRequestsCacheTable,
              SyncReconciliationRequestsCacheData>
        ),
        SyncReconciliationRequestsCacheData,
        PrefetchHooks Function()> {
  $$SyncReconciliationRequestsCacheTableTableManager(
      _$AppDatabase db, $SyncReconciliationRequestsCacheTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SyncReconciliationRequestsCacheTableFilterComposer(
                  $db: db, $table: table),
          createOrderingComposer: () =>
              $$SyncReconciliationRequestsCacheTableOrderingComposer(
                  $db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SyncReconciliationRequestsCacheTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String?> campusId = const Value.absent(),
            Value<String> targetDeviceId = const Value.absent(),
            Value<String> reason = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<DateTime> requestedAt = const Value.absent(),
            Value<DateTime?> acknowledgedAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncReconciliationRequestsCacheCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            targetDeviceId: targetDeviceId,
            reason: reason,
            status: status,
            requestedAt: requestedAt,
            acknowledgedAt: acknowledgedAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            Value<String?> campusId = const Value.absent(),
            required String targetDeviceId,
            required String reason,
            Value<String> status = const Value.absent(),
            required DateTime requestedAt,
            Value<DateTime?> acknowledgedAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncReconciliationRequestsCacheCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            targetDeviceId: targetDeviceId,
            reason: reason,
            status: status,
            requestedAt: requestedAt,
            acknowledgedAt: acknowledgedAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SyncReconciliationRequestsCacheTableProcessedTableManager
    = ProcessedTableManager<
        _$AppDatabase,
        $SyncReconciliationRequestsCacheTable,
        SyncReconciliationRequestsCacheData,
        $$SyncReconciliationRequestsCacheTableFilterComposer,
        $$SyncReconciliationRequestsCacheTableOrderingComposer,
        $$SyncReconciliationRequestsCacheTableAnnotationComposer,
        $$SyncReconciliationRequestsCacheTableCreateCompanionBuilder,
        $$SyncReconciliationRequestsCacheTableUpdateCompanionBuilder,
        (
          SyncReconciliationRequestsCacheData,
          BaseReferences<_$AppDatabase, $SyncReconciliationRequestsCacheTable,
              SyncReconciliationRequestsCacheData>
        ),
        SyncReconciliationRequestsCacheData,
        PrefetchHooks Function()>;
typedef $$AcademicYearsCacheTableCreateCompanionBuilder
    = AcademicYearsCacheCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  required String label,
  required String startDate,
  required String endDate,
  Value<bool> isCurrent,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$AcademicYearsCacheTableUpdateCompanionBuilder
    = AcademicYearsCacheCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String> label,
  Value<String> startDate,
  Value<String> endDate,
  Value<bool> isCurrent,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$AcademicYearsCacheTableFilterComposer
    extends Composer<_$AppDatabase, $AcademicYearsCacheTable> {
  $$AcademicYearsCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get label => $composableBuilder(
      column: $table.label, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get startDate => $composableBuilder(
      column: $table.startDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get endDate => $composableBuilder(
      column: $table.endDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isCurrent => $composableBuilder(
      column: $table.isCurrent, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$AcademicYearsCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $AcademicYearsCacheTable> {
  $$AcademicYearsCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get label => $composableBuilder(
      column: $table.label, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get startDate => $composableBuilder(
      column: $table.startDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get endDate => $composableBuilder(
      column: $table.endDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isCurrent => $composableBuilder(
      column: $table.isCurrent, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$AcademicYearsCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $AcademicYearsCacheTable> {
  $$AcademicYearsCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get label =>
      $composableBuilder(column: $table.label, builder: (column) => column);

  GeneratedColumn<String> get startDate =>
      $composableBuilder(column: $table.startDate, builder: (column) => column);

  GeneratedColumn<String> get endDate =>
      $composableBuilder(column: $table.endDate, builder: (column) => column);

  GeneratedColumn<bool> get isCurrent =>
      $composableBuilder(column: $table.isCurrent, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$AcademicYearsCacheTableTableManager extends RootTableManager<
    _$AppDatabase,
    $AcademicYearsCacheTable,
    AcademicYearsCacheData,
    $$AcademicYearsCacheTableFilterComposer,
    $$AcademicYearsCacheTableOrderingComposer,
    $$AcademicYearsCacheTableAnnotationComposer,
    $$AcademicYearsCacheTableCreateCompanionBuilder,
    $$AcademicYearsCacheTableUpdateCompanionBuilder,
    (
      AcademicYearsCacheData,
      BaseReferences<_$AppDatabase, $AcademicYearsCacheTable,
          AcademicYearsCacheData>
    ),
    AcademicYearsCacheData,
    PrefetchHooks Function()> {
  $$AcademicYearsCacheTableTableManager(
      _$AppDatabase db, $AcademicYearsCacheTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$AcademicYearsCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$AcademicYearsCacheTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$AcademicYearsCacheTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String> label = const Value.absent(),
            Value<String> startDate = const Value.absent(),
            Value<String> endDate = const Value.absent(),
            Value<bool> isCurrent = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AcademicYearsCacheCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            label: label,
            startDate: startDate,
            endDate: endDate,
            isCurrent: isCurrent,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            required String label,
            required String startDate,
            required String endDate,
            Value<bool> isCurrent = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AcademicYearsCacheCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            label: label,
            startDate: startDate,
            endDate: endDate,
            isCurrent: isCurrent,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$AcademicYearsCacheTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $AcademicYearsCacheTable,
    AcademicYearsCacheData,
    $$AcademicYearsCacheTableFilterComposer,
    $$AcademicYearsCacheTableOrderingComposer,
    $$AcademicYearsCacheTableAnnotationComposer,
    $$AcademicYearsCacheTableCreateCompanionBuilder,
    $$AcademicYearsCacheTableUpdateCompanionBuilder,
    (
      AcademicYearsCacheData,
      BaseReferences<_$AppDatabase, $AcademicYearsCacheTable,
          AcademicYearsCacheData>
    ),
    AcademicYearsCacheData,
    PrefetchHooks Function()>;
typedef $$TermsCacheTableCreateCompanionBuilder = TermsCacheCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  required String academicYearId,
  required String name,
  required int termNumber,
  required String startDate,
  required String endDate,
  Value<bool> isCurrent,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$TermsCacheTableUpdateCompanionBuilder = TermsCacheCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String> academicYearId,
  Value<String> name,
  Value<int> termNumber,
  Value<String> startDate,
  Value<String> endDate,
  Value<bool> isCurrent,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$TermsCacheTableFilterComposer
    extends Composer<_$AppDatabase, $TermsCacheTable> {
  $$TermsCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get termNumber => $composableBuilder(
      column: $table.termNumber, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get startDate => $composableBuilder(
      column: $table.startDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get endDate => $composableBuilder(
      column: $table.endDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isCurrent => $composableBuilder(
      column: $table.isCurrent, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$TermsCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $TermsCacheTable> {
  $$TermsCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get termNumber => $composableBuilder(
      column: $table.termNumber, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get startDate => $composableBuilder(
      column: $table.startDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get endDate => $composableBuilder(
      column: $table.endDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isCurrent => $composableBuilder(
      column: $table.isCurrent, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$TermsCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $TermsCacheTable> {
  $$TermsCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<int> get termNumber => $composableBuilder(
      column: $table.termNumber, builder: (column) => column);

  GeneratedColumn<String> get startDate =>
      $composableBuilder(column: $table.startDate, builder: (column) => column);

  GeneratedColumn<String> get endDate =>
      $composableBuilder(column: $table.endDate, builder: (column) => column);

  GeneratedColumn<bool> get isCurrent =>
      $composableBuilder(column: $table.isCurrent, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$TermsCacheTableTableManager extends RootTableManager<
    _$AppDatabase,
    $TermsCacheTable,
    TermsCacheData,
    $$TermsCacheTableFilterComposer,
    $$TermsCacheTableOrderingComposer,
    $$TermsCacheTableAnnotationComposer,
    $$TermsCacheTableCreateCompanionBuilder,
    $$TermsCacheTableUpdateCompanionBuilder,
    (
      TermsCacheData,
      BaseReferences<_$AppDatabase, $TermsCacheTable, TermsCacheData>
    ),
    TermsCacheData,
    PrefetchHooks Function()> {
  $$TermsCacheTableTableManager(_$AppDatabase db, $TermsCacheTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$TermsCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$TermsCacheTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$TermsCacheTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String> academicYearId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<int> termNumber = const Value.absent(),
            Value<String> startDate = const Value.absent(),
            Value<String> endDate = const Value.absent(),
            Value<bool> isCurrent = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              TermsCacheCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            academicYearId: academicYearId,
            name: name,
            termNumber: termNumber,
            startDate: startDate,
            endDate: endDate,
            isCurrent: isCurrent,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            required String academicYearId,
            required String name,
            required int termNumber,
            required String startDate,
            required String endDate,
            Value<bool> isCurrent = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              TermsCacheCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            academicYearId: academicYearId,
            name: name,
            termNumber: termNumber,
            startDate: startDate,
            endDate: endDate,
            isCurrent: isCurrent,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$TermsCacheTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $TermsCacheTable,
    TermsCacheData,
    $$TermsCacheTableFilterComposer,
    $$TermsCacheTableOrderingComposer,
    $$TermsCacheTableAnnotationComposer,
    $$TermsCacheTableCreateCompanionBuilder,
    $$TermsCacheTableUpdateCompanionBuilder,
    (
      TermsCacheData,
      BaseReferences<_$AppDatabase, $TermsCacheTable, TermsCacheData>
    ),
    TermsCacheData,
    PrefetchHooks Function()>;
typedef $$ClassLevelsCacheTableCreateCompanionBuilder
    = ClassLevelsCacheCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  required String name,
  Value<int> sortOrder,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$ClassLevelsCacheTableUpdateCompanionBuilder
    = ClassLevelsCacheCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String> name,
  Value<int> sortOrder,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$ClassLevelsCacheTableFilterComposer
    extends Composer<_$AppDatabase, $ClassLevelsCacheTable> {
  $$ClassLevelsCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get sortOrder => $composableBuilder(
      column: $table.sortOrder, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$ClassLevelsCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $ClassLevelsCacheTable> {
  $$ClassLevelsCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get sortOrder => $composableBuilder(
      column: $table.sortOrder, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$ClassLevelsCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $ClassLevelsCacheTable> {
  $$ClassLevelsCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<int> get sortOrder =>
      $composableBuilder(column: $table.sortOrder, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$ClassLevelsCacheTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ClassLevelsCacheTable,
    ClassLevelsCacheData,
    $$ClassLevelsCacheTableFilterComposer,
    $$ClassLevelsCacheTableOrderingComposer,
    $$ClassLevelsCacheTableAnnotationComposer,
    $$ClassLevelsCacheTableCreateCompanionBuilder,
    $$ClassLevelsCacheTableUpdateCompanionBuilder,
    (
      ClassLevelsCacheData,
      BaseReferences<_$AppDatabase, $ClassLevelsCacheTable,
          ClassLevelsCacheData>
    ),
    ClassLevelsCacheData,
    PrefetchHooks Function()> {
  $$ClassLevelsCacheTableTableManager(
      _$AppDatabase db, $ClassLevelsCacheTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ClassLevelsCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ClassLevelsCacheTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ClassLevelsCacheTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<int> sortOrder = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ClassLevelsCacheCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            name: name,
            sortOrder: sortOrder,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            required String name,
            Value<int> sortOrder = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ClassLevelsCacheCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            name: name,
            sortOrder: sortOrder,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ClassLevelsCacheTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ClassLevelsCacheTable,
    ClassLevelsCacheData,
    $$ClassLevelsCacheTableFilterComposer,
    $$ClassLevelsCacheTableOrderingComposer,
    $$ClassLevelsCacheTableAnnotationComposer,
    $$ClassLevelsCacheTableCreateCompanionBuilder,
    $$ClassLevelsCacheTableUpdateCompanionBuilder,
    (
      ClassLevelsCacheData,
      BaseReferences<_$AppDatabase, $ClassLevelsCacheTable,
          ClassLevelsCacheData>
    ),
    ClassLevelsCacheData,
    PrefetchHooks Function()>;
typedef $$ClassArmsCacheTableCreateCompanionBuilder = ClassArmsCacheCompanion
    Function({
  required String id,
  required String tenantId,
  required String schoolId,
  required String classLevelId,
  required String arm,
  required String displayName,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$ClassArmsCacheTableUpdateCompanionBuilder = ClassArmsCacheCompanion
    Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String> classLevelId,
  Value<String> arm,
  Value<String> displayName,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$ClassArmsCacheTableFilterComposer
    extends Composer<_$AppDatabase, $ClassArmsCacheTable> {
  $$ClassArmsCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get classLevelId => $composableBuilder(
      column: $table.classLevelId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get arm => $composableBuilder(
      column: $table.arm, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$ClassArmsCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $ClassArmsCacheTable> {
  $$ClassArmsCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get classLevelId => $composableBuilder(
      column: $table.classLevelId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get arm => $composableBuilder(
      column: $table.arm, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$ClassArmsCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $ClassArmsCacheTable> {
  $$ClassArmsCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get classLevelId => $composableBuilder(
      column: $table.classLevelId, builder: (column) => column);

  GeneratedColumn<String> get arm =>
      $composableBuilder(column: $table.arm, builder: (column) => column);

  GeneratedColumn<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$ClassArmsCacheTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ClassArmsCacheTable,
    ClassArmsCacheData,
    $$ClassArmsCacheTableFilterComposer,
    $$ClassArmsCacheTableOrderingComposer,
    $$ClassArmsCacheTableAnnotationComposer,
    $$ClassArmsCacheTableCreateCompanionBuilder,
    $$ClassArmsCacheTableUpdateCompanionBuilder,
    (
      ClassArmsCacheData,
      BaseReferences<_$AppDatabase, $ClassArmsCacheTable, ClassArmsCacheData>
    ),
    ClassArmsCacheData,
    PrefetchHooks Function()> {
  $$ClassArmsCacheTableTableManager(
      _$AppDatabase db, $ClassArmsCacheTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ClassArmsCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ClassArmsCacheTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ClassArmsCacheTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String> classLevelId = const Value.absent(),
            Value<String> arm = const Value.absent(),
            Value<String> displayName = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ClassArmsCacheCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            classLevelId: classLevelId,
            arm: arm,
            displayName: displayName,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            required String classLevelId,
            required String arm,
            required String displayName,
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ClassArmsCacheCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            classLevelId: classLevelId,
            arm: arm,
            displayName: displayName,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ClassArmsCacheTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ClassArmsCacheTable,
    ClassArmsCacheData,
    $$ClassArmsCacheTableFilterComposer,
    $$ClassArmsCacheTableOrderingComposer,
    $$ClassArmsCacheTableAnnotationComposer,
    $$ClassArmsCacheTableCreateCompanionBuilder,
    $$ClassArmsCacheTableUpdateCompanionBuilder,
    (
      ClassArmsCacheData,
      BaseReferences<_$AppDatabase, $ClassArmsCacheTable, ClassArmsCacheData>
    ),
    ClassArmsCacheData,
    PrefetchHooks Function()>;
typedef $$SubjectsCacheTableCreateCompanionBuilder = SubjectsCacheCompanion
    Function({
  required String id,
  required String tenantId,
  required String schoolId,
  required String name,
  Value<String?> code,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$SubjectsCacheTableUpdateCompanionBuilder = SubjectsCacheCompanion
    Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String> name,
  Value<String?> code,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$SubjectsCacheTableFilterComposer
    extends Composer<_$AppDatabase, $SubjectsCacheTable> {
  $$SubjectsCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get code => $composableBuilder(
      column: $table.code, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$SubjectsCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $SubjectsCacheTable> {
  $$SubjectsCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get code => $composableBuilder(
      column: $table.code, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$SubjectsCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $SubjectsCacheTable> {
  $$SubjectsCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get code =>
      $composableBuilder(column: $table.code, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$SubjectsCacheTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SubjectsCacheTable,
    SubjectsCacheData,
    $$SubjectsCacheTableFilterComposer,
    $$SubjectsCacheTableOrderingComposer,
    $$SubjectsCacheTableAnnotationComposer,
    $$SubjectsCacheTableCreateCompanionBuilder,
    $$SubjectsCacheTableUpdateCompanionBuilder,
    (
      SubjectsCacheData,
      BaseReferences<_$AppDatabase, $SubjectsCacheTable, SubjectsCacheData>
    ),
    SubjectsCacheData,
    PrefetchHooks Function()> {
  $$SubjectsCacheTableTableManager(_$AppDatabase db, $SubjectsCacheTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SubjectsCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SubjectsCacheTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SubjectsCacheTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String?> code = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SubjectsCacheCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            name: name,
            code: code,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            required String name,
            Value<String?> code = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SubjectsCacheCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            name: name,
            code: code,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SubjectsCacheTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SubjectsCacheTable,
    SubjectsCacheData,
    $$SubjectsCacheTableFilterComposer,
    $$SubjectsCacheTableOrderingComposer,
    $$SubjectsCacheTableAnnotationComposer,
    $$SubjectsCacheTableCreateCompanionBuilder,
    $$SubjectsCacheTableUpdateCompanionBuilder,
    (
      SubjectsCacheData,
      BaseReferences<_$AppDatabase, $SubjectsCacheTable, SubjectsCacheData>
    ),
    SubjectsCacheData,
    PrefetchHooks Function()>;
typedef $$GradingSchemesCacheTableCreateCompanionBuilder
    = GradingSchemesCacheCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  required String name,
  required String bandsJson,
  Value<bool> isDefault,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$GradingSchemesCacheTableUpdateCompanionBuilder
    = GradingSchemesCacheCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String> name,
  Value<String> bandsJson,
  Value<bool> isDefault,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$GradingSchemesCacheTableFilterComposer
    extends Composer<_$AppDatabase, $GradingSchemesCacheTable> {
  $$GradingSchemesCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get bandsJson => $composableBuilder(
      column: $table.bandsJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isDefault => $composableBuilder(
      column: $table.isDefault, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$GradingSchemesCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $GradingSchemesCacheTable> {
  $$GradingSchemesCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get bandsJson => $composableBuilder(
      column: $table.bandsJson, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isDefault => $composableBuilder(
      column: $table.isDefault, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$GradingSchemesCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $GradingSchemesCacheTable> {
  $$GradingSchemesCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get bandsJson =>
      $composableBuilder(column: $table.bandsJson, builder: (column) => column);

  GeneratedColumn<bool> get isDefault =>
      $composableBuilder(column: $table.isDefault, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$GradingSchemesCacheTableTableManager extends RootTableManager<
    _$AppDatabase,
    $GradingSchemesCacheTable,
    GradingSchemesCacheData,
    $$GradingSchemesCacheTableFilterComposer,
    $$GradingSchemesCacheTableOrderingComposer,
    $$GradingSchemesCacheTableAnnotationComposer,
    $$GradingSchemesCacheTableCreateCompanionBuilder,
    $$GradingSchemesCacheTableUpdateCompanionBuilder,
    (
      GradingSchemesCacheData,
      BaseReferences<_$AppDatabase, $GradingSchemesCacheTable,
          GradingSchemesCacheData>
    ),
    GradingSchemesCacheData,
    PrefetchHooks Function()> {
  $$GradingSchemesCacheTableTableManager(
      _$AppDatabase db, $GradingSchemesCacheTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$GradingSchemesCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$GradingSchemesCacheTableOrderingComposer(
                  $db: db, $table: table),
          createComputedFieldComposer: () =>
              $$GradingSchemesCacheTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String> bandsJson = const Value.absent(),
            Value<bool> isDefault = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              GradingSchemesCacheCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            name: name,
            bandsJson: bandsJson,
            isDefault: isDefault,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            required String name,
            required String bandsJson,
            Value<bool> isDefault = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              GradingSchemesCacheCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            name: name,
            bandsJson: bandsJson,
            isDefault: isDefault,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$GradingSchemesCacheTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $GradingSchemesCacheTable,
    GradingSchemesCacheData,
    $$GradingSchemesCacheTableFilterComposer,
    $$GradingSchemesCacheTableOrderingComposer,
    $$GradingSchemesCacheTableAnnotationComposer,
    $$GradingSchemesCacheTableCreateCompanionBuilder,
    $$GradingSchemesCacheTableUpdateCompanionBuilder,
    (
      GradingSchemesCacheData,
      BaseReferences<_$AppDatabase, $GradingSchemesCacheTable,
          GradingSchemesCacheData>
    ),
    GradingSchemesCacheData,
    PrefetchHooks Function()>;
typedef $$FeeCategoriesTableCreateCompanionBuilder = FeeCategoriesCompanion
    Function({
  required String id,
  required String tenantId,
  required String schoolId,
  required String name,
  Value<String> billingTerm,
  Value<bool> isActive,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$FeeCategoriesTableUpdateCompanionBuilder = FeeCategoriesCompanion
    Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String> name,
  Value<String> billingTerm,
  Value<bool> isActive,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$FeeCategoriesTableFilterComposer
    extends Composer<_$AppDatabase, $FeeCategoriesTable> {
  $$FeeCategoriesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get billingTerm => $composableBuilder(
      column: $table.billingTerm, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$FeeCategoriesTableOrderingComposer
    extends Composer<_$AppDatabase, $FeeCategoriesTable> {
  $$FeeCategoriesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get billingTerm => $composableBuilder(
      column: $table.billingTerm, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$FeeCategoriesTableAnnotationComposer
    extends Composer<_$AppDatabase, $FeeCategoriesTable> {
  $$FeeCategoriesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get billingTerm => $composableBuilder(
      column: $table.billingTerm, builder: (column) => column);

  GeneratedColumn<bool> get isActive =>
      $composableBuilder(column: $table.isActive, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$FeeCategoriesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FeeCategoriesTable,
    FeeCategory,
    $$FeeCategoriesTableFilterComposer,
    $$FeeCategoriesTableOrderingComposer,
    $$FeeCategoriesTableAnnotationComposer,
    $$FeeCategoriesTableCreateCompanionBuilder,
    $$FeeCategoriesTableUpdateCompanionBuilder,
    (
      FeeCategory,
      BaseReferences<_$AppDatabase, $FeeCategoriesTable, FeeCategory>
    ),
    FeeCategory,
    PrefetchHooks Function()> {
  $$FeeCategoriesTableTableManager(_$AppDatabase db, $FeeCategoriesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$FeeCategoriesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$FeeCategoriesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$FeeCategoriesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String> billingTerm = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              FeeCategoriesCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            name: name,
            billingTerm: billingTerm,
            isActive: isActive,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            required String name,
            Value<String> billingTerm = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              FeeCategoriesCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            name: name,
            billingTerm: billingTerm,
            isActive: isActive,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$FeeCategoriesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $FeeCategoriesTable,
    FeeCategory,
    $$FeeCategoriesTableFilterComposer,
    $$FeeCategoriesTableOrderingComposer,
    $$FeeCategoriesTableAnnotationComposer,
    $$FeeCategoriesTableCreateCompanionBuilder,
    $$FeeCategoriesTableUpdateCompanionBuilder,
    (
      FeeCategory,
      BaseReferences<_$AppDatabase, $FeeCategoriesTable, FeeCategory>
    ),
    FeeCategory,
    PrefetchHooks Function()>;
typedef $$FeeStructureItemsTableCreateCompanionBuilder
    = FeeStructureItemsCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  required String feeCategoryId,
  Value<String?> classLevelId,
  Value<String?> termId,
  required double amount,
  Value<String?> notes,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$FeeStructureItemsTableUpdateCompanionBuilder
    = FeeStructureItemsCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String> feeCategoryId,
  Value<String?> classLevelId,
  Value<String?> termId,
  Value<double> amount,
  Value<String?> notes,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$FeeStructureItemsTableFilterComposer
    extends Composer<_$AppDatabase, $FeeStructureItemsTable> {
  $$FeeStructureItemsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get feeCategoryId => $composableBuilder(
      column: $table.feeCategoryId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get classLevelId => $composableBuilder(
      column: $table.classLevelId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get termId => $composableBuilder(
      column: $table.termId, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get amount => $composableBuilder(
      column: $table.amount, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$FeeStructureItemsTableOrderingComposer
    extends Composer<_$AppDatabase, $FeeStructureItemsTable> {
  $$FeeStructureItemsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get feeCategoryId => $composableBuilder(
      column: $table.feeCategoryId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get classLevelId => $composableBuilder(
      column: $table.classLevelId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get termId => $composableBuilder(
      column: $table.termId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get amount => $composableBuilder(
      column: $table.amount, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$FeeStructureItemsTableAnnotationComposer
    extends Composer<_$AppDatabase, $FeeStructureItemsTable> {
  $$FeeStructureItemsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get feeCategoryId => $composableBuilder(
      column: $table.feeCategoryId, builder: (column) => column);

  GeneratedColumn<String> get classLevelId => $composableBuilder(
      column: $table.classLevelId, builder: (column) => column);

  GeneratedColumn<String> get termId =>
      $composableBuilder(column: $table.termId, builder: (column) => column);

  GeneratedColumn<double> get amount =>
      $composableBuilder(column: $table.amount, builder: (column) => column);

  GeneratedColumn<String> get notes =>
      $composableBuilder(column: $table.notes, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$FeeStructureItemsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FeeStructureItemsTable,
    FeeStructureItem,
    $$FeeStructureItemsTableFilterComposer,
    $$FeeStructureItemsTableOrderingComposer,
    $$FeeStructureItemsTableAnnotationComposer,
    $$FeeStructureItemsTableCreateCompanionBuilder,
    $$FeeStructureItemsTableUpdateCompanionBuilder,
    (
      FeeStructureItem,
      BaseReferences<_$AppDatabase, $FeeStructureItemsTable, FeeStructureItem>
    ),
    FeeStructureItem,
    PrefetchHooks Function()> {
  $$FeeStructureItemsTableTableManager(
      _$AppDatabase db, $FeeStructureItemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$FeeStructureItemsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$FeeStructureItemsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$FeeStructureItemsTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String> feeCategoryId = const Value.absent(),
            Value<String?> classLevelId = const Value.absent(),
            Value<String?> termId = const Value.absent(),
            Value<double> amount = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              FeeStructureItemsCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            feeCategoryId: feeCategoryId,
            classLevelId: classLevelId,
            termId: termId,
            amount: amount,
            notes: notes,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            required String feeCategoryId,
            Value<String?> classLevelId = const Value.absent(),
            Value<String?> termId = const Value.absent(),
            required double amount,
            Value<String?> notes = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              FeeStructureItemsCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            feeCategoryId: feeCategoryId,
            classLevelId: classLevelId,
            termId: termId,
            amount: amount,
            notes: notes,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$FeeStructureItemsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $FeeStructureItemsTable,
    FeeStructureItem,
    $$FeeStructureItemsTableFilterComposer,
    $$FeeStructureItemsTableOrderingComposer,
    $$FeeStructureItemsTableAnnotationComposer,
    $$FeeStructureItemsTableCreateCompanionBuilder,
    $$FeeStructureItemsTableUpdateCompanionBuilder,
    (
      FeeStructureItem,
      BaseReferences<_$AppDatabase, $FeeStructureItemsTable, FeeStructureItem>
    ),
    FeeStructureItem,
    PrefetchHooks Function()>;
typedef $$InvoicesTableCreateCompanionBuilder = InvoicesCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  Value<String?> campusId,
  required String studentId,
  required String academicYearId,
  required String termId,
  required String classArmId,
  required String invoiceCode,
  Value<String> status,
  required String lineItemsJson,
  required double totalAmount,
  Value<String?> generatedByUserId,
  Value<DateTime?> postedAt,
  Value<String> syncStatus,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$InvoicesTableUpdateCompanionBuilder = InvoicesCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String?> campusId,
  Value<String> studentId,
  Value<String> academicYearId,
  Value<String> termId,
  Value<String> classArmId,
  Value<String> invoiceCode,
  Value<String> status,
  Value<String> lineItemsJson,
  Value<double> totalAmount,
  Value<String?> generatedByUserId,
  Value<DateTime?> postedAt,
  Value<String> syncStatus,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$InvoicesTableFilterComposer
    extends Composer<_$AppDatabase, $InvoicesTable> {
  $$InvoicesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get studentId => $composableBuilder(
      column: $table.studentId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get termId => $composableBuilder(
      column: $table.termId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get classArmId => $composableBuilder(
      column: $table.classArmId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get invoiceCode => $composableBuilder(
      column: $table.invoiceCode, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get lineItemsJson => $composableBuilder(
      column: $table.lineItemsJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get totalAmount => $composableBuilder(
      column: $table.totalAmount, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get generatedByUserId => $composableBuilder(
      column: $table.generatedByUserId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get postedAt => $composableBuilder(
      column: $table.postedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$InvoicesTableOrderingComposer
    extends Composer<_$AppDatabase, $InvoicesTable> {
  $$InvoicesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get studentId => $composableBuilder(
      column: $table.studentId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get termId => $composableBuilder(
      column: $table.termId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get classArmId => $composableBuilder(
      column: $table.classArmId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get invoiceCode => $composableBuilder(
      column: $table.invoiceCode, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get lineItemsJson => $composableBuilder(
      column: $table.lineItemsJson,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get totalAmount => $composableBuilder(
      column: $table.totalAmount, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get generatedByUserId => $composableBuilder(
      column: $table.generatedByUserId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get postedAt => $composableBuilder(
      column: $table.postedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$InvoicesTableAnnotationComposer
    extends Composer<_$AppDatabase, $InvoicesTable> {
  $$InvoicesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get campusId =>
      $composableBuilder(column: $table.campusId, builder: (column) => column);

  GeneratedColumn<String> get studentId =>
      $composableBuilder(column: $table.studentId, builder: (column) => column);

  GeneratedColumn<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId, builder: (column) => column);

  GeneratedColumn<String> get termId =>
      $composableBuilder(column: $table.termId, builder: (column) => column);

  GeneratedColumn<String> get classArmId => $composableBuilder(
      column: $table.classArmId, builder: (column) => column);

  GeneratedColumn<String> get invoiceCode => $composableBuilder(
      column: $table.invoiceCode, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get lineItemsJson => $composableBuilder(
      column: $table.lineItemsJson, builder: (column) => column);

  GeneratedColumn<double> get totalAmount => $composableBuilder(
      column: $table.totalAmount, builder: (column) => column);

  GeneratedColumn<String> get generatedByUserId => $composableBuilder(
      column: $table.generatedByUserId, builder: (column) => column);

  GeneratedColumn<DateTime> get postedAt =>
      $composableBuilder(column: $table.postedAt, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$InvoicesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $InvoicesTable,
    Invoice,
    $$InvoicesTableFilterComposer,
    $$InvoicesTableOrderingComposer,
    $$InvoicesTableAnnotationComposer,
    $$InvoicesTableCreateCompanionBuilder,
    $$InvoicesTableUpdateCompanionBuilder,
    (Invoice, BaseReferences<_$AppDatabase, $InvoicesTable, Invoice>),
    Invoice,
    PrefetchHooks Function()> {
  $$InvoicesTableTableManager(_$AppDatabase db, $InvoicesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$InvoicesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$InvoicesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$InvoicesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String?> campusId = const Value.absent(),
            Value<String> studentId = const Value.absent(),
            Value<String> academicYearId = const Value.absent(),
            Value<String> termId = const Value.absent(),
            Value<String> classArmId = const Value.absent(),
            Value<String> invoiceCode = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String> lineItemsJson = const Value.absent(),
            Value<double> totalAmount = const Value.absent(),
            Value<String?> generatedByUserId = const Value.absent(),
            Value<DateTime?> postedAt = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              InvoicesCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            studentId: studentId,
            academicYearId: academicYearId,
            termId: termId,
            classArmId: classArmId,
            invoiceCode: invoiceCode,
            status: status,
            lineItemsJson: lineItemsJson,
            totalAmount: totalAmount,
            generatedByUserId: generatedByUserId,
            postedAt: postedAt,
            syncStatus: syncStatus,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            Value<String?> campusId = const Value.absent(),
            required String studentId,
            required String academicYearId,
            required String termId,
            required String classArmId,
            required String invoiceCode,
            Value<String> status = const Value.absent(),
            required String lineItemsJson,
            required double totalAmount,
            Value<String?> generatedByUserId = const Value.absent(),
            Value<DateTime?> postedAt = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              InvoicesCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            studentId: studentId,
            academicYearId: academicYearId,
            termId: termId,
            classArmId: classArmId,
            invoiceCode: invoiceCode,
            status: status,
            lineItemsJson: lineItemsJson,
            totalAmount: totalAmount,
            generatedByUserId: generatedByUserId,
            postedAt: postedAt,
            syncStatus: syncStatus,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$InvoicesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $InvoicesTable,
    Invoice,
    $$InvoicesTableFilterComposer,
    $$InvoicesTableOrderingComposer,
    $$InvoicesTableAnnotationComposer,
    $$InvoicesTableCreateCompanionBuilder,
    $$InvoicesTableUpdateCompanionBuilder,
    (Invoice, BaseReferences<_$AppDatabase, $InvoicesTable, Invoice>),
    Invoice,
    PrefetchHooks Function()>;
typedef $$PaymentsTableCreateCompanionBuilder = PaymentsCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  Value<String?> campusId,
  required String invoiceId,
  required String paymentCode,
  Value<String> status,
  required double amount,
  required String paymentMode,
  required String paymentDate,
  Value<String?> reference,
  Value<String?> notes,
  Value<String?> receivedByUserId,
  Value<DateTime?> postedAt,
  Value<String> syncStatus,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$PaymentsTableUpdateCompanionBuilder = PaymentsCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String?> campusId,
  Value<String> invoiceId,
  Value<String> paymentCode,
  Value<String> status,
  Value<double> amount,
  Value<String> paymentMode,
  Value<String> paymentDate,
  Value<String?> reference,
  Value<String?> notes,
  Value<String?> receivedByUserId,
  Value<DateTime?> postedAt,
  Value<String> syncStatus,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$PaymentsTableFilterComposer
    extends Composer<_$AppDatabase, $PaymentsTable> {
  $$PaymentsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get invoiceId => $composableBuilder(
      column: $table.invoiceId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get paymentCode => $composableBuilder(
      column: $table.paymentCode, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get amount => $composableBuilder(
      column: $table.amount, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get paymentMode => $composableBuilder(
      column: $table.paymentMode, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get paymentDate => $composableBuilder(
      column: $table.paymentDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get reference => $composableBuilder(
      column: $table.reference, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get receivedByUserId => $composableBuilder(
      column: $table.receivedByUserId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get postedAt => $composableBuilder(
      column: $table.postedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$PaymentsTableOrderingComposer
    extends Composer<_$AppDatabase, $PaymentsTable> {
  $$PaymentsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get invoiceId => $composableBuilder(
      column: $table.invoiceId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get paymentCode => $composableBuilder(
      column: $table.paymentCode, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get amount => $composableBuilder(
      column: $table.amount, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get paymentMode => $composableBuilder(
      column: $table.paymentMode, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get paymentDate => $composableBuilder(
      column: $table.paymentDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get reference => $composableBuilder(
      column: $table.reference, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get receivedByUserId => $composableBuilder(
      column: $table.receivedByUserId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get postedAt => $composableBuilder(
      column: $table.postedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$PaymentsTableAnnotationComposer
    extends Composer<_$AppDatabase, $PaymentsTable> {
  $$PaymentsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get campusId =>
      $composableBuilder(column: $table.campusId, builder: (column) => column);

  GeneratedColumn<String> get invoiceId =>
      $composableBuilder(column: $table.invoiceId, builder: (column) => column);

  GeneratedColumn<String> get paymentCode => $composableBuilder(
      column: $table.paymentCode, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<double> get amount =>
      $composableBuilder(column: $table.amount, builder: (column) => column);

  GeneratedColumn<String> get paymentMode => $composableBuilder(
      column: $table.paymentMode, builder: (column) => column);

  GeneratedColumn<String> get paymentDate => $composableBuilder(
      column: $table.paymentDate, builder: (column) => column);

  GeneratedColumn<String> get reference =>
      $composableBuilder(column: $table.reference, builder: (column) => column);

  GeneratedColumn<String> get notes =>
      $composableBuilder(column: $table.notes, builder: (column) => column);

  GeneratedColumn<String> get receivedByUserId => $composableBuilder(
      column: $table.receivedByUserId, builder: (column) => column);

  GeneratedColumn<DateTime> get postedAt =>
      $composableBuilder(column: $table.postedAt, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$PaymentsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PaymentsTable,
    Payment,
    $$PaymentsTableFilterComposer,
    $$PaymentsTableOrderingComposer,
    $$PaymentsTableAnnotationComposer,
    $$PaymentsTableCreateCompanionBuilder,
    $$PaymentsTableUpdateCompanionBuilder,
    (Payment, BaseReferences<_$AppDatabase, $PaymentsTable, Payment>),
    Payment,
    PrefetchHooks Function()> {
  $$PaymentsTableTableManager(_$AppDatabase db, $PaymentsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$PaymentsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$PaymentsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$PaymentsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String?> campusId = const Value.absent(),
            Value<String> invoiceId = const Value.absent(),
            Value<String> paymentCode = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<double> amount = const Value.absent(),
            Value<String> paymentMode = const Value.absent(),
            Value<String> paymentDate = const Value.absent(),
            Value<String?> reference = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            Value<String?> receivedByUserId = const Value.absent(),
            Value<DateTime?> postedAt = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PaymentsCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            invoiceId: invoiceId,
            paymentCode: paymentCode,
            status: status,
            amount: amount,
            paymentMode: paymentMode,
            paymentDate: paymentDate,
            reference: reference,
            notes: notes,
            receivedByUserId: receivedByUserId,
            postedAt: postedAt,
            syncStatus: syncStatus,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            Value<String?> campusId = const Value.absent(),
            required String invoiceId,
            required String paymentCode,
            Value<String> status = const Value.absent(),
            required double amount,
            required String paymentMode,
            required String paymentDate,
            Value<String?> reference = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            Value<String?> receivedByUserId = const Value.absent(),
            Value<DateTime?> postedAt = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PaymentsCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            invoiceId: invoiceId,
            paymentCode: paymentCode,
            status: status,
            amount: amount,
            paymentMode: paymentMode,
            paymentDate: paymentDate,
            reference: reference,
            notes: notes,
            receivedByUserId: receivedByUserId,
            postedAt: postedAt,
            syncStatus: syncStatus,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$PaymentsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $PaymentsTable,
    Payment,
    $$PaymentsTableFilterComposer,
    $$PaymentsTableOrderingComposer,
    $$PaymentsTableAnnotationComposer,
    $$PaymentsTableCreateCompanionBuilder,
    $$PaymentsTableUpdateCompanionBuilder,
    (Payment, BaseReferences<_$AppDatabase, $PaymentsTable, Payment>),
    Payment,
    PrefetchHooks Function()>;
typedef $$PaymentReversalsTableCreateCompanionBuilder
    = PaymentReversalsCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  Value<String?> campusId,
  required String paymentId,
  required String invoiceId,
  required double amount,
  required String reason,
  Value<String?> reversedByUserId,
  Value<String> syncStatus,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$PaymentReversalsTableUpdateCompanionBuilder
    = PaymentReversalsCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String?> campusId,
  Value<String> paymentId,
  Value<String> invoiceId,
  Value<double> amount,
  Value<String> reason,
  Value<String?> reversedByUserId,
  Value<String> syncStatus,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$PaymentReversalsTableFilterComposer
    extends Composer<_$AppDatabase, $PaymentReversalsTable> {
  $$PaymentReversalsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get paymentId => $composableBuilder(
      column: $table.paymentId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get invoiceId => $composableBuilder(
      column: $table.invoiceId, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get amount => $composableBuilder(
      column: $table.amount, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get reason => $composableBuilder(
      column: $table.reason, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get reversedByUserId => $composableBuilder(
      column: $table.reversedByUserId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$PaymentReversalsTableOrderingComposer
    extends Composer<_$AppDatabase, $PaymentReversalsTable> {
  $$PaymentReversalsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get paymentId => $composableBuilder(
      column: $table.paymentId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get invoiceId => $composableBuilder(
      column: $table.invoiceId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get amount => $composableBuilder(
      column: $table.amount, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get reason => $composableBuilder(
      column: $table.reason, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get reversedByUserId => $composableBuilder(
      column: $table.reversedByUserId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$PaymentReversalsTableAnnotationComposer
    extends Composer<_$AppDatabase, $PaymentReversalsTable> {
  $$PaymentReversalsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get campusId =>
      $composableBuilder(column: $table.campusId, builder: (column) => column);

  GeneratedColumn<String> get paymentId =>
      $composableBuilder(column: $table.paymentId, builder: (column) => column);

  GeneratedColumn<String> get invoiceId =>
      $composableBuilder(column: $table.invoiceId, builder: (column) => column);

  GeneratedColumn<double> get amount =>
      $composableBuilder(column: $table.amount, builder: (column) => column);

  GeneratedColumn<String> get reason =>
      $composableBuilder(column: $table.reason, builder: (column) => column);

  GeneratedColumn<String> get reversedByUserId => $composableBuilder(
      column: $table.reversedByUserId, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$PaymentReversalsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PaymentReversalsTable,
    PaymentReversal,
    $$PaymentReversalsTableFilterComposer,
    $$PaymentReversalsTableOrderingComposer,
    $$PaymentReversalsTableAnnotationComposer,
    $$PaymentReversalsTableCreateCompanionBuilder,
    $$PaymentReversalsTableUpdateCompanionBuilder,
    (
      PaymentReversal,
      BaseReferences<_$AppDatabase, $PaymentReversalsTable, PaymentReversal>
    ),
    PaymentReversal,
    PrefetchHooks Function()> {
  $$PaymentReversalsTableTableManager(
      _$AppDatabase db, $PaymentReversalsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$PaymentReversalsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$PaymentReversalsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$PaymentReversalsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String?> campusId = const Value.absent(),
            Value<String> paymentId = const Value.absent(),
            Value<String> invoiceId = const Value.absent(),
            Value<double> amount = const Value.absent(),
            Value<String> reason = const Value.absent(),
            Value<String?> reversedByUserId = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PaymentReversalsCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            paymentId: paymentId,
            invoiceId: invoiceId,
            amount: amount,
            reason: reason,
            reversedByUserId: reversedByUserId,
            syncStatus: syncStatus,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            Value<String?> campusId = const Value.absent(),
            required String paymentId,
            required String invoiceId,
            required double amount,
            required String reason,
            Value<String?> reversedByUserId = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PaymentReversalsCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            paymentId: paymentId,
            invoiceId: invoiceId,
            amount: amount,
            reason: reason,
            reversedByUserId: reversedByUserId,
            syncStatus: syncStatus,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$PaymentReversalsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $PaymentReversalsTable,
    PaymentReversal,
    $$PaymentReversalsTableFilterComposer,
    $$PaymentReversalsTableOrderingComposer,
    $$PaymentReversalsTableAnnotationComposer,
    $$PaymentReversalsTableCreateCompanionBuilder,
    $$PaymentReversalsTableUpdateCompanionBuilder,
    (
      PaymentReversal,
      BaseReferences<_$AppDatabase, $PaymentReversalsTable, PaymentReversal>
    ),
    PaymentReversal,
    PrefetchHooks Function()>;
typedef $$SchoolProfileCacheTableCreateCompanionBuilder
    = SchoolProfileCacheCompanion Function({
  required String id,
  required String tenantId,
  required String name,
  Value<String?> shortName,
  required String schoolType,
  Value<String?> address,
  Value<String?> region,
  Value<String?> district,
  Value<String?> contactPhone,
  Value<String?> contactEmail,
  required String onboardingDefaultsJson,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$SchoolProfileCacheTableUpdateCompanionBuilder
    = SchoolProfileCacheCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> name,
  Value<String?> shortName,
  Value<String> schoolType,
  Value<String?> address,
  Value<String?> region,
  Value<String?> district,
  Value<String?> contactPhone,
  Value<String?> contactEmail,
  Value<String> onboardingDefaultsJson,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$SchoolProfileCacheTableFilterComposer
    extends Composer<_$AppDatabase, $SchoolProfileCacheTable> {
  $$SchoolProfileCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get shortName => $composableBuilder(
      column: $table.shortName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolType => $composableBuilder(
      column: $table.schoolType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get address => $composableBuilder(
      column: $table.address, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get region => $composableBuilder(
      column: $table.region, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get district => $composableBuilder(
      column: $table.district, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get contactPhone => $composableBuilder(
      column: $table.contactPhone, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get contactEmail => $composableBuilder(
      column: $table.contactEmail, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get onboardingDefaultsJson => $composableBuilder(
      column: $table.onboardingDefaultsJson,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$SchoolProfileCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $SchoolProfileCacheTable> {
  $$SchoolProfileCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get shortName => $composableBuilder(
      column: $table.shortName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolType => $composableBuilder(
      column: $table.schoolType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get address => $composableBuilder(
      column: $table.address, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get region => $composableBuilder(
      column: $table.region, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get district => $composableBuilder(
      column: $table.district, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get contactPhone => $composableBuilder(
      column: $table.contactPhone,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get contactEmail => $composableBuilder(
      column: $table.contactEmail,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get onboardingDefaultsJson => $composableBuilder(
      column: $table.onboardingDefaultsJson,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$SchoolProfileCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $SchoolProfileCacheTable> {
  $$SchoolProfileCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get shortName =>
      $composableBuilder(column: $table.shortName, builder: (column) => column);

  GeneratedColumn<String> get schoolType => $composableBuilder(
      column: $table.schoolType, builder: (column) => column);

  GeneratedColumn<String> get address =>
      $composableBuilder(column: $table.address, builder: (column) => column);

  GeneratedColumn<String> get region =>
      $composableBuilder(column: $table.region, builder: (column) => column);

  GeneratedColumn<String> get district =>
      $composableBuilder(column: $table.district, builder: (column) => column);

  GeneratedColumn<String> get contactPhone => $composableBuilder(
      column: $table.contactPhone, builder: (column) => column);

  GeneratedColumn<String> get contactEmail => $composableBuilder(
      column: $table.contactEmail, builder: (column) => column);

  GeneratedColumn<String> get onboardingDefaultsJson => $composableBuilder(
      column: $table.onboardingDefaultsJson, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$SchoolProfileCacheTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SchoolProfileCacheTable,
    SchoolProfileCacheData,
    $$SchoolProfileCacheTableFilterComposer,
    $$SchoolProfileCacheTableOrderingComposer,
    $$SchoolProfileCacheTableAnnotationComposer,
    $$SchoolProfileCacheTableCreateCompanionBuilder,
    $$SchoolProfileCacheTableUpdateCompanionBuilder,
    (
      SchoolProfileCacheData,
      BaseReferences<_$AppDatabase, $SchoolProfileCacheTable,
          SchoolProfileCacheData>
    ),
    SchoolProfileCacheData,
    PrefetchHooks Function()> {
  $$SchoolProfileCacheTableTableManager(
      _$AppDatabase db, $SchoolProfileCacheTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SchoolProfileCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SchoolProfileCacheTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SchoolProfileCacheTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String?> shortName = const Value.absent(),
            Value<String> schoolType = const Value.absent(),
            Value<String?> address = const Value.absent(),
            Value<String?> region = const Value.absent(),
            Value<String?> district = const Value.absent(),
            Value<String?> contactPhone = const Value.absent(),
            Value<String?> contactEmail = const Value.absent(),
            Value<String> onboardingDefaultsJson = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SchoolProfileCacheCompanion(
            id: id,
            tenantId: tenantId,
            name: name,
            shortName: shortName,
            schoolType: schoolType,
            address: address,
            region: region,
            district: district,
            contactPhone: contactPhone,
            contactEmail: contactEmail,
            onboardingDefaultsJson: onboardingDefaultsJson,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String name,
            Value<String?> shortName = const Value.absent(),
            required String schoolType,
            Value<String?> address = const Value.absent(),
            Value<String?> region = const Value.absent(),
            Value<String?> district = const Value.absent(),
            Value<String?> contactPhone = const Value.absent(),
            Value<String?> contactEmail = const Value.absent(),
            required String onboardingDefaultsJson,
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SchoolProfileCacheCompanion.insert(
            id: id,
            tenantId: tenantId,
            name: name,
            shortName: shortName,
            schoolType: schoolType,
            address: address,
            region: region,
            district: district,
            contactPhone: contactPhone,
            contactEmail: contactEmail,
            onboardingDefaultsJson: onboardingDefaultsJson,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SchoolProfileCacheTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SchoolProfileCacheTable,
    SchoolProfileCacheData,
    $$SchoolProfileCacheTableFilterComposer,
    $$SchoolProfileCacheTableOrderingComposer,
    $$SchoolProfileCacheTableAnnotationComposer,
    $$SchoolProfileCacheTableCreateCompanionBuilder,
    $$SchoolProfileCacheTableUpdateCompanionBuilder,
    (
      SchoolProfileCacheData,
      BaseReferences<_$AppDatabase, $SchoolProfileCacheTable,
          SchoolProfileCacheData>
    ),
    SchoolProfileCacheData,
    PrefetchHooks Function()>;
typedef $$CampusProfileCacheTableCreateCompanionBuilder
    = CampusProfileCacheCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  required String name,
  Value<String?> address,
  Value<String?> contactPhone,
  Value<String?> registrationCode,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$CampusProfileCacheTableUpdateCompanionBuilder
    = CampusProfileCacheCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String> name,
  Value<String?> address,
  Value<String?> contactPhone,
  Value<String?> registrationCode,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$CampusProfileCacheTableFilterComposer
    extends Composer<_$AppDatabase, $CampusProfileCacheTable> {
  $$CampusProfileCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get address => $composableBuilder(
      column: $table.address, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get contactPhone => $composableBuilder(
      column: $table.contactPhone, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get registrationCode => $composableBuilder(
      column: $table.registrationCode,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$CampusProfileCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $CampusProfileCacheTable> {
  $$CampusProfileCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get address => $composableBuilder(
      column: $table.address, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get contactPhone => $composableBuilder(
      column: $table.contactPhone,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get registrationCode => $composableBuilder(
      column: $table.registrationCode,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$CampusProfileCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $CampusProfileCacheTable> {
  $$CampusProfileCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get address =>
      $composableBuilder(column: $table.address, builder: (column) => column);

  GeneratedColumn<String> get contactPhone => $composableBuilder(
      column: $table.contactPhone, builder: (column) => column);

  GeneratedColumn<String> get registrationCode => $composableBuilder(
      column: $table.registrationCode, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$CampusProfileCacheTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CampusProfileCacheTable,
    CampusProfileCacheData,
    $$CampusProfileCacheTableFilterComposer,
    $$CampusProfileCacheTableOrderingComposer,
    $$CampusProfileCacheTableAnnotationComposer,
    $$CampusProfileCacheTableCreateCompanionBuilder,
    $$CampusProfileCacheTableUpdateCompanionBuilder,
    (
      CampusProfileCacheData,
      BaseReferences<_$AppDatabase, $CampusProfileCacheTable,
          CampusProfileCacheData>
    ),
    CampusProfileCacheData,
    PrefetchHooks Function()> {
  $$CampusProfileCacheTableTableManager(
      _$AppDatabase db, $CampusProfileCacheTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$CampusProfileCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$CampusProfileCacheTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$CampusProfileCacheTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String?> address = const Value.absent(),
            Value<String?> contactPhone = const Value.absent(),
            Value<String?> registrationCode = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CampusProfileCacheCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            name: name,
            address: address,
            contactPhone: contactPhone,
            registrationCode: registrationCode,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            required String name,
            Value<String?> address = const Value.absent(),
            Value<String?> contactPhone = const Value.absent(),
            Value<String?> registrationCode = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CampusProfileCacheCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            name: name,
            address: address,
            contactPhone: contactPhone,
            registrationCode: registrationCode,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$CampusProfileCacheTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $CampusProfileCacheTable,
    CampusProfileCacheData,
    $$CampusProfileCacheTableFilterComposer,
    $$CampusProfileCacheTableOrderingComposer,
    $$CampusProfileCacheTableAnnotationComposer,
    $$CampusProfileCacheTableCreateCompanionBuilder,
    $$CampusProfileCacheTableUpdateCompanionBuilder,
    (
      CampusProfileCacheData,
      BaseReferences<_$AppDatabase, $CampusProfileCacheTable,
          CampusProfileCacheData>
    ),
    CampusProfileCacheData,
    PrefetchHooks Function()>;
typedef $$StudentsTableCreateCompanionBuilder = StudentsCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  Value<String?> campusId,
  Value<String?> studentNumber,
  required String firstName,
  Value<String?> middleName,
  required String lastName,
  Value<String?> dateOfBirth,
  Value<String?> gender,
  Value<String> status,
  Value<String?> profilePhotoUrl,
  Value<int> serverRevision,
  Value<String> syncStatus,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$StudentsTableUpdateCompanionBuilder = StudentsCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String?> campusId,
  Value<String?> studentNumber,
  Value<String> firstName,
  Value<String?> middleName,
  Value<String> lastName,
  Value<String?> dateOfBirth,
  Value<String?> gender,
  Value<String> status,
  Value<String?> profilePhotoUrl,
  Value<int> serverRevision,
  Value<String> syncStatus,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$StudentsTableFilterComposer
    extends Composer<_$AppDatabase, $StudentsTable> {
  $$StudentsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get studentNumber => $composableBuilder(
      column: $table.studentNumber, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get firstName => $composableBuilder(
      column: $table.firstName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get middleName => $composableBuilder(
      column: $table.middleName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get lastName => $composableBuilder(
      column: $table.lastName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get dateOfBirth => $composableBuilder(
      column: $table.dateOfBirth, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get gender => $composableBuilder(
      column: $table.gender, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get profilePhotoUrl => $composableBuilder(
      column: $table.profilePhotoUrl,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$StudentsTableOrderingComposer
    extends Composer<_$AppDatabase, $StudentsTable> {
  $$StudentsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get studentNumber => $composableBuilder(
      column: $table.studentNumber,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get firstName => $composableBuilder(
      column: $table.firstName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get middleName => $composableBuilder(
      column: $table.middleName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get lastName => $composableBuilder(
      column: $table.lastName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get dateOfBirth => $composableBuilder(
      column: $table.dateOfBirth, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get gender => $composableBuilder(
      column: $table.gender, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get profilePhotoUrl => $composableBuilder(
      column: $table.profilePhotoUrl,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$StudentsTableAnnotationComposer
    extends Composer<_$AppDatabase, $StudentsTable> {
  $$StudentsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get campusId =>
      $composableBuilder(column: $table.campusId, builder: (column) => column);

  GeneratedColumn<String> get studentNumber => $composableBuilder(
      column: $table.studentNumber, builder: (column) => column);

  GeneratedColumn<String> get firstName =>
      $composableBuilder(column: $table.firstName, builder: (column) => column);

  GeneratedColumn<String> get middleName => $composableBuilder(
      column: $table.middleName, builder: (column) => column);

  GeneratedColumn<String> get lastName =>
      $composableBuilder(column: $table.lastName, builder: (column) => column);

  GeneratedColumn<String> get dateOfBirth => $composableBuilder(
      column: $table.dateOfBirth, builder: (column) => column);

  GeneratedColumn<String> get gender =>
      $composableBuilder(column: $table.gender, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get profilePhotoUrl => $composableBuilder(
      column: $table.profilePhotoUrl, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$StudentsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $StudentsTable,
    Student,
    $$StudentsTableFilterComposer,
    $$StudentsTableOrderingComposer,
    $$StudentsTableAnnotationComposer,
    $$StudentsTableCreateCompanionBuilder,
    $$StudentsTableUpdateCompanionBuilder,
    (Student, BaseReferences<_$AppDatabase, $StudentsTable, Student>),
    Student,
    PrefetchHooks Function()> {
  $$StudentsTableTableManager(_$AppDatabase db, $StudentsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$StudentsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$StudentsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$StudentsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String?> campusId = const Value.absent(),
            Value<String?> studentNumber = const Value.absent(),
            Value<String> firstName = const Value.absent(),
            Value<String?> middleName = const Value.absent(),
            Value<String> lastName = const Value.absent(),
            Value<String?> dateOfBirth = const Value.absent(),
            Value<String?> gender = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String?> profilePhotoUrl = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              StudentsCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            studentNumber: studentNumber,
            firstName: firstName,
            middleName: middleName,
            lastName: lastName,
            dateOfBirth: dateOfBirth,
            gender: gender,
            status: status,
            profilePhotoUrl: profilePhotoUrl,
            serverRevision: serverRevision,
            syncStatus: syncStatus,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            Value<String?> campusId = const Value.absent(),
            Value<String?> studentNumber = const Value.absent(),
            required String firstName,
            Value<String?> middleName = const Value.absent(),
            required String lastName,
            Value<String?> dateOfBirth = const Value.absent(),
            Value<String?> gender = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String?> profilePhotoUrl = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              StudentsCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            studentNumber: studentNumber,
            firstName: firstName,
            middleName: middleName,
            lastName: lastName,
            dateOfBirth: dateOfBirth,
            gender: gender,
            status: status,
            profilePhotoUrl: profilePhotoUrl,
            serverRevision: serverRevision,
            syncStatus: syncStatus,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$StudentsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $StudentsTable,
    Student,
    $$StudentsTableFilterComposer,
    $$StudentsTableOrderingComposer,
    $$StudentsTableAnnotationComposer,
    $$StudentsTableCreateCompanionBuilder,
    $$StudentsTableUpdateCompanionBuilder,
    (Student, BaseReferences<_$AppDatabase, $StudentsTable, Student>),
    Student,
    PrefetchHooks Function()>;
typedef $$GuardiansTableCreateCompanionBuilder = GuardiansCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  required String studentId,
  required String firstName,
  required String lastName,
  Value<String> relationship,
  Value<String?> phone,
  Value<String?> email,
  Value<bool> isPrimary,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<int> rowid,
});
typedef $$GuardiansTableUpdateCompanionBuilder = GuardiansCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String> studentId,
  Value<String> firstName,
  Value<String> lastName,
  Value<String> relationship,
  Value<String?> phone,
  Value<String?> email,
  Value<bool> isPrimary,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$GuardiansTableFilterComposer
    extends Composer<_$AppDatabase, $GuardiansTable> {
  $$GuardiansTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get studentId => $composableBuilder(
      column: $table.studentId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get firstName => $composableBuilder(
      column: $table.firstName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get lastName => $composableBuilder(
      column: $table.lastName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get relationship => $composableBuilder(
      column: $table.relationship, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get phone => $composableBuilder(
      column: $table.phone, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get email => $composableBuilder(
      column: $table.email, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isPrimary => $composableBuilder(
      column: $table.isPrimary, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$GuardiansTableOrderingComposer
    extends Composer<_$AppDatabase, $GuardiansTable> {
  $$GuardiansTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get studentId => $composableBuilder(
      column: $table.studentId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get firstName => $composableBuilder(
      column: $table.firstName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get lastName => $composableBuilder(
      column: $table.lastName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get relationship => $composableBuilder(
      column: $table.relationship,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get phone => $composableBuilder(
      column: $table.phone, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get email => $composableBuilder(
      column: $table.email, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isPrimary => $composableBuilder(
      column: $table.isPrimary, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$GuardiansTableAnnotationComposer
    extends Composer<_$AppDatabase, $GuardiansTable> {
  $$GuardiansTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get studentId =>
      $composableBuilder(column: $table.studentId, builder: (column) => column);

  GeneratedColumn<String> get firstName =>
      $composableBuilder(column: $table.firstName, builder: (column) => column);

  GeneratedColumn<String> get lastName =>
      $composableBuilder(column: $table.lastName, builder: (column) => column);

  GeneratedColumn<String> get relationship => $composableBuilder(
      column: $table.relationship, builder: (column) => column);

  GeneratedColumn<String> get phone =>
      $composableBuilder(column: $table.phone, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<bool> get isPrimary =>
      $composableBuilder(column: $table.isPrimary, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$GuardiansTableTableManager extends RootTableManager<
    _$AppDatabase,
    $GuardiansTable,
    Guardian,
    $$GuardiansTableFilterComposer,
    $$GuardiansTableOrderingComposer,
    $$GuardiansTableAnnotationComposer,
    $$GuardiansTableCreateCompanionBuilder,
    $$GuardiansTableUpdateCompanionBuilder,
    (Guardian, BaseReferences<_$AppDatabase, $GuardiansTable, Guardian>),
    Guardian,
    PrefetchHooks Function()> {
  $$GuardiansTableTableManager(_$AppDatabase db, $GuardiansTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$GuardiansTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$GuardiansTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$GuardiansTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String> studentId = const Value.absent(),
            Value<String> firstName = const Value.absent(),
            Value<String> lastName = const Value.absent(),
            Value<String> relationship = const Value.absent(),
            Value<String?> phone = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<bool> isPrimary = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              GuardiansCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            studentId: studentId,
            firstName: firstName,
            lastName: lastName,
            relationship: relationship,
            phone: phone,
            email: email,
            isPrimary: isPrimary,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            required String studentId,
            required String firstName,
            required String lastName,
            Value<String> relationship = const Value.absent(),
            Value<String?> phone = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<bool> isPrimary = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              GuardiansCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            studentId: studentId,
            firstName: firstName,
            lastName: lastName,
            relationship: relationship,
            phone: phone,
            email: email,
            isPrimary: isPrimary,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$GuardiansTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $GuardiansTable,
    Guardian,
    $$GuardiansTableFilterComposer,
    $$GuardiansTableOrderingComposer,
    $$GuardiansTableAnnotationComposer,
    $$GuardiansTableCreateCompanionBuilder,
    $$GuardiansTableUpdateCompanionBuilder,
    (Guardian, BaseReferences<_$AppDatabase, $GuardiansTable, Guardian>),
    Guardian,
    PrefetchHooks Function()>;
typedef $$EnrollmentsTableCreateCompanionBuilder = EnrollmentsCompanion
    Function({
  required String id,
  required String tenantId,
  required String schoolId,
  required String studentId,
  required String classArmId,
  required String academicYearId,
  required String enrollmentDate,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<int> rowid,
});
typedef $$EnrollmentsTableUpdateCompanionBuilder = EnrollmentsCompanion
    Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String> studentId,
  Value<String> classArmId,
  Value<String> academicYearId,
  Value<String> enrollmentDate,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$EnrollmentsTableFilterComposer
    extends Composer<_$AppDatabase, $EnrollmentsTable> {
  $$EnrollmentsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get studentId => $composableBuilder(
      column: $table.studentId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get classArmId => $composableBuilder(
      column: $table.classArmId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get enrollmentDate => $composableBuilder(
      column: $table.enrollmentDate,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$EnrollmentsTableOrderingComposer
    extends Composer<_$AppDatabase, $EnrollmentsTable> {
  $$EnrollmentsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get studentId => $composableBuilder(
      column: $table.studentId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get classArmId => $composableBuilder(
      column: $table.classArmId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get enrollmentDate => $composableBuilder(
      column: $table.enrollmentDate,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$EnrollmentsTableAnnotationComposer
    extends Composer<_$AppDatabase, $EnrollmentsTable> {
  $$EnrollmentsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get studentId =>
      $composableBuilder(column: $table.studentId, builder: (column) => column);

  GeneratedColumn<String> get classArmId => $composableBuilder(
      column: $table.classArmId, builder: (column) => column);

  GeneratedColumn<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId, builder: (column) => column);

  GeneratedColumn<String> get enrollmentDate => $composableBuilder(
      column: $table.enrollmentDate, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$EnrollmentsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EnrollmentsTable,
    Enrollment,
    $$EnrollmentsTableFilterComposer,
    $$EnrollmentsTableOrderingComposer,
    $$EnrollmentsTableAnnotationComposer,
    $$EnrollmentsTableCreateCompanionBuilder,
    $$EnrollmentsTableUpdateCompanionBuilder,
    (Enrollment, BaseReferences<_$AppDatabase, $EnrollmentsTable, Enrollment>),
    Enrollment,
    PrefetchHooks Function()> {
  $$EnrollmentsTableTableManager(_$AppDatabase db, $EnrollmentsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$EnrollmentsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$EnrollmentsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$EnrollmentsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String> studentId = const Value.absent(),
            Value<String> classArmId = const Value.absent(),
            Value<String> academicYearId = const Value.absent(),
            Value<String> enrollmentDate = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EnrollmentsCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            studentId: studentId,
            classArmId: classArmId,
            academicYearId: academicYearId,
            enrollmentDate: enrollmentDate,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            required String studentId,
            required String classArmId,
            required String academicYearId,
            required String enrollmentDate,
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EnrollmentsCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            studentId: studentId,
            classArmId: classArmId,
            academicYearId: academicYearId,
            enrollmentDate: enrollmentDate,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$EnrollmentsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $EnrollmentsTable,
    Enrollment,
    $$EnrollmentsTableFilterComposer,
    $$EnrollmentsTableOrderingComposer,
    $$EnrollmentsTableAnnotationComposer,
    $$EnrollmentsTableCreateCompanionBuilder,
    $$EnrollmentsTableUpdateCompanionBuilder,
    (Enrollment, BaseReferences<_$AppDatabase, $EnrollmentsTable, Enrollment>),
    Enrollment,
    PrefetchHooks Function()>;
typedef $$StaffTableCreateCompanionBuilder = StaffCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  Value<String?> campusId,
  Value<String?> userId,
  Value<String?> staffNumber,
  required String firstName,
  Value<String?> middleName,
  required String lastName,
  Value<String?> gender,
  Value<String?> phone,
  Value<String?> email,
  Value<String?> department,
  Value<String> systemRole,
  Value<String> employmentType,
  Value<String?> dateJoined,
  Value<bool> isActive,
  Value<int> serverRevision,
  Value<String> syncStatus,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$StaffTableUpdateCompanionBuilder = StaffCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String?> campusId,
  Value<String?> userId,
  Value<String?> staffNumber,
  Value<String> firstName,
  Value<String?> middleName,
  Value<String> lastName,
  Value<String?> gender,
  Value<String?> phone,
  Value<String?> email,
  Value<String?> department,
  Value<String> systemRole,
  Value<String> employmentType,
  Value<String?> dateJoined,
  Value<bool> isActive,
  Value<int> serverRevision,
  Value<String> syncStatus,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$StaffTableFilterComposer extends Composer<_$AppDatabase, $StaffTable> {
  $$StaffTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get staffNumber => $composableBuilder(
      column: $table.staffNumber, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get firstName => $composableBuilder(
      column: $table.firstName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get middleName => $composableBuilder(
      column: $table.middleName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get lastName => $composableBuilder(
      column: $table.lastName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get gender => $composableBuilder(
      column: $table.gender, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get phone => $composableBuilder(
      column: $table.phone, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get email => $composableBuilder(
      column: $table.email, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get department => $composableBuilder(
      column: $table.department, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get systemRole => $composableBuilder(
      column: $table.systemRole, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get employmentType => $composableBuilder(
      column: $table.employmentType,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get dateJoined => $composableBuilder(
      column: $table.dateJoined, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$StaffTableOrderingComposer
    extends Composer<_$AppDatabase, $StaffTable> {
  $$StaffTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get staffNumber => $composableBuilder(
      column: $table.staffNumber, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get firstName => $composableBuilder(
      column: $table.firstName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get middleName => $composableBuilder(
      column: $table.middleName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get lastName => $composableBuilder(
      column: $table.lastName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get gender => $composableBuilder(
      column: $table.gender, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get phone => $composableBuilder(
      column: $table.phone, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get email => $composableBuilder(
      column: $table.email, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get department => $composableBuilder(
      column: $table.department, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get systemRole => $composableBuilder(
      column: $table.systemRole, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get employmentType => $composableBuilder(
      column: $table.employmentType,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get dateJoined => $composableBuilder(
      column: $table.dateJoined, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$StaffTableAnnotationComposer
    extends Composer<_$AppDatabase, $StaffTable> {
  $$StaffTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get campusId =>
      $composableBuilder(column: $table.campusId, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get staffNumber => $composableBuilder(
      column: $table.staffNumber, builder: (column) => column);

  GeneratedColumn<String> get firstName =>
      $composableBuilder(column: $table.firstName, builder: (column) => column);

  GeneratedColumn<String> get middleName => $composableBuilder(
      column: $table.middleName, builder: (column) => column);

  GeneratedColumn<String> get lastName =>
      $composableBuilder(column: $table.lastName, builder: (column) => column);

  GeneratedColumn<String> get gender =>
      $composableBuilder(column: $table.gender, builder: (column) => column);

  GeneratedColumn<String> get phone =>
      $composableBuilder(column: $table.phone, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<String> get department => $composableBuilder(
      column: $table.department, builder: (column) => column);

  GeneratedColumn<String> get systemRole => $composableBuilder(
      column: $table.systemRole, builder: (column) => column);

  GeneratedColumn<String> get employmentType => $composableBuilder(
      column: $table.employmentType, builder: (column) => column);

  GeneratedColumn<String> get dateJoined => $composableBuilder(
      column: $table.dateJoined, builder: (column) => column);

  GeneratedColumn<bool> get isActive =>
      $composableBuilder(column: $table.isActive, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$StaffTableTableManager extends RootTableManager<
    _$AppDatabase,
    $StaffTable,
    StaffData,
    $$StaffTableFilterComposer,
    $$StaffTableOrderingComposer,
    $$StaffTableAnnotationComposer,
    $$StaffTableCreateCompanionBuilder,
    $$StaffTableUpdateCompanionBuilder,
    (StaffData, BaseReferences<_$AppDatabase, $StaffTable, StaffData>),
    StaffData,
    PrefetchHooks Function()> {
  $$StaffTableTableManager(_$AppDatabase db, $StaffTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$StaffTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$StaffTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$StaffTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String?> campusId = const Value.absent(),
            Value<String?> userId = const Value.absent(),
            Value<String?> staffNumber = const Value.absent(),
            Value<String> firstName = const Value.absent(),
            Value<String?> middleName = const Value.absent(),
            Value<String> lastName = const Value.absent(),
            Value<String?> gender = const Value.absent(),
            Value<String?> phone = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> department = const Value.absent(),
            Value<String> systemRole = const Value.absent(),
            Value<String> employmentType = const Value.absent(),
            Value<String?> dateJoined = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              StaffCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            userId: userId,
            staffNumber: staffNumber,
            firstName: firstName,
            middleName: middleName,
            lastName: lastName,
            gender: gender,
            phone: phone,
            email: email,
            department: department,
            systemRole: systemRole,
            employmentType: employmentType,
            dateJoined: dateJoined,
            isActive: isActive,
            serverRevision: serverRevision,
            syncStatus: syncStatus,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            Value<String?> campusId = const Value.absent(),
            Value<String?> userId = const Value.absent(),
            Value<String?> staffNumber = const Value.absent(),
            required String firstName,
            Value<String?> middleName = const Value.absent(),
            required String lastName,
            Value<String?> gender = const Value.absent(),
            Value<String?> phone = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> department = const Value.absent(),
            Value<String> systemRole = const Value.absent(),
            Value<String> employmentType = const Value.absent(),
            Value<String?> dateJoined = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              StaffCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            userId: userId,
            staffNumber: staffNumber,
            firstName: firstName,
            middleName: middleName,
            lastName: lastName,
            gender: gender,
            phone: phone,
            email: email,
            department: department,
            systemRole: systemRole,
            employmentType: employmentType,
            dateJoined: dateJoined,
            isActive: isActive,
            serverRevision: serverRevision,
            syncStatus: syncStatus,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$StaffTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $StaffTable,
    StaffData,
    $$StaffTableFilterComposer,
    $$StaffTableOrderingComposer,
    $$StaffTableAnnotationComposer,
    $$StaffTableCreateCompanionBuilder,
    $$StaffTableUpdateCompanionBuilder,
    (StaffData, BaseReferences<_$AppDatabase, $StaffTable, StaffData>),
    StaffData,
    PrefetchHooks Function()>;
typedef $$StaffTeachingAssignmentsTableCreateCompanionBuilder
    = StaffTeachingAssignmentsCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  required String staffId,
  required String assignmentType,
  Value<String?> subjectId,
  Value<String?> classArmId,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$StaffTeachingAssignmentsTableUpdateCompanionBuilder
    = StaffTeachingAssignmentsCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String> staffId,
  Value<String> assignmentType,
  Value<String?> subjectId,
  Value<String?> classArmId,
  Value<int> serverRevision,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$StaffTeachingAssignmentsTableFilterComposer
    extends Composer<_$AppDatabase, $StaffTeachingAssignmentsTable> {
  $$StaffTeachingAssignmentsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get staffId => $composableBuilder(
      column: $table.staffId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get assignmentType => $composableBuilder(
      column: $table.assignmentType,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get subjectId => $composableBuilder(
      column: $table.subjectId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get classArmId => $composableBuilder(
      column: $table.classArmId, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$StaffTeachingAssignmentsTableOrderingComposer
    extends Composer<_$AppDatabase, $StaffTeachingAssignmentsTable> {
  $$StaffTeachingAssignmentsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get staffId => $composableBuilder(
      column: $table.staffId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get assignmentType => $composableBuilder(
      column: $table.assignmentType,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get subjectId => $composableBuilder(
      column: $table.subjectId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get classArmId => $composableBuilder(
      column: $table.classArmId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$StaffTeachingAssignmentsTableAnnotationComposer
    extends Composer<_$AppDatabase, $StaffTeachingAssignmentsTable> {
  $$StaffTeachingAssignmentsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get staffId =>
      $composableBuilder(column: $table.staffId, builder: (column) => column);

  GeneratedColumn<String> get assignmentType => $composableBuilder(
      column: $table.assignmentType, builder: (column) => column);

  GeneratedColumn<String> get subjectId =>
      $composableBuilder(column: $table.subjectId, builder: (column) => column);

  GeneratedColumn<String> get classArmId => $composableBuilder(
      column: $table.classArmId, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$StaffTeachingAssignmentsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $StaffTeachingAssignmentsTable,
    StaffTeachingAssignment,
    $$StaffTeachingAssignmentsTableFilterComposer,
    $$StaffTeachingAssignmentsTableOrderingComposer,
    $$StaffTeachingAssignmentsTableAnnotationComposer,
    $$StaffTeachingAssignmentsTableCreateCompanionBuilder,
    $$StaffTeachingAssignmentsTableUpdateCompanionBuilder,
    (
      StaffTeachingAssignment,
      BaseReferences<_$AppDatabase, $StaffTeachingAssignmentsTable,
          StaffTeachingAssignment>
    ),
    StaffTeachingAssignment,
    PrefetchHooks Function()> {
  $$StaffTeachingAssignmentsTableTableManager(
      _$AppDatabase db, $StaffTeachingAssignmentsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$StaffTeachingAssignmentsTableFilterComposer(
                  $db: db, $table: table),
          createOrderingComposer: () =>
              $$StaffTeachingAssignmentsTableOrderingComposer(
                  $db: db, $table: table),
          createComputedFieldComposer: () =>
              $$StaffTeachingAssignmentsTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String> staffId = const Value.absent(),
            Value<String> assignmentType = const Value.absent(),
            Value<String?> subjectId = const Value.absent(),
            Value<String?> classArmId = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              StaffTeachingAssignmentsCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            staffId: staffId,
            assignmentType: assignmentType,
            subjectId: subjectId,
            classArmId: classArmId,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            required String staffId,
            required String assignmentType,
            Value<String?> subjectId = const Value.absent(),
            Value<String?> classArmId = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              StaffTeachingAssignmentsCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            staffId: staffId,
            assignmentType: assignmentType,
            subjectId: subjectId,
            classArmId: classArmId,
            serverRevision: serverRevision,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$StaffTeachingAssignmentsTableProcessedTableManager
    = ProcessedTableManager<
        _$AppDatabase,
        $StaffTeachingAssignmentsTable,
        StaffTeachingAssignment,
        $$StaffTeachingAssignmentsTableFilterComposer,
        $$StaffTeachingAssignmentsTableOrderingComposer,
        $$StaffTeachingAssignmentsTableAnnotationComposer,
        $$StaffTeachingAssignmentsTableCreateCompanionBuilder,
        $$StaffTeachingAssignmentsTableUpdateCompanionBuilder,
        (
          StaffTeachingAssignment,
          BaseReferences<_$AppDatabase, $StaffTeachingAssignmentsTable,
              StaffTeachingAssignment>
        ),
        StaffTeachingAssignment,
        PrefetchHooks Function()>;
typedef $$ApplicantsTableCreateCompanionBuilder = ApplicantsCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  Value<String?> campusId,
  required String firstName,
  Value<String?> middleName,
  required String lastName,
  Value<String?> dateOfBirth,
  Value<String?> gender,
  Value<String?> classLevelId,
  Value<String?> academicYearId,
  Value<String> status,
  Value<String?> guardianName,
  Value<String?> guardianPhone,
  Value<String?> guardianEmail,
  Value<String?> documentNotes,
  Value<String?> studentId,
  Value<DateTime?> admittedAt,
  Value<int> serverRevision,
  Value<String> syncStatus,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$ApplicantsTableUpdateCompanionBuilder = ApplicantsCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String?> campusId,
  Value<String> firstName,
  Value<String?> middleName,
  Value<String> lastName,
  Value<String?> dateOfBirth,
  Value<String?> gender,
  Value<String?> classLevelId,
  Value<String?> academicYearId,
  Value<String> status,
  Value<String?> guardianName,
  Value<String?> guardianPhone,
  Value<String?> guardianEmail,
  Value<String?> documentNotes,
  Value<String?> studentId,
  Value<DateTime?> admittedAt,
  Value<int> serverRevision,
  Value<String> syncStatus,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$ApplicantsTableFilterComposer
    extends Composer<_$AppDatabase, $ApplicantsTable> {
  $$ApplicantsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get firstName => $composableBuilder(
      column: $table.firstName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get middleName => $composableBuilder(
      column: $table.middleName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get lastName => $composableBuilder(
      column: $table.lastName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get dateOfBirth => $composableBuilder(
      column: $table.dateOfBirth, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get gender => $composableBuilder(
      column: $table.gender, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get classLevelId => $composableBuilder(
      column: $table.classLevelId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get guardianName => $composableBuilder(
      column: $table.guardianName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get guardianPhone => $composableBuilder(
      column: $table.guardianPhone, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get guardianEmail => $composableBuilder(
      column: $table.guardianEmail, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get documentNotes => $composableBuilder(
      column: $table.documentNotes, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get studentId => $composableBuilder(
      column: $table.studentId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get admittedAt => $composableBuilder(
      column: $table.admittedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$ApplicantsTableOrderingComposer
    extends Composer<_$AppDatabase, $ApplicantsTable> {
  $$ApplicantsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get firstName => $composableBuilder(
      column: $table.firstName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get middleName => $composableBuilder(
      column: $table.middleName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get lastName => $composableBuilder(
      column: $table.lastName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get dateOfBirth => $composableBuilder(
      column: $table.dateOfBirth, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get gender => $composableBuilder(
      column: $table.gender, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get classLevelId => $composableBuilder(
      column: $table.classLevelId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get guardianName => $composableBuilder(
      column: $table.guardianName,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get guardianPhone => $composableBuilder(
      column: $table.guardianPhone,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get guardianEmail => $composableBuilder(
      column: $table.guardianEmail,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get documentNotes => $composableBuilder(
      column: $table.documentNotes,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get studentId => $composableBuilder(
      column: $table.studentId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get admittedAt => $composableBuilder(
      column: $table.admittedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$ApplicantsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ApplicantsTable> {
  $$ApplicantsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get campusId =>
      $composableBuilder(column: $table.campusId, builder: (column) => column);

  GeneratedColumn<String> get firstName =>
      $composableBuilder(column: $table.firstName, builder: (column) => column);

  GeneratedColumn<String> get middleName => $composableBuilder(
      column: $table.middleName, builder: (column) => column);

  GeneratedColumn<String> get lastName =>
      $composableBuilder(column: $table.lastName, builder: (column) => column);

  GeneratedColumn<String> get dateOfBirth => $composableBuilder(
      column: $table.dateOfBirth, builder: (column) => column);

  GeneratedColumn<String> get gender =>
      $composableBuilder(column: $table.gender, builder: (column) => column);

  GeneratedColumn<String> get classLevelId => $composableBuilder(
      column: $table.classLevelId, builder: (column) => column);

  GeneratedColumn<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get guardianName => $composableBuilder(
      column: $table.guardianName, builder: (column) => column);

  GeneratedColumn<String> get guardianPhone => $composableBuilder(
      column: $table.guardianPhone, builder: (column) => column);

  GeneratedColumn<String> get guardianEmail => $composableBuilder(
      column: $table.guardianEmail, builder: (column) => column);

  GeneratedColumn<String> get documentNotes => $composableBuilder(
      column: $table.documentNotes, builder: (column) => column);

  GeneratedColumn<String> get studentId =>
      $composableBuilder(column: $table.studentId, builder: (column) => column);

  GeneratedColumn<DateTime> get admittedAt => $composableBuilder(
      column: $table.admittedAt, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$ApplicantsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ApplicantsTable,
    Applicant,
    $$ApplicantsTableFilterComposer,
    $$ApplicantsTableOrderingComposer,
    $$ApplicantsTableAnnotationComposer,
    $$ApplicantsTableCreateCompanionBuilder,
    $$ApplicantsTableUpdateCompanionBuilder,
    (Applicant, BaseReferences<_$AppDatabase, $ApplicantsTable, Applicant>),
    Applicant,
    PrefetchHooks Function()> {
  $$ApplicantsTableTableManager(_$AppDatabase db, $ApplicantsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ApplicantsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ApplicantsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ApplicantsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String?> campusId = const Value.absent(),
            Value<String> firstName = const Value.absent(),
            Value<String?> middleName = const Value.absent(),
            Value<String> lastName = const Value.absent(),
            Value<String?> dateOfBirth = const Value.absent(),
            Value<String?> gender = const Value.absent(),
            Value<String?> classLevelId = const Value.absent(),
            Value<String?> academicYearId = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String?> guardianName = const Value.absent(),
            Value<String?> guardianPhone = const Value.absent(),
            Value<String?> guardianEmail = const Value.absent(),
            Value<String?> documentNotes = const Value.absent(),
            Value<String?> studentId = const Value.absent(),
            Value<DateTime?> admittedAt = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ApplicantsCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            firstName: firstName,
            middleName: middleName,
            lastName: lastName,
            dateOfBirth: dateOfBirth,
            gender: gender,
            classLevelId: classLevelId,
            academicYearId: academicYearId,
            status: status,
            guardianName: guardianName,
            guardianPhone: guardianPhone,
            guardianEmail: guardianEmail,
            documentNotes: documentNotes,
            studentId: studentId,
            admittedAt: admittedAt,
            serverRevision: serverRevision,
            syncStatus: syncStatus,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            Value<String?> campusId = const Value.absent(),
            required String firstName,
            Value<String?> middleName = const Value.absent(),
            required String lastName,
            Value<String?> dateOfBirth = const Value.absent(),
            Value<String?> gender = const Value.absent(),
            Value<String?> classLevelId = const Value.absent(),
            Value<String?> academicYearId = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String?> guardianName = const Value.absent(),
            Value<String?> guardianPhone = const Value.absent(),
            Value<String?> guardianEmail = const Value.absent(),
            Value<String?> documentNotes = const Value.absent(),
            Value<String?> studentId = const Value.absent(),
            Value<DateTime?> admittedAt = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ApplicantsCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            firstName: firstName,
            middleName: middleName,
            lastName: lastName,
            dateOfBirth: dateOfBirth,
            gender: gender,
            classLevelId: classLevelId,
            academicYearId: academicYearId,
            status: status,
            guardianName: guardianName,
            guardianPhone: guardianPhone,
            guardianEmail: guardianEmail,
            documentNotes: documentNotes,
            studentId: studentId,
            admittedAt: admittedAt,
            serverRevision: serverRevision,
            syncStatus: syncStatus,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ApplicantsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ApplicantsTable,
    Applicant,
    $$ApplicantsTableFilterComposer,
    $$ApplicantsTableOrderingComposer,
    $$ApplicantsTableAnnotationComposer,
    $$ApplicantsTableCreateCompanionBuilder,
    $$ApplicantsTableUpdateCompanionBuilder,
    (Applicant, BaseReferences<_$AppDatabase, $ApplicantsTable, Applicant>),
    Applicant,
    PrefetchHooks Function()>;
typedef $$AttendanceRecordsTableCreateCompanionBuilder
    = AttendanceRecordsCompanion Function({
  required String id,
  required String tenantId,
  required String schoolId,
  Value<String?> campusId,
  required String studentId,
  required String classArmId,
  required String academicYearId,
  required String termId,
  required String attendanceDate,
  Value<String> status,
  Value<String?> notes,
  Value<String?> recordedByUserId,
  Value<int> serverRevision,
  Value<String> syncStatus,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$AttendanceRecordsTableUpdateCompanionBuilder
    = AttendanceRecordsCompanion Function({
  Value<String> id,
  Value<String> tenantId,
  Value<String> schoolId,
  Value<String?> campusId,
  Value<String> studentId,
  Value<String> classArmId,
  Value<String> academicYearId,
  Value<String> termId,
  Value<String> attendanceDate,
  Value<String> status,
  Value<String?> notes,
  Value<String?> recordedByUserId,
  Value<int> serverRevision,
  Value<String> syncStatus,
  Value<bool> deleted,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$AttendanceRecordsTableFilterComposer
    extends Composer<_$AppDatabase, $AttendanceRecordsTable> {
  $$AttendanceRecordsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get studentId => $composableBuilder(
      column: $table.studentId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get classArmId => $composableBuilder(
      column: $table.classArmId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get termId => $composableBuilder(
      column: $table.termId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get attendanceDate => $composableBuilder(
      column: $table.attendanceDate,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get recordedByUserId => $composableBuilder(
      column: $table.recordedByUserId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$AttendanceRecordsTableOrderingComposer
    extends Composer<_$AppDatabase, $AttendanceRecordsTable> {
  $$AttendanceRecordsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tenantId => $composableBuilder(
      column: $table.tenantId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get schoolId => $composableBuilder(
      column: $table.schoolId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get campusId => $composableBuilder(
      column: $table.campusId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get studentId => $composableBuilder(
      column: $table.studentId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get classArmId => $composableBuilder(
      column: $table.classArmId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get termId => $composableBuilder(
      column: $table.termId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get attendanceDate => $composableBuilder(
      column: $table.attendanceDate,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get recordedByUserId => $composableBuilder(
      column: $table.recordedByUserId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get deleted => $composableBuilder(
      column: $table.deleted, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$AttendanceRecordsTableAnnotationComposer
    extends Composer<_$AppDatabase, $AttendanceRecordsTable> {
  $$AttendanceRecordsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get tenantId =>
      $composableBuilder(column: $table.tenantId, builder: (column) => column);

  GeneratedColumn<String> get schoolId =>
      $composableBuilder(column: $table.schoolId, builder: (column) => column);

  GeneratedColumn<String> get campusId =>
      $composableBuilder(column: $table.campusId, builder: (column) => column);

  GeneratedColumn<String> get studentId =>
      $composableBuilder(column: $table.studentId, builder: (column) => column);

  GeneratedColumn<String> get classArmId => $composableBuilder(
      column: $table.classArmId, builder: (column) => column);

  GeneratedColumn<String> get academicYearId => $composableBuilder(
      column: $table.academicYearId, builder: (column) => column);

  GeneratedColumn<String> get termId =>
      $composableBuilder(column: $table.termId, builder: (column) => column);

  GeneratedColumn<String> get attendanceDate => $composableBuilder(
      column: $table.attendanceDate, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get notes =>
      $composableBuilder(column: $table.notes, builder: (column) => column);

  GeneratedColumn<String> get recordedByUserId => $composableBuilder(
      column: $table.recordedByUserId, builder: (column) => column);

  GeneratedColumn<int> get serverRevision => $composableBuilder(
      column: $table.serverRevision, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$AttendanceRecordsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $AttendanceRecordsTable,
    AttendanceRecord,
    $$AttendanceRecordsTableFilterComposer,
    $$AttendanceRecordsTableOrderingComposer,
    $$AttendanceRecordsTableAnnotationComposer,
    $$AttendanceRecordsTableCreateCompanionBuilder,
    $$AttendanceRecordsTableUpdateCompanionBuilder,
    (
      AttendanceRecord,
      BaseReferences<_$AppDatabase, $AttendanceRecordsTable, AttendanceRecord>
    ),
    AttendanceRecord,
    PrefetchHooks Function()> {
  $$AttendanceRecordsTableTableManager(
      _$AppDatabase db, $AttendanceRecordsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$AttendanceRecordsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$AttendanceRecordsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$AttendanceRecordsTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> tenantId = const Value.absent(),
            Value<String> schoolId = const Value.absent(),
            Value<String?> campusId = const Value.absent(),
            Value<String> studentId = const Value.absent(),
            Value<String> classArmId = const Value.absent(),
            Value<String> academicYearId = const Value.absent(),
            Value<String> termId = const Value.absent(),
            Value<String> attendanceDate = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            Value<String?> recordedByUserId = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AttendanceRecordsCompanion(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            studentId: studentId,
            classArmId: classArmId,
            academicYearId: academicYearId,
            termId: termId,
            attendanceDate: attendanceDate,
            status: status,
            notes: notes,
            recordedByUserId: recordedByUserId,
            serverRevision: serverRevision,
            syncStatus: syncStatus,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String tenantId,
            required String schoolId,
            Value<String?> campusId = const Value.absent(),
            required String studentId,
            required String classArmId,
            required String academicYearId,
            required String termId,
            required String attendanceDate,
            Value<String> status = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            Value<String?> recordedByUserId = const Value.absent(),
            Value<int> serverRevision = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<bool> deleted = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AttendanceRecordsCompanion.insert(
            id: id,
            tenantId: tenantId,
            schoolId: schoolId,
            campusId: campusId,
            studentId: studentId,
            classArmId: classArmId,
            academicYearId: academicYearId,
            termId: termId,
            attendanceDate: attendanceDate,
            status: status,
            notes: notes,
            recordedByUserId: recordedByUserId,
            serverRevision: serverRevision,
            syncStatus: syncStatus,
            deleted: deleted,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$AttendanceRecordsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $AttendanceRecordsTable,
    AttendanceRecord,
    $$AttendanceRecordsTableFilterComposer,
    $$AttendanceRecordsTableOrderingComposer,
    $$AttendanceRecordsTableAnnotationComposer,
    $$AttendanceRecordsTableCreateCompanionBuilder,
    $$AttendanceRecordsTableUpdateCompanionBuilder,
    (
      AttendanceRecord,
      BaseReferences<_$AppDatabase, $AttendanceRecordsTable, AttendanceRecord>
    ),
    AttendanceRecord,
    PrefetchHooks Function()>;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$SyncQueueTableTableManager get syncQueue =>
      $$SyncQueueTableTableManager(_db, _db.syncQueue);
  $$SyncStateTableTableManager get syncState =>
      $$SyncStateTableTableManager(_db, _db.syncState);
  $$SyncConflictsTableTableManager get syncConflicts =>
      $$SyncConflictsTableTableManager(_db, _db.syncConflicts);
  $$SyncReconciliationRequestsCacheTableTableManager
      get syncReconciliationRequestsCache =>
          $$SyncReconciliationRequestsCacheTableTableManager(
              _db, _db.syncReconciliationRequestsCache);
  $$AcademicYearsCacheTableTableManager get academicYearsCache =>
      $$AcademicYearsCacheTableTableManager(_db, _db.academicYearsCache);
  $$TermsCacheTableTableManager get termsCache =>
      $$TermsCacheTableTableManager(_db, _db.termsCache);
  $$ClassLevelsCacheTableTableManager get classLevelsCache =>
      $$ClassLevelsCacheTableTableManager(_db, _db.classLevelsCache);
  $$ClassArmsCacheTableTableManager get classArmsCache =>
      $$ClassArmsCacheTableTableManager(_db, _db.classArmsCache);
  $$SubjectsCacheTableTableManager get subjectsCache =>
      $$SubjectsCacheTableTableManager(_db, _db.subjectsCache);
  $$GradingSchemesCacheTableTableManager get gradingSchemesCache =>
      $$GradingSchemesCacheTableTableManager(_db, _db.gradingSchemesCache);
  $$FeeCategoriesTableTableManager get feeCategories =>
      $$FeeCategoriesTableTableManager(_db, _db.feeCategories);
  $$FeeStructureItemsTableTableManager get feeStructureItems =>
      $$FeeStructureItemsTableTableManager(_db, _db.feeStructureItems);
  $$InvoicesTableTableManager get invoices =>
      $$InvoicesTableTableManager(_db, _db.invoices);
  $$PaymentsTableTableManager get payments =>
      $$PaymentsTableTableManager(_db, _db.payments);
  $$PaymentReversalsTableTableManager get paymentReversals =>
      $$PaymentReversalsTableTableManager(_db, _db.paymentReversals);
  $$SchoolProfileCacheTableTableManager get schoolProfileCache =>
      $$SchoolProfileCacheTableTableManager(_db, _db.schoolProfileCache);
  $$CampusProfileCacheTableTableManager get campusProfileCache =>
      $$CampusProfileCacheTableTableManager(_db, _db.campusProfileCache);
  $$StudentsTableTableManager get students =>
      $$StudentsTableTableManager(_db, _db.students);
  $$GuardiansTableTableManager get guardians =>
      $$GuardiansTableTableManager(_db, _db.guardians);
  $$EnrollmentsTableTableManager get enrollments =>
      $$EnrollmentsTableTableManager(_db, _db.enrollments);
  $$StaffTableTableManager get staff =>
      $$StaffTableTableManager(_db, _db.staff);
  $$StaffTeachingAssignmentsTableTableManager get staffTeachingAssignments =>
      $$StaffTeachingAssignmentsTableTableManager(
          _db, _db.staffTeachingAssignments);
  $$ApplicantsTableTableManager get applicants =>
      $$ApplicantsTableTableManager(_db, _db.applicants);
  $$AttendanceRecordsTableTableManager get attendanceRecords =>
      $$AttendanceRecordsTableTableManager(_db, _db.attendanceRecords);
}
