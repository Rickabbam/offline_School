import { BadRequestException, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { DataSource, Repository } from "typeorm";
import * as bcrypt from "bcrypt";
import { randomUUID } from "crypto";
import { Tenant, TenantStatus } from "../tenants/tenant.entity";
import { School } from "../schools/school.entity";
import { Campus } from "../campuses/campus.entity";
import {
  AcademicYear,
  ClassArm,
  ClassLevel,
  GradingScheme,
  Subject,
  Term,
} from "../academic/academic.entity";
import { User } from "../users/user.entity";
import { Device } from "../devices/device.entity";
import { BootstrapSchoolSetupDto } from "./dto/bootstrap-school.dto";

@Injectable()
export class OnboardingService {
  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(User) private readonly users: Repository<User>,
  ) {}

  async bootstrapSchoolSetup(
    currentUserId: string,
    dto: BootstrapSchoolSetupDto,
  ) {
    const currentUser = await this.users.findOne({
      where: { id: currentUserId, deleted: false, isActive: true },
    });

    if (!currentUser) {
      throw new BadRequestException("Authenticated user not found.");
    }

    if (currentUser.tenantId || currentUser.schoolId || currentUser.campusId) {
      throw new BadRequestException(
        "School setup has already been completed for this user.",
      );
    }

    const userId = currentUser.id;
    const shouldRegisterTrustedDevice =
      dto.deviceRegistration.registerOfflineAccess;
    if (
      shouldRegisterTrustedDevice &&
      (!dto.deviceRegistration.deviceFingerprint ||
        !dto.deviceRegistration.deviceName)
    ) {
      throw new BadRequestException(
        "Trusted device registration requires a device name and fingerprint.",
      );
    }

    return this.dataSource.transaction(async (manager) => {
      const tenant = await manager.save(
        Tenant,
        manager.create(Tenant, {
          name: dto.school.name,
          status: TenantStatus.Trial,
          contactEmail: dto.school.contactEmail ?? null,
          contactPhone: dto.school.contactPhone ?? null,
          deleted: false,
        }),
      );

      const school = await manager.save(
        School,
        manager.create(School, {
          tenantId: tenant.id,
          name: dto.school.name,
          shortName: dto.school.shortName ?? null,
          schoolType: dto.school.schoolType,
          address: dto.school.address ?? null,
          region: dto.school.region ?? null,
          district: dto.school.district ?? null,
          contactPhone: dto.school.contactPhone ?? null,
          contactEmail: dto.school.contactEmail ?? null,
          onboardingDefaults: {
            staffRoles: dto.onboardingDefaults.staffRoles,
            feeCategories: dto.onboardingDefaults.feeCategories,
            receiptFormat: dto.onboardingDefaults.receiptFormat,
            notifications: dto.onboardingDefaults.notifications,
          },
          serverRevision: await this.nextServerRevision(manager),
          deleted: false,
        }),
      );

      const campus = await manager.save(
        Campus,
        manager.create(Campus, {
          tenantId: tenant.id,
          schoolId: school.id,
          name: dto.campus.name,
          address: dto.campus.address ?? null,
          contactPhone: dto.campus.contactPhone ?? null,
          registrationCode: dto.campus.registrationCode ?? null,
          serverRevision: await this.nextServerRevision(manager),
          deleted: false,
        }),
      );

      const year = await manager.save(
        AcademicYear,
        manager.create(AcademicYear, {
          tenantId: tenant.id,
          schoolId: school.id,
          label: dto.academicYear.label,
          startDate: dto.academicYear.startDate,
          endDate: dto.academicYear.endDate,
          isCurrent: true,
          serverRevision: await this.nextServerRevision(manager),
          deleted: false,
        }),
      );

      const terms: Term[] = [];
      for (const term of dto.academicYear.terms) {
        const savedTerm = await manager.save(
          Term,
          manager.create(Term, {
            tenantId: tenant.id,
            schoolId: school.id,
            academicYearId: year.id,
            name: term.name,
            termNumber: term.termNumber,
            startDate: term.startDate,
            endDate: term.endDate,
            isCurrent: term.isCurrent,
            serverRevision: await this.nextServerRevision(manager),
            deleted: false,
          }),
        );
        terms.push(savedTerm);
      }

      const classLevels: ClassLevel[] = [];
      const classArms: ClassArm[] = [];
      for (const levelDto of dto.classLevels) {
        const level = await manager.save(
          ClassLevel,
          manager.create(ClassLevel, {
            tenantId: tenant.id,
            schoolId: school.id,
            name: levelDto.name,
            sortOrder: levelDto.sortOrder,
            serverRevision: await this.nextServerRevision(manager),
            deleted: false,
          }),
        );
        classLevels.push(level);

        for (const armDto of levelDto.arms) {
          const classArm = await manager.save(
            ClassArm,
            manager.create(ClassArm, {
              tenantId: tenant.id,
              schoolId: school.id,
              classLevelId: level.id,
              arm: armDto.arm,
              displayName: `${levelDto.name} ${armDto.arm}`,
              serverRevision: await this.nextServerRevision(manager),
              deleted: false,
            }),
          );
          classArms.push(classArm);
        }
      }

      const subjects: Subject[] = [];
      for (const subjectDto of dto.subjects) {
        const subject = await manager.save(
          Subject,
          manager.create(Subject, {
            tenantId: tenant.id,
            schoolId: school.id,
            name: subjectDto.name,
            code: subjectDto.code ?? null,
            serverRevision: await this.nextServerRevision(manager),
            deleted: false,
          }),
        );
        subjects.push(subject);
      }

      const gradingScheme = await manager.save(
        GradingScheme,
        manager.create(GradingScheme, {
          tenantId: tenant.id,
          schoolId: school.id,
          name: dto.gradingScheme.name,
          bands: dto.gradingScheme.bands,
          isDefault: true,
          serverRevision: await this.nextServerRevision(manager),
          deleted: false,
        }),
      );

      await manager.update(User, userId, {
        tenantId: tenant.id,
        schoolId: school.id,
        campusId: campus.id,
      });

      let deviceRegistration:
        | {
            deviceId: string;
            deviceName: string;
            deviceFingerprint: string;
            offlineToken: string;
          }
        | null = null;

      if (shouldRegisterTrustedDevice) {
        const rawOfflineToken = `${randomUUID()}-${randomUUID()}`;
        const offlineTokenHash = await bcrypt.hash(rawOfflineToken, 12);
        const existingDevice = await manager.findOne(Device, {
          where: {
            deviceFingerprint: dto.deviceRegistration.deviceFingerprint,
          },
        });

        if (existingDevice && existingDevice.registeredByUserId !== userId) {
          throw new BadRequestException(
            "Device fingerprint is already registered to another user.",
          );
        }

        const device = await manager.save(
          Device,
          manager.create(Device, {
            ...(existingDevice ?? {}),
            id: existingDevice?.id,
            deviceName: dto.deviceRegistration.deviceName,
            deviceFingerprint: dto.deviceRegistration.deviceFingerprint,
            offlineTokenHash,
            tenantId: tenant.id,
            schoolId: school.id,
            campusId: campus.id,
            registeredByUserId: userId,
            isActive: true,
          }),
        );

        deviceRegistration = {
          deviceId: device.id,
          deviceName: device.deviceName,
          deviceFingerprint: device.deviceFingerprint,
          offlineToken: rawOfflineToken,
        };
      }

      const updatedUser = await manager.findOne(User, {
        where: { id: userId },
      });

      return {
        tenant: {
          id: tenant.id,
          name: tenant.name,
        },
        school: {
          id: school.id,
          tenantId: school.tenantId,
          name: school.name,
          shortName: school.shortName,
          schoolType: school.schoolType,
          address: school.address,
          region: school.region,
          district: school.district,
          contactPhone: school.contactPhone,
          contactEmail: school.contactEmail,
          onboardingDefaults: school.onboardingDefaults,
          serverRevision: school.serverRevision,
          deleted: school.deleted,
          createdAt: school.createdAt.toISOString(),
          updatedAt: school.updatedAt.toISOString(),
        },
        campus: {
          id: campus.id,
          tenantId: campus.tenantId,
          schoolId: campus.schoolId,
          name: campus.name,
          address: campus.address,
          contactPhone: campus.contactPhone,
          registrationCode: campus.registrationCode,
          serverRevision: campus.serverRevision,
          deleted: campus.deleted,
          createdAt: campus.createdAt.toISOString(),
          updatedAt: campus.updatedAt.toISOString(),
        },
        bootstrapSnapshot: {
          academicYear: this.serializeEntity(year),
          terms: terms.map((term) => this.serializeEntity(term)),
          classLevels: classLevels.map((level) => this.serializeEntity(level)),
          classArms: classArms.map((arm) => this.serializeEntity(arm)),
          subjects: subjects.map((subject) => this.serializeEntity(subject)),
          gradingScheme: this.serializeEntity(gradingScheme),
        },
        user: updatedUser
          ? {
              id: updatedUser.id,
              email: updatedUser.email,
              fullName: updatedUser.fullName,
              role: updatedUser.role,
              tenantId: updatedUser.tenantId,
              schoolId: updatedUser.schoolId,
              campusId: updatedUser.campusId,
            }
          : null,
        deviceRegistration,
      };
    });
  }

  private serializeEntity<T extends { createdAt: Date; updatedAt: Date }>(
    entity: T,
  ) {
    return {
      ...entity,
      createdAt: entity.createdAt.toISOString(),
      updatedAt: entity.updatedAt.toISOString(),
    };
  }

  private async nextServerRevision(manager: {
    query: (query: string) => Promise<unknown>;
  }) {
    const result = (await manager.query(
      "SELECT nextval('sync_server_revision_seq')::bigint AS revision",
    )) as { revision: string | number }[];
    return Number(result[0].revision);
  }
}
