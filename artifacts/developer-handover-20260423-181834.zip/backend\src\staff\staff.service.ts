import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository, ILike } from 'typeorm';
import { Campus } from '../campuses/campus.entity';
import { Staff } from './staff.entity';

@Injectable()
export class StaffService {
  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(Staff) private readonly repo: Repository<Staff>,
    @InjectRepository(Campus) private readonly campuses: Repository<Campus>,
  ) {}

  findAll(tenantId: string, schoolId: string, search?: string) {
    if (search) {
      return this.repo.find({
        where: [
          { tenantId, schoolId, deleted: false, firstName: ILike(`%${search}%`) },
          { tenantId, schoolId, deleted: false, lastName: ILike(`%${search}%`) },
        ],
      });
    }
    return this.repo.find({ where: { tenantId, schoolId, deleted: false } });
  }

  findById(tenantId: string, schoolId: string, id: string) {
    return this.repo.findOne({ where: { id, tenantId, schoolId, deleted: false } });
  }

  async create(tenantId: string, schoolId: string, data: Partial<Staff>) {
    await this.assertCampusInScope(tenantId, schoolId, data.campusId);
    return this.repo.save(
      this.repo.create({
        ...data,
        tenantId,
        schoolId,
        serverRevision: await this.nextServerRevision(),
        syncStatus: 'local',
      }),
    );
  }

  async update(tenantId: string, schoolId: string, id: string, data: Partial<Staff>) {
    const staff = await this.repo.findOne({ where: { id, tenantId, schoolId, deleted: false } });
    if (!staff) throw new NotFoundException('Staff member not found.');
    await this.assertCampusInScope(tenantId, schoolId, data.campusId);
    await this.repo.update(id, {
      ...data,
      serverRevision: await this.nextServerRevision(),
      syncStatus: 'local',
    });
    return this.findById(tenantId, schoolId, id);
  }

  async remove(tenantId: string, schoolId: string, id: string) {
    const staff = await this.repo.findOne({ where: { id, tenantId, schoolId, deleted: false } });
    if (!staff) throw new NotFoundException('Staff member not found.');
    await this.repo.update(id, {
      deleted: true,
      serverRevision: await this.nextServerRevision(),
      syncStatus: 'local',
    });
  }

  private async assertCampusInScope(
    tenantId: string,
    schoolId: string,
    campusId: string | null | undefined,
  ) {
    if (!campusId) {
      return;
    }

    const campus = await this.campuses.findOne({
      where: { id: campusId, tenantId, schoolId, deleted: false },
    });
    if (!campus) {
      throw new NotFoundException('Campus not found.');
    }
  }

  private async nextServerRevision() {
    const result = (await this.dataSource.query(
      "SELECT nextval('sync_server_revision_seq')::bigint AS revision",
    )) as { revision: string | number }[];
    return Number(result[0].revision);
  }
}
